"""
anim.py - v1.00

Copyright 2023 Alec Dee - MIT license - SPDX: MIT
alecdee.github.io - akdee144@gmail.com


--------------------------------------------------------------------------------
Notes


yuv444p isn't recognized by browsers.
Try AV1 when it gets browser support.
Circuit background?


"""

import os, re, subprocess, math, time
from PIL import Image, ImageFont, ImageDraw

time0 = time.time()
path = "~/Downloads/animation"
path = os.path.abspath(os.path.expanduser(path)) + "/"

for name in os.listdir(path):
	if re.match("frame\\d+\\.(bmp|png)",name):
		os.remove(os.path.join(path,name))

backimg  = Image.new(mode="RGB",size=(1024,1024))
backdraw = ImageDraw.Draw(backimg)
scale    = backimg.height / 1080.0

logo = Image.open("logo.png")


#---------------------------------------------------------------------------------
# Text


fontarr = [
	["../files/consola.ttf",34,0],
	["../files/consola.ttf",60,0],
	["./C64_Pro_Mono-STYLE.ttf",34,0]
]

text = "!\"#$%&'()*+,-./0123456789:;<=>?@ABCDEFGHIJKLMNOPQRSTUVWXYZ[\\]^_`abcdefghijklmnopqrstuvwxyz{|}~"
for i in range(len(fontarr)):
	font = ImageFont.truetype(fontarr[i][0],int(fontarr[i][1]*scale))
	rect = backdraw.textbbox((0,0),text,font=font)
	charw,charh = rect[2]*1.0/len(text),rect[3]*1.09
	fontarr[i] = [font,charw,charh]

# Cache characters as images since they take so long to render.
textcache = {}
def textdraw(coord,text,color,fontnum=0):
	assert(len(color)==4)
	font,charw,charh = fontarr[fontnum]
	color = [int(c) for c in color]
	size  = int(34*scale)
	x,y = 0,0
	for char in text:
		if ord(char) < 32:
			if char == "\n":
				y += 1
				x = 0
			elif char == "\r":
				x = 0
			elif char == "\b":
				x -= 1
				if x < 0: x = 0
			elif char == "\t":
				x += 5 - (x % 5)
		else:
			index = tuple(color+[ord(char),size,fontnum])
			charimg = textcache.get(index,None)
			if charimg is None:
				charimg = Image.new("RGBA",(math.ceil(charw),math.ceil(charh)),(0,0,0,0))
				chardraw = ImageDraw.Draw(charimg)
				chardraw.text((0,0),char,fill=tuple(color),font=font)
				textcache[index] = charimg
			backimg.paste(charimg,(int(coord[0]+x*charw),int(coord[1]+y*charh)),charimg)
			x += 1


def textcoord(text,fontnum=0):
	font,charw,charh = fontarr[fontnum]
	x,y = 0,0
	for char in text:
		if ord(char) < 32:
			if char == "\n":
				y += 1
				x = 0
			elif char == "\r":
				x = 0
			elif char == "\b":
				x -= 1
				if x < 0: x = 0
			elif char == "\t":
				x += 5 - (x % 5)
		else:
			x += 1
	return (x*charw,y*charh)


def textrect(text,fontnum=0):
	font,charw,charh = fontarr[fontnum]
	maxx,x,y = 0,0,1
	for char in text:
		if ord(char) < 32:
			if char == "\n":
				y += 1
				x = 0
			elif char == "\r":
				x = 0
			elif char == "\b":
				x -= 1
				if x < 0: x = 0
			elif char == "\t":
				x += 5 - (x % 5)
		else:
			x += 1
		if maxx < x: maxx = x
	return (maxx*charw,y*charh)


#---------------------------------------------------------------------------------
# Title Screen


width = int(backimg.width*0.3)
logo = logo.resize((width,int(logo.height*width/logo.width)),Image.LANCZOS)

titlecolor = {
	"D":[255,255,255,255],
	"C":[153,153,255,255]
}

titlestr = "Single\nInstruction\nComputer\n"
titlefmt = "CDDDDD\nCDDDDDDDDDD\nCCDDDDDD\n"

rect = textrect(titlestr,1)
logobase  = [(backimg.width  - logo.width ) // 2,
             (backimg.height - logo.height) // 3]
titlebase = [logobase[0] + int(logo.width*0.085),
             logobase[1] + int(logo.height*1.5)]

def titledraw():
	alphaimg = Image.new("RGBA",logo.size,tuple(titlecolor["D"]))
	backimg.paste(logo,logobase,alphaimg)
	x0,y0 = titlebase
	for i in range(len(titlestr)):
		c,f = titlestr[i],titlefmt[i]
		if ord(c) > 32:
			x,y = textcoord(titlestr[:i],1)
			textdraw((x0 + x,y0 + y),c,titlecolor[f],1)


#---------------------------------------------------------------------------------
# SICO Code


codecolor = {
	"D":[255,255,255,255],
	"C":[153,153,221,255],
	"L":[170,187,128,255],
	"A":[144,144,144,255]
}

code0str = "loop: 0-2  txt  ?+1         # Print a letter\n      len  one  exit        # Decrement [len]\n      ?-5  neg  loop        # Increment pointer\n\nexit: 0-1  0    0\n\ntxt:  'H 'e 'l 'l 'o ', ' \n      'W 'o 'r 'l 'd '! 10\nlen:  len-txt\nneg:  0-1\none:  1"
code0fmt = "LLLLL DDD  DDD  DDD         CCCCCCCCCCCCCCCC\n      DDD  DDD  DDDD        CCCCCCCCCCCCCCCCC\n      DDD  DDD  DDDD        CCCCCCCCCCCCCCCCCCC\n\nLLLLL DDD  D    D\n\nLLLL  AA AA AA AA AA AA AA\n      AA AA AA AA AA AA DD\nLLLL  DDDDDDD\nLLLL  DDD\nLLLL  D"

code1str = "loop: 0-2  txt  ?+1\n      len  one  exit\n      ?-5  neg  loop\n\nexit: 0-1  0    0  \n\ntxt:  'H 'e 'l 'l 'o ', '             \n      'W 'o 'r 'l 'd '! 10           \nlen:  len-txt\nneg:  0-1\none:  1  "
code1fmt = "LLLLL DDD  DDD  DDD\n      DDD  DDD  DDDD\n      DDD  DDD  DDDD\n\nLLLLL DDD  D    D  \n\nLLLL  AA AA AA AA AA AA AA            \n      AA AA AA AA AA AA DD           \nLLLL  DDDDDDD\nLLLL  DDD\nLLLL  D  "

code2str = "loop:  -2   12    3\n       26   28    9 \n        1   27    0 \n\nexit:  -1    0    0\n\ntxt:   72  101  108  108  111  44  32 \n       87  111  114  108  100  33  10\nlen:   14    \nneg:   -1\none:    1"
code2fmt = "LLLLL  DD   DD    D\n       DD   DD    D \n        D   DD    D \n\nLLLLL  DD    D    D\n\nLLLL   DD  DDD  DDD  DDD  DDD  DD  DD \n       DD  DDD  DDD  DDD  DDD  DD  DD\nLLLL   DD    \nLLLL   DD\nLLLL    D"

codecurs = "      XXXXXXXXXXXXX\n      XXXXXXXXXXXXXX\n      XXXXXXXXXXXXXX\n\n      XXXXXXXXXXXXX\n\n      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n      XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX\n      XXXXXXX\n      XXX\n      XXX"

code3str = "       -2   12    3\n       26   28    9 \n        1   27    0 \n\n       -1    0    0\n\n       72  101  108  108  111  44  32 \n       87  111  114  108  100  33  10\n       14    \n       -1\n        1"

assert(len(code1str)==len(code2str))
assert(len(code2str)==len(codecurs))

def codedraw(coord,codestr,codefmt,fontnum=0):
	assert(len(codestr)==len(codefmt))
	x0,y0 = coord
	for i in range(len(codestr)):
		c,f = codestr[i],codefmt[i]
		if ord(c) > 32:
			x,y = textcoord(codestr[:i],fontnum)
			textdraw((x0+x,y0+y),c,codecolor[f],fontnum)

rect = textrect(code0str)
codebase = [int(backimg.width - rect[0]) // 2,
            int(fontarr[0][2] * 2)]


#---------------------------------------------------------------------------------
# Cell data


celldim = max(fontarr[0][1]*3*1.2,fontarr[0][2]*2*1.2)
cellpad = [int(celldim * 1.2),int(celldim * 1.2)]
celldim = int(celldim)

cellbase = [(backimg.width  - cellpad[0] * 7 + celldim * 0) // 2,
             backimg.height - cellpad[1] * 4 - celldim // 2]

class SicoCell():
	def __init__(self,text,index,state):
		self.state = state
		# cellx,celly = 0,0
		cellx = 0
		textx,texty = 0,0
		ordtext = [ord(c) for c in text]
		for i in range(index):
			c = ordtext[i]
			if c == 10:
				texty += 1
				textx = 0
			else:
				if c > 32 and (i == 0 or ordtext[i-1] <= 32):
					cellx += 1
				textx += 1
		self.val = int(text[index:].split()[0]) & state.mask
		celly = cellx // 8
		cellx %= 8
		self.rectpos = [int(cellbase[0] + cellx * cellpad[0]),
		                int(cellbase[1] + celly * cellpad[1])]
		rect = textrect(str(self.signedval()))
		self.textpos = [codebase[0] + textx * fontarr[0][1] + rect[0]*0.5,
		                codebase[1] + texty * fontarr[0][2] + rect[1]*0.5]
		self.color = [96,96,96,0]
		self.color0 = list(self.color)
		self.img = None


	def signedval(self):
		half,val = self.state.half,self.val
		if val >= half: val -= 2*half
		return val


	def drawrect(self):
		color = self.color
		if self.color0 != color or self.img is None:
			self.color0[:] = color[:]
			img = Image.new("RGBA",(celldim,celldim),(0,0,0,0))
			draw = ImageDraw.Draw(img)
			self.img = img
			shadow = celldim // 6
			border = celldim // 25
			norm = max(color)
			norm = 255/norm if norm > 255 else 1
			edge = norm * 0.66
			fillcol = (
				(int(color[0]*edge),int(color[1]*edge),int(color[2]*edge),int(color[3])),
				(0,0,0,0),
				(int(color[0]*norm),int(color[1]*norm),int(color[2]*norm),int(color[3]))
			)
			for layer in range(3):
				for i in range(shadow):
					incw = int(i < shadow - layer)*layer + img.width  - shadow - border*layer - 1
					inch = int(i < shadow - layer)*layer + img.height - shadow - border*layer - 1
					draw.rectangle((i+border*layer,i+border*layer,i+incw,i+inch),fill=fillcol[layer])
		x,y = self.rectpos
		backimg.paste(self.img,(int(x-celldim//2),int(y-celldim//2)),self.img)


	def drawtext(self):
		vstr = str(self.signedval())
		rect = textrect(vstr)
		x,y = self.textpos
		textdraw((x-rect[0]*0.5,y-rect[1]*0.5),vstr,codecolor["D"])


class SicoState:
	COMPLETED = 0
	RUNNING = 1

	def __init__(self):
		self.half = 1<<63
		self.mask = (self.half << 1) - 1
		self.mem = []
		self.memalpha = 0
		self.outalpha = 0
		self.outimg = None
		self.outtext = chr(0x2588)
		mem = []
		i,l = 0,len(code3str)
		while True:
			while i < l and ord(code3str[i]) <= 32: i += 1
			if i >= l: break
			mem += [SicoCell(code3str,i,self)]
			while i < l and ord(code3str[i]) >  32: i += 1
		self.mem = mem
		self.ip = 0
		self.state = self.RUNNING


	def draw(self):
		if self.outalpha > 0:
			alpha = self.outalpha
			img = Image.new("RGBA",(int(backimg.width-cellbase[0]*2+celldim),int(cellbase[1]-celldim*1.5-fontarr[0][2]*4)),(0,0,0,0))
			draw = ImageDraw.Draw(img)
			self.outimg = img
			border = celldim // 25
			draw.rectangle((0,0,img.width-1,img.height-1),fill=(128,255,128,alpha))
			draw.rectangle((border,border,img.width-border-1,img.height-border-1),fill=(32,32,32,alpha))
			x,y = int(backimg.width-self.outimg.width)//2,int(celldim+fontarr[0][2]*0.5)
			backimg.paste(self.outimg,(x,y),self.outimg)
			rect = textrect("Output")
			textdraw((x+border*4,y+border*4),self.outtext,(128,255,128,alpha),2)
		if self.memalpha > 0:
			alpha = self.memalpha
			rect = textrect("Memory Cells")
			textdraw((int((backimg.width-rect[0])*0.5),int(cellbase[1]-celldim*0.5-fontarr[0][2]*2)),"Memory Cells",(255,255,255,alpha))
			for cell in self.mem: cell.color[3] = alpha
			for cell in self.mem: cell.drawrect()
		for cell in self.mem: cell.drawtext()


	def update(self):
		if self.state != self.RUNNING:
			return
		half,mask = self.half,self.mask
		ip,mem = self.ip,self.mem
		a,b,c = mem[ip].val,mem[ip+1].val,mem[ip+2].val
		for cell in mem:
			cell.color = [96,96,96] + cell.color[3:]
		for i in range(ip,ip+3):
			mem[i].color = [255,80,80]+mem[i].color[3:]
		bv = mem[b].val
		if a >= half:
			self.outtext = self.outtext[:-1]
			if a == mask - 0:
				self.outtext += "\nProgram terminated..."
				self.state = self.COMPLETED
			elif a == mask - 1:
				self.outtext += chr(bv) + chr(0x2588)
			ip = c
		else:
			av = mem[a].val
			mem[a].val = (av - bv) & mask
			ip = c if av <= bv else (ip+3)
		self.ip = ip


sico = SicoState()


#---------------------------------------------------------------------------------
# Render the scene


instframes = [0] + [max(15,60-i*5) for i in range(42)]
for i in range(1,len(instframes)): instframes[i] += instframes[i-1]
sceneframes = [
	  0,120,  # 0: SICO title
	 30, 60,  # 1: Show code
	 30,  0,  # 3: Fade out comments
	170, 10,  # 5: Replace values
	 30, 10,  # 7: Fade out labels
	 30, 10,  # 9: Fade in memory cells
	60+8*len(sico.mem),10,  # 11: Sort values into cells
	30,  10,  # 13: Fade in output
	instframes[-1],300  # 15: Run SICO
]
for i in range(1,len(sceneframes)): sceneframes[i] += sceneframes[i-1]

scene = 0
for frame in range(sceneframes[-1]):
	print("{0} / {1}".format(frame,sceneframes[-1]-1))
	backdraw.rectangle(((0,0),backimg.size),(0,0,0,255))
	while frame >= sceneframes[scene+1]: scene += 1
	f = frame - sceneframes[scene]
	u = f / (sceneframes[scene+1] - sceneframes[scene] - 1)
	if scene == 0:
		# Pause to show the SICO title.
		titledraw()
	elif scene == 1:
		# Fade in code.
		alpha = int((1 - u) * 255)
		titlecolor["D"][3] = alpha
		titlecolor["C"][3] = alpha
		for val in codecolor.values(): val[3] = 255 - alpha
		titledraw()
		codedraw(codebase,code0str,code0fmt)
	elif scene == 2:
		# Pause to show the code.
		codedraw(codebase,code0str,code0fmt)
	elif scene == 3:
		# Dim the comments.
		alpha = int((1 - u) * 255)
		codecolor["C"][3] = alpha
		codedraw(codebase,code0str,code0fmt)
	elif scene == 4:
		# Pause to show the code.
		codedraw(codebase,code0str,code0fmt)
	elif scene == 5:
		# Replace tokens with values.
		difs = [i for i in range(len(codecurs)) if codecurs[i]=="X"]
		tmpstr = code2str
		tmpfmt = code2fmt
		i = int(len(difs)*u*1.01)
		if i < len(difs):
			i = difs[i]
			tmpstr = code2str[:i] + chr(0x2588) + code1str[i+1:]
			tmpfmt = code2fmt[:i] + "D" + code1fmt[i+1:]
		codedraw(codebase,tmpstr,tmpfmt)
	elif scene == 6:
		# Pause to show the translated values.
		codedraw(codebase,code2str,code2fmt)
	elif scene == 7:
		# Dim the labels.
		codecolor["L"][3] = (1 - u) * 255
		codedraw(codebase,code2str,code2fmt)
	elif scene == 8:
		# Pause to show values.
		codedraw(codebase,code2str,code2fmt)
	elif scene == 9:
		# Fade in memory cells.
		sico.memalpha = int(u * 255)
		sico.draw()
	elif scene == 10:
		# Pause to show memory cells.
		sico.draw()
	elif scene == 11:
		# Sort memory values.
		lim = min(len(sico.mem),f//8+1)
		z = math.exp(math.log(0.01) / 59.0)
		for i in range(lim):
			cell = sico.mem[i]
			x,y = cell.rectpos
			cell.textpos = [x + (cell.textpos[0] - x) * z, y + (cell.textpos[1] - y) * z]
		if frame == sceneframes[scene+1]-1:
			for cell in sico.mem: cell.textpos = cell.rectpos
		sico.draw()
	elif scene == 12:
		# Pause to show memory cells.
		sico.draw()
	elif scene == 13:
		# Fade in output.
		sico.outalpha = int(u * 255)
		sico.draw()
	elif scene == 14:
		# Pause to show output.
		sico.draw()
	elif scene == 15:
		# Update SICO state.
		if f in instframes: sico.update()
		sico.draw()
	elif scene == 16:
		# Pause to show final screen.
		sico.draw()
	else:
		assert(False)
	backimg.save(path+"frame{0:05d}.bmp".format(frame),"bmp")

time1 = time.time()

# Compile the frames into a video.
ffcmd = "ffmpeg -r 60 -f image2 -s {0}x{1} -i \"{2}frame%05d.bmp\" -vcodec libx264 -acodec avc -crf 1 -pix_fmt yuv420p -y \"{2}anim.mp4\"".format(backimg.width,backimg.height,path)
print("calling: " + ffcmd)
subprocess.call(ffcmd,shell=True)

time2 = time.time() - time1
time1 -= time0
print("Image time: {0:.2f}".format(time1))
print("Video time: {0:.2f}".format(time2))

