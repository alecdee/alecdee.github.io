#!/usr/bin/python3
"""
Compile C source files and concatenate libraries.
Store output in "compiled" directory.
"""


import os,re,sys,shutil


# Directory helpers
pydir=os.path.dirname(os.path.abspath(__file__))
webdir=os.path.realpath(os.path.join(pydir,"../libraries"))
cmpdir=os.path.realpath(os.path.join(pydir,"./compiled"))
libdir=os.path.realpath(os.path.join(pydir,"./library"))
mscdir=os.path.realpath(os.path.join(pydir,"./misc"))

def webjoin(path): return os.path.join(webdir,path)
def cmpjoin(path): return os.path.join(cmpdir,path)
def libjoin(path): return os.path.join(libdir,path)
def mscjoin(path): return os.path.join(mscdir,path)

def loadfile(path):
	with open(path,"r") as f:
		return "".join(f.readlines())
	raise "failed to load file"

def concat(input,output):
	text=""
	for file in input: text+=loadfile(file)
	with open(output,"w") as f: f.write(text)


# Compile the master library. Add line numbers to the index.
if not os.path.isdir(cmpdir): os.mkdir(cmpdir)
master=loadfile(libjoin("master_header.sico"))
files=("uint.sico","int.sico","random.sico","string.sico","memory.sico")
for file in files:
	path=libjoin(file)
	data=loadfile(path)
	idx="{0:s}  |  {1:>4d}".format(file,master.count("\n")+1)
	master=re.sub(re.escape("$"+file+"  |"),idx,master,1)
	master+=data
with open(cmpjoin("master.sico"),"w") as f:
	f.write(master)


# Compile demos
concat([libjoin("helloworld_demo.sico")]                   ,cmpjoin("helloworld_demo.sico"))
concat([libjoin("memory_demo.sico"),cmpjoin("master.sico")],cmpjoin("memory_demo.sico"))
concat([libjoin("random_demo.sico"),cmpjoin("master.sico")],cmpjoin("random_demo.sico"))
concat([libjoin("string_demo.sico"),cmpjoin("master.sico")],cmpjoin("string_demo.sico"))
concat([libjoin("uint_demo.sico")  ,cmpjoin("master.sico")],cmpjoin("uint_demo.sico"))


# Compile tests
concat([libjoin("int_test.sico")   ,cmpjoin("master.sico")],cmpjoin("int_test.sico"))
concat([libjoin("memory_test.sico"),cmpjoin("master.sico")],cmpjoin("memory_test.sico"))
concat([libjoin("random_test.sico"),cmpjoin("master.sico")],cmpjoin("random_test.sico"))
concat([libjoin("uint_test.sico")  ,cmpjoin("master.sico")],cmpjoin("uint_test.sico"))


# Copy compiled files to the site library
shutil.copyfile(cmpjoin("helloworld_demo.sico"),webjoin("helloworld_demo.sico"))
shutil.copyfile(libjoin("int.sico")        ,webjoin("int.sico"))
shutil.copyfile(cmpjoin("master.sico")     ,webjoin("master.sico"))
shutil.copyfile(libjoin("memory.sico")     ,webjoin("memory.sico"))
shutil.copyfile(cmpjoin("memory_demo.sico"),webjoin("memory_demo.sico"))
shutil.copyfile(cmpjoin("string_demo.sico"),webjoin("string_demo.sico"))
shutil.copyfile(libjoin("random.sico")     ,webjoin("random.sico"))
shutil.copyfile(cmpjoin("random_demo.sico"),webjoin("random_demo.sico"))
shutil.copyfile(libjoin("string.sico")     ,webjoin("string.sico"))
shutil.copyfile(cmpjoin("string_demo.sico"),webjoin("string_demo.sico"))
shutil.copyfile(libjoin("uint.sico")       ,webjoin("uint.sico"))
shutil.copyfile(cmpjoin("uint_demo.sico")  ,webjoin("uint_demo.sico"))


# Compile sico.c, sico_graphics.c, and sicotest.c
if os.path.isfile(cmpjoin("sico")): os.remove(cmpjoin("sico"))
os.system("gcc -Wall -Wextra -O3 "+os.path.join(pydir,"../sico.c")+" -o "+cmpjoin("sico"))
if os.path.isfile(cmpjoin("sico_graphics")): os.remove(cmpjoin("sico_graphics"))
os.system("gcc -Wall -Wextra -O3 "+mscjoin("sico_graphics.c")+" -o "+cmpjoin("sico_graphics")+" -lSDL2")
if os.path.isfile(cmpjoin("sico_test")): os.remove(cmpjoin("sico_test"))
os.system("gcc -I\""+os.path.join(pydir,"../")+"\" -fsanitize=address -fsanitize=undefined "+mscjoin("sico_test.c")+" -o "+cmpjoin("sico_test"))


