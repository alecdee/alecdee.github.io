#--------------------------------------------------------------------------------
#Prime Generator Functions
#--------------------------------------------------------------------------------

#from amico    import primes_up_to as Ami_primegen
from beneicke import primegen as Ben_primegen
from eppstein import eratosthenes as Epp_primegen
from hochberg import primegen as Hoc_primegen
from hofstra  import erat2a   as Hof_primegen
from ness     import postponed_sieve as Nes_primegen
from martelli import primegen as Mar_primegen
from primegen import primegen as Dee_primegen

genarr=(
	(Epp_primegen,"Eppstein"),(Mar_primegen,"Martelli"),
	(Ben_primegen,"Beneicke"),(Hof_primegen,"Hofstra"),
	(Hoc_primegen,"Hochberg"),(Nes_primegen,"Ness"),
	(Dee_primegen,"Dee")
)

#--------------------------------------------------------------------------------
#Speed testing
#--------------------------------------------------------------------------------

import time,gc

def speedtest(func,n=10**8):
	#Reset the grabage collector and wait a few seconds to try and create the same
	#environment for each test.
	gc.collect()
	time.sleep(3.0)
	t0=time.time()
	s=0
	for p in func():
		if p>=n: break
		s+=p
	t0=time.time()-t0
	#Sanity checks.
	assert(n!=10**7 or s==3203324994356)
	assert(n!=10**8 or s==279209790387276)
	assert(n!=10**9 or s==24739512092254535)
	return t0

for func,name in genarr:
	t=speedtest(func)
	print(name+": {0:>6f} s".format(t))

#--------------------------------------------------------------------------------
#Memory testing
#--------------------------------------------------------------------------------

def memorytest(func,n=10**8):
	gc.collect()
	time.sleep(3.0)
	heap=guppy.hpy()
	size=heap.heap().size
	it=iter(func())
	p=0
	while p<n: p=next(it)
	size=heap.heap().size-size
	next(it)
	return size

try:
	import guppy
	for func,name in genarr:
		s=memorytest(func)
		print(name+": {0:d} kb".format((s+512)//1024))
except ImportError:
	print("Could not import guppy. Skipping memory profiling.")

#--------------------------------------------------------------------------------
#Speed plotting
#--------------------------------------------------------------------------------

try:
	import matplotlib.pyplot as plt
	maxn=10**7
	markinc=10**4
	funcs=len(genarr)
	timearr=[None]*funcs
	for f in range(funcs):
		gc.collect()
		time.sleep(3.0)
		markn=markinc-1
		markarr=[0]*(maxn//markinc+1)
		markindex=1
		func,name=genarr[f]
		time0=time.time()
		it=iter(func())
		for n in range(maxn):
			next(it)
			if n==markn:
				t=time.time()-time0
				markarr[markindex]=t
				markindex+=1
				markn+=markinc
		timearr[f]=markarr
	xaxis=list(range(0,maxn+1,markinc))
	fig=plt.figure(figsize=(12,6),dpi=100)
	plt.xlabel("n",fontsize=15)
	plt.ylabel("seconds",fontsize=15)
	xform=plt.gca()
	xform.get_xaxis().get_major_formatter().set_scientific(False)
	maxy=70
	plt.xlim(0,maxn)
	plt.ylim(0,maxy)
	for f in range(funcs):
		yaxis=timearr[f]
		name=genarr[f][1]
		plt.plot(xaxis,yaxis)
		x=0
		for i in range(len(xaxis)):
			if yaxis[i]<=maxy: x=xaxis[i]
		y=min(yaxis[-1],maxy)
		#Kludge for text overlap.
		if name=="Hofstra": y-=1.0
		plt.text(x,y,name)
	plt.show()
except ImportError:
	print("Could not import matplotlib. Skipping time plotting.")

