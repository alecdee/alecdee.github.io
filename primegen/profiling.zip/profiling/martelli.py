#Alex Martelli
#License: https://docs.python.org/3/license.html

def primegen():
	'''Yields the sequence of prime numbers via the Sieve of Eratosthenes.'''
	D = {}  # map composite integers to primes witnessing their compositeness
	q = 2   # first integer to test for primality
	while True:
		p = D.pop(q, None)
		if p:
			x = p + q
			while x in D: x += p
			D[x] = p
		else:
			D[q*q] = q
			yield q
		q += 1
