#Wolfgang Beneicke
#License: https://docs.python.org/3/license.html

import itertools
def primegen():
	D = {}
	yield 2    # no need to mark D[4] as we will test odd numbers only
	for q in itertools.islice(itertools.count(3),0,None,2):
		p = D.pop(q,None)      # get and remove
		if p:                      #  is composite
			x = q + p+p                # next odd(!) multiple
			while x in D:              # skip primes
				x += p+p
			D[x] = p
		else:                      # is prime
			D[q*q] = q
			yield q
