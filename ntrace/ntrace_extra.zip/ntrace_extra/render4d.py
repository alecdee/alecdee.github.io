"""
render4d.py - v1.05

Copyright (C) 2020 by Alec Dee - alecdee.github.io - akdee144@gmail.com

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

import NTrace,time,sys

if __name__=="__main__":
	#Render a 4D scene with 3 hypercubes. For less noise, increase raysperpixel.
	path="./render4d.bmp"
	start=time.time()
	sc=NTrace.Scene(4,600,600)
	sc.raysperpixel=(1<<6,1<<16)[sys.argv[-1]=="-HQ"]
	#4D requires 4 coordinate values and 6 angles for rotation.
	sc.setcamera((0,0,1.5,0),(0,0,0,0,0,0))
	#Materials are the same as 3D.
	boxmat=NTrace.MeshMaterial((0.4,0.4,0.9),0.0)
	floormat=NTrace.MeshMaterial((0.9,0.9,0.9),0.0)
	lightmat=NTrace.MeshMaterial((1.0,1.0,1.0),12.0)
	#Create the floor, light, and center hypercubes.
	#Specify 6 angles to rotate the center hypercube by.
	angs=(3.70,3.47,4.95,0.58,2.51,0.27)
	sc.addcube((0.5,0.5,0.5,0.5),boxmat,NTrace.Transform((0,0,0,0),angs))
	sc.addcube((100,100,100,100),floormat,NTrace.Transform((0,-50.7,0,0)))
	sc.addcube((3,3,3,3),lightmat,NTrace.Transform((0,5.0,0,0)))
	print("rendering {0} tetrahedrons".format(sc.mesh.faces))
	sc.render(True)
	print("saving image to "+path)
	sc.savebmp(path)
	print("time: {0:.6f}".format(time.time()-start))
