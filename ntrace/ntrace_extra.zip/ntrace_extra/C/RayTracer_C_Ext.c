/*
RayTracer_C_Ext.c - v1.01

Copyright 2020 Alec Dee - MIT license - SPDX: MIT
alecdee.github.io - akdee144@gmail.com
*/

#include <Python.h>
#include <math.h>
#include <stdio.h>
#include <string.h>
#if defined(_MSC_VER)!=0
	#include <intrin.h>
	#define _Thread_local __declspec(thread)
#else
	#include <x86intrin.h>
#endif

//---------------------------------------------------------------------------------
// Declarations
//---------------------------------------------------------------------------------

typedef   signed      char  s8;
typedef unsigned      char  u8;
typedef   signed     short s16;
typedef unsigned     short u16;
typedef   signed       int s32;
typedef unsigned       int u32;
typedef   signed long long s64;
typedef unsigned long long u64;
// typedef              float f32;
typedef             double f64;

// #define RT_DIAGNOSTICS
#define RT_EPS 1e-8
// f32: 1e-4
// f64: 1e-8
#define RT_INF ((f64)INFINITY)

#define DIM 3
#define RT_TYPE_NONE  0
#define RT_TYPE_MATL  1
#define RT_TYPE_VERT  2
#define RT_TYPE_FACE  3
#define RT_TYPE_INST  4
#define RT_TYPE_BVH   5
#define RT_TYPE_MESH  6
#define RT_TYPE_SCENE 7

typedef struct rtvec_t rtvec;
typedef struct rtmat_t rtmat;
typedef struct rtray_t rtray;
typedef struct rtmaterial_t rtmaterial;
typedef struct rtvert_t rtvert;
typedef struct rtface_t rtface;
typedef struct rtinst_t rtinst;
typedef struct rtbvhnode_t rtbvhnode;
typedef struct rtmesh_t rtmesh;
typedef struct rtscene_t rtscene;
typedef struct rtpymaplink_t rtpymaplink;

struct rtvec_t
{
	f64 elem[DIM];
};

struct rtmat_t
{
	f64 elem[DIM*DIM];
};

struct rtbvhnode_t
{
	rtvec bbmin;
	rtvec bbmax;
	// rtbvhnode* parent;
	void* left;
	void* right;
	rtbvhnode* next[1<<DIM];
	u8 type;
	u8 axis;
	u8 testray;
};

struct rtray_t
{
	rtvec pos;
	rtvec dir;
	rtvec inv;
	f64 min;
	f64 max;
	f64 dot;
	rtvec facenorm;
	rtface* face;
	rtmaterial* facemat;
	u8 swap;
};

struct rtmaterial_t
{
	f64 color[3];
	f64 luminosity;
	f64 reflectprob;
	f64 diffusion;
	f64 refractprob;
	f64 refractindex;
	f64 refractinv;
	f64 scatterlen;
	f64 absorbprob;
	rtpymaplink* pymap;
};

struct rtvert_t
{
	rtvec pos;
};

struct rtface_t
{
	rtvec norm;
	rtvec off;
	rtvec bary[DIM-1];
	#ifdef RT_DIAGNOSTICS
		rtvert* vertarr[DIM];
	#endif
	rtmaterial* mat;
};

struct rtinst_t
{
	rtmat transmat;
	rtvec transoff;
	rtmat invmat;
	rtvec invoff;
	rtmesh* mesh;
	rtmaterial* matl;
	rtpymaplink* pymap;
};

struct rtmesh_t
{
	rtpymaplink* pymap;
	rtvert* vertarr;
	rtface* facearr;
	rtinst* instarr;
	rtbvhnode* bvhnodearr;
	rtbvhnode* bvhroot;
	s32 dim;
	s32 verts;
	s32 faces;
	s32 insts;
	s32 bvhnodes;
	s32 bvhnodepos;
};

struct rtscene_t
{
	rtvec campos;
	rtvec cambl;
	rtvec camu;
	rtvec camv;
	f64* imgrgb;
	rtmesh* mesh;
	rtpymaplink* pymap;
	s32 dim;
	u32 raysperpixel;
	u32 maxbounces;
	s32 imgwidth;
	s32 imgheight;
	s32 imgpixels;
};

rtmesh* rtmeshcreate(void);
void rtmeshfree(rtmesh* mesh);
void rtmeshloadpy(rtmesh* mesh,PyObject* pymesh);
rtbvhnode* rtbvhloadpyarr(PyObject* pybvh,s32 nodes);
void rtbvhraypick(rtbvhnode* root,rtray* ray);
void rtscenefree(rtscene* scene);
void rtmatlfree(rtmaterial* mat);

//---------------------------------------------------------------------------------
// Helper Functions
//---------------------------------------------------------------------------------

#ifdef RT_DIAGNOSTICS
	#define rtassert(cond) rtassert0((cond)!=0,__FILE__,__LINE__)
	void rtassert0(u32 cond,const char* file,int line)
	{
		if (cond==0)
		{
			printf("assert failed:\nfile: %s\nline: %d\n",file,line);
			exit(1);
		}
	}
	#define rtprint(...) printf(__VA_ARGS__)
	s64 rt_alloc_count=0;
	u64 rt_face_hit=0;
	u64 rt_bvh_hit=0;
	u64 rt_ray_count=0;
#else
	#define rtassert(cond) ((void)0)
	#define rtprint(...) ((void)0)
#endif

void* rtalloc(u32 size)
{
	if (size==0) {return 0;}
	#ifdef RT_DIAGNOSTICS
		rt_alloc_count++;
	#endif
	return malloc(size);
}

void rtfree(void* mem)
{
	if (mem==0) {return;}
	#ifdef RT_DIAGNOSTICS
		rt_alloc_count--;
	#endif
	free(mem);
}

u64 rtrand64(void)
{
	// Generate a random, uniformly distributed 64 bit integer.
	static _Thread_local u64 state=0;
	static _Thread_local u64 inc=0;
	if (inc==0)
	{
		inc=__rdtsc()|(1ULL<<63);
		inc=rtrand64()|1;
		state=__rdtsc();
	}
	u64 hash=state+=inc;
	hash++;hash+=hash<<10;hash^=hash>>51;
	hash++;hash+=hash<<32;hash^=hash>>14;
	hash++;hash+=hash<< 4;hash^=hash>>12;
	hash++;hash+=hash<<24;hash^=hash>>28;
	return hash;
}

f64 rtrandf(void)
{
	// Generate a 64 bit float in [0,1). Assume we're working with an IEEE double
	// precision float and create a value in [1,2). Then, subtract 1.
	union {u64 i;f64 f;} cast;
	cast.i=(rtrand64()>>12)|0x3ff0000000000000ULL;
	return cast.f-1.0;
}

f64 rtrandr(f64 min,f64 max)
{
	// Generate a 64 bit float in the range [min,max).
	return rtrandf()*(max-min)+min;
}

u32 rtrandmod(u32 min,u32 max)
{
	// Generate a 32 bit int in the range [min,max).
	return rtrand64()%(max-min)+min;
}

f64 rtrandn(void)
{
	// Return a normally distributed random variable. This function uses a linear
	// piecewise approximation of sqrt(2)*erfinv((x+1)*0.5) to quickly compute values.
	static const f64 xmbarr[96]=
	{
		0.0000000000,2.1105791e+05,-5.4199832e+00,0.0000056568,6.9695708e+03,-4.2654963e+00,
		0.0000920071,7.7912181e+02,-3.6959312e+00,0.0007516877,1.6937928e+02,-3.2375953e+00,
		0.0032102442,6.1190088e+01,-2.8902816e+00,0.0088150936,2.8470915e+01,-2.6018590e+00,
		0.0176252084,1.8800444e+01,-2.4314149e+00,0.0283040851,1.2373531e+01,-2.2495070e+00,
		0.0466319112,8.6534303e+00,-2.0760316e+00,0.0672857680,6.8979540e+00,-1.9579131e+00,
		0.0910495504,5.3823501e+00,-1.8199180e+00,0.1221801449,4.5224728e+00,-1.7148581e+00,
		0.1540346442,3.9141567e+00,-1.6211563e+00,0.1900229058,3.4575317e+00,-1.5343871e+00,
		0.2564543024,2.8079448e+00,-1.3677978e+00,0.3543675790,2.6047685e+00,-1.2957987e+00,
		0.4178358886,2.5233767e+00,-1.2617903e+00,0.5881852711,2.6379475e+00,-1.3291791e+00,
		0.6397157999,2.7530438e+00,-1.4028080e+00,0.7303095074,3.3480131e+00,-1.8373198e+00,
		0.7977016349,3.7812818e+00,-2.1829389e+00,0.8484734402,4.7872429e+00,-3.0364702e+00,
		0.8939255135,6.2138677e+00,-4.3117665e+00,0.9239453541,7.8175201e+00,-5.7934537e+00,
		0.9452687641,1.0404724e+01,-8.2390571e+00,0.9628624602,1.4564418e+01,-1.2244270e+01,
		0.9772883839,2.3567788e+01,-2.1043159e+01,0.9881715750,4.4573121e+01,-4.1800032e+01,
		0.9948144543,1.0046744e+02,-9.7404506e+01,0.9980488575,2.5934959e+02,-2.5597666e+02,
		0.9994697975,1.0783868e+03,-1.0745796e+03,0.9999882905,1.3881171e+05,-1.3880629e+05
	};
	// Find the greatest y[i]<=x, then return x*m[i]+b[i].
	f64 x=rtrandf();
	const f64* xmb=xmbarr+48;
	xmb+=x<*xmb?-24:24;
	xmb+=x<*xmb?-12:12;
	xmb+=x<*xmb?-6:6;
	xmb+=x<*xmb?-3:3;
	xmb+=x<*xmb?-3:0;
	return x*xmb[1]+xmb[2];
}

//---------------------------------------------------------------------------------
// Python Setup
//---------------------------------------------------------------------------------
// "self" refers to the module.
// "args" contains all the arguments passed to the python function.
//
// In the python documentation, if an object it a new reference, we need to call
// decref. If an object is a borrowed reference, do nothing.

// https://docs.python.org/3/c-api/object.html
// https://docs.python.org/3/c-api/float.html
// https://docs.python.org/3/c-api/list.html

static PyObject* render(PyObject* self,PyObject* args);

static PyMethodDef methoddefs[]=
{
	{"render",render,METH_VARARGS,"N/A"},
	{NULL,NULL,0,NULL}
};

static struct PyModuleDef moduledef=
{
	PyModuleDef_HEAD_INIT,
	"RayTracer_C_Ext",
	"RayTracer C extensions",
	-1,
	methoddefs,
	NULL,
	NULL,
	NULL,
	NULL
};

PyMODINIT_FUNC PyInit_RayTracer_C_Ext(void)
{
	return PyModule_Create(&moduledef);
}

f64 pygetf64(PyObject* obj,const char* name)
{
	PyObject* elem=PyObject_GetAttrString(obj,name);
	f64 x=PyFloat_AsDouble(elem);
	Py_DECREF(elem);
	return x;
}

s32 pygets32(PyObject* obj,const char* name)
{
	PyObject* elem=PyObject_GetAttrString(obj,name);
	s32 x=PyLong_AsLong(elem);
	Py_DECREF(elem);
	return x;
}

PyObject* pygetobj(PyObject* obj,const char* name)
{
	PyObject* elem=PyObject_GetAttrString(obj,name);
	rtassert(elem->ob_refcnt>1);
	Py_DECREF(elem);
	return elem;
}

struct rtpymaplink_t
{
	rtpymaplink* next;
	PyObject* pyobj;
	void* rtobj;
	u32 type;
};

rtpymaplink** rtpymap=0;
const u32 rtpymaplen=1<<24;

u32 rtpymaphash(void* ptr)
{
	u64 hash=0;
	for (u32 i=0;i<sizeof(ptr);i++)
	{
		u8* dst=(u8*)&hash;
		u8* src=(u8*)&ptr;
		dst[i%sizeof(hash)]^=src[i];
		if (i+1==sizeof(ptr) || (i+1)%sizeof(hash)==0)
		{
			hash=(hash>>31)|(hash<<33);
			hash^=hash>>34;
			hash*=0x77289737111f5371ULL;
			hash=(hash>>42)|(hash<<22);
			hash^=hash>>12;
			hash*=0x2cd3001685ece1f9ULL;
			hash=(hash>>55)|(hash<<9);
			hash^=hash>>20;
			hash*=0xc80b46d2e9ec9f8dULL;
			hash=(hash>>32)|(hash<<32);
		}
	}
	return hash%rtpymaplen;
}

void* rtpymapget(PyObject* pyobj)
{
	if (rtpymap==0) {return 0;}
	u32 hash=rtpymaphash(pyobj);
	rtpymaplink* link=rtpymap[hash];
	while (link && link->pyobj!=pyobj) {link=link->next;}
	if (link) {return link->rtobj;}
	return 0;
}

rtpymaplink* rtpymapadd(PyObject* pyobj,void* rtobj,u32 type)
{
	rtassert(pyobj!=0 && rtobj!=0);
	if (rtpymap==0)
	{
		rtpymap=rtalloc(sizeof(rtpymaplink*)*rtpymaplen);
		for (u32 i=0;i<rtpymaplen;i++) {rtpymap[i]=0;}
	}
	u32 hash=rtpymaphash(pyobj);
	rtpymaplink** root=rtpymap+hash;
	rtpymaplink* link=rtalloc(sizeof(rtpymaplink));
	link->next=*root;
	link->pyobj=pyobj;
	link->rtobj=rtobj;
	link->type=type;
	*root=link;
	return link;
}

void rtpymapnodefree(rtpymaplink* node)
{
	if (node && node->type!=RT_TYPE_NONE)
	{
		node->type=RT_TYPE_NONE;
		node->pyobj=0;
		node->rtobj=0;
	}
}

void rtpymapfree(void)
{
	// Free objects in reverse order, so their free calls can mark objects that the
	// map doesn't need to free.
	for (s32 order=7;order>-1;order--)
	{
		for (u32 i=0;i<rtpymaplen;i++)
		{
			rtpymaplink* link=rtpymap[i];
			while (link)
			{
				rtpymaplink* next=link->next;
				s32 type=link->type;
				if (type==order)
				{
					void* obj=link->rtobj;
					if (type==RT_TYPE_MATL ) {rtmatlfree(obj);}
					// if (type==RT_TYPE_VERT ) {rtvertfree(obj);}
					// if (type==RT_TYPE_FACE ) {rtfacefree(obj);}
					// if (type==RT_TYPE_INST ) {rtinstfree(obj);}
					// if (type==RT_TYPE_BVH  ) {rtbvhfree(obj);}
					if (type==RT_TYPE_MESH ) {rtmeshfree(obj);}
					if (type==RT_TYPE_SCENE) {rtscenefree(obj);}
				}
				if (order==0) {rtfree(link);}
				link=next;
			}
		}
	}
	rtfree(rtpymap);
	rtpymap=0;
}

void rtpymapnofree(rtpymaplink* link)
{
	if (link) {link->type=RT_TYPE_NONE;}
}

//---------------------------------------------------------------------------------
// Algebra
//---------------------------------------------------------------------------------
// Helper classes for matrix/vector linear algebra.

void rtvecloadpy(rtvec* vec,PyObject* pyvec)
{
	PyObject* pyelem=pygetobj(pyvec,"elem");
	for (int i=0;i<DIM;i++)
	{
		PyObject* obj=PyList_GetItem(pyelem,i);
		vec->elem[i]=PyFloat_AsDouble(obj);
	}
}

void rtvecloadpyname(rtvec* vec,PyObject* pyobj,const char* name)
{
	rtvecloadpy(vec,pygetobj(pyobj,name));
}

inline void rtvecset(rtvec* r,const rtvec* u)
{
	memcpy(r,u,sizeof(rtvec));
}

inline void rtveczero(rtvec* u)
{
	memset(u,0,sizeof(rtvec));
}

inline void rtvecadd(rtvec* r,const rtvec* u,const rtvec* v)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=u->elem[i]+v->elem[i];}
}

inline void rtvecaddmul(rtvec* r,const rtvec* u,const rtvec* v,const f64 mul)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=u->elem[i]+v->elem[i]*mul;}
}

inline void rtvecsub(rtvec* r,const rtvec* u,const rtvec* v)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=u->elem[i]-v->elem[i];}
}

inline void rtvecneg(rtvec* r,const rtvec* u)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=-u->elem[i];}
}

inline void rtvecscale(rtvec* r,const rtvec* u,const f64 scale)
{
	for (u32 i=0;i<DIM;i++) {r->elem[i]=u->elem[i]*scale;}
}

inline f64 rtvecdot(const rtvec* u,const rtvec* v)
{
	f64 r=0.0;
	for (u32 i=0;i<DIM;i++) {r+=u->elem[i]*v->elem[i];}
	return r;
}

inline f64 rtvecmag(const rtvec* u)
{
	f64 r=0.0;
	for (u32 i=0;i<DIM;i++) {r+=u->elem[i]*u->elem[i];}
	return sqrt(r);
}

inline void rtvecrand(rtvec* r)
{
	f64 mag;
	do
	{
		mag=0.0;
		for (u32 i=0;i<DIM;i++)
		{
			f64 x=rtrandn();
			r->elem[i]=x;
			mag+=x*x;
		}
	}
	while(mag<=1e-10);
	mag=1.0/sqrt(mag);
	for (u32 i=0;i<DIM;i++) {r->elem[i]*=mag;}
}

inline void rtvecnorm(rtvec* r,const rtvec* u)
{
	f64 mag=rtvecdot(u,u);
	if (mag<=1e-10) {rtvecrand(r);}
	else {rtvecscale(r,u,1.0/sqrt(mag));}
}

void rtmatloadpy(rtmat* mat,PyObject* pymat)
{
	PyObject* pyelem=pygetobj(pymat,"elem");
	for (int i=0;i<DIM*DIM;i++)
	{
		PyObject* obj=PyList_GetItem(pyelem,i);
		mat->elem[i]=PyFloat_AsDouble(obj);
	}
}

void rtmatloadpyname(rtmat* mat,PyObject* pyobj,const char* name)
{
	rtmatloadpy(mat,pygetobj(pyobj,name));
}

void rtvecmatmul(rtvec* r,const rtmat* mat,const rtvec* u)
{
	f64 tmp[DIM];
	const f64* me=mat->elem;
	for (u32 i=0;i<DIM;i++)
	{
		f64 s=0.0;
		for (u32 j=0;j<DIM;j++) {s+=(*me++)*u->elem[j];}
		tmp[i]=s;
	}
	memcpy(r->elem,tmp,sizeof(f64)*DIM);
}

//---------------------------------------------------------------------------------
// Rays
//---------------------------------------------------------------------------------

void rtrayprecalc(rtray* ray)
{
	ray->min=RT_EPS;
	ray->dot=RT_INF;
	ray->face=0;
	ray->facemat=0;
	// For AABB collision detection.
	f64* dir=ray->dir.elem;
	f64* inv=ray->inv.elem;
	ray->swap=0;
	for (u32 i=0;i<DIM;i++)
	{
		f64 d=dir[i];
		ray->swap|=(d<0.0)<<i;
		inv[i]=fabs(d)>1e-10?1.0/d:RT_INF;
	}
}

//---------------------------------------------------------------------------------
// Materials
//---------------------------------------------------------------------------------

rtmaterial* rtmatlcreate(void)
{
	rtmaterial* mat=rtalloc(sizeof(rtmaterial));
	memset(mat,0,sizeof(rtmaterial));
	return mat;
}

void rtmatlfree(rtmaterial* mat)
{
	rtfree(mat);
}

void rtmatlloadpy(rtmaterial* mat,PyObject* pymat)
{
	mat->pymap=rtpymapadd(pymat,mat,RT_TYPE_MATL);
	PyObject* pycolor=pygetobj(pymat,"color");
	for (u32 i=0;i<3;i++)
	{
		PyObject* obj=PyList_GetItem(pycolor,i);
		mat->color[i]=PyFloat_AsDouble(obj);
	}
	mat->luminosity=pygetf64(pymat,"luminosity");
	mat->reflectprob=pygetf64(pymat,"reflectprob");
	mat->diffusion=pygetf64(pymat,"diffusion");
	mat->refractprob=pygetf64(pymat,"refractprob");
	mat->refractindex=pygetf64(pymat,"refractindex");
	mat->refractinv=1.0/mat->refractindex;
	mat->scatterlen=pygetf64(pymat,"scatterlen");
	mat->absorbprob=pygetf64(pymat,"absorbprob");
}

//---------------------------------------------------------------------------------
// Faces
//---------------------------------------------------------------------------------

void rtvertloadpy(rtvert* vert,PyObject* pyvert)
{
	rtpymapadd(pyvert,vert,RT_TYPE_VERT);
	rtvecloadpyname(&vert->pos,pyvert,"pos");
}

void rtfaceloadpy(rtface* face,PyObject* pyface)
{
	rtpymapadd(pyface,face,RT_TYPE_FACE);
	// load vertices
	PyObject* pyvertarr=pygetobj(pyface,"vertarr");
	PyObject* pyvert=PyList_GetItem(pyvertarr,0);
	rtvert* vert=rtpymapget(pyvert);
	rtvecset(&face->off,&vert->pos);
	#ifdef RT_DIAGNOSTICS
		for (u32 i=0;i<DIM;i++)
		{
			pyvert=PyList_GetItem(pyvertarr,i);
			face->vertarr[i]=rtpymapget(pyvert);
		}
	#endif
	// load normal and barycentric vectors
	rtvecloadpyname(&face->norm,pyface,"norm");
	PyObject* pybaryarr=pygetobj(pyface,"bary");
	for (u32 i=0;i<DIM-1;i++)
	{
		PyObject* pybary=PyList_GetItem(pybaryarr,i);
		rtvecloadpy(&face->bary[i],pybary);
	}
	// load material
	PyObject* pymat=pygetobj(pyface,"mat");
	face->mat=rtpymapget(pymat);
	if (face->mat==0 && PyObject_IsTrue(pymat)==1)
	{
		face->mat=rtmatlcreate();
		rtmatlloadpy(face->mat,pymat);
	}
}

void rtfaceintersect(rtface* face,rtray* ray)
{
	#ifdef RT_DIAGNOSTICS
		rt_face_hit++;
	#endif
	// Return the distance from the ray origin to the face. Return false if the ray
	// misses.
	// First, project the ray onto the face's plane. We have (pos+u*dir)*norm=v0*norm,
	// thus u=-(pos-v0)*norm/(dir*norm).
	f64 dot=rtvecdot(&ray->dir,&face->norm);
	if (fabs(dot)<=1e-10) {return;}
	rtvec p;
	rtvecsub(&p,&ray->pos,&face->off);
	f64 dist=-rtvecdot(&p,&face->norm)/dot;
	// If the new distance is within +-eps, and the new face is more pointed away from
	// the ray, skip this new face.
	f64 min=ray->min,dif=dist-ray->max;
	if (dist<min || dif>min) {return;}
	if (dif>-min && dot>ray->dot) {return;}
	rtvecaddmul(&p,&p,&ray->dir,dist);
	// Make sure the barycentric coordinates of the point are within the face.
	f64 s=0.0;
	for (u32 i=0;i<DIM-1;i++)
	{
		f64 u=rtvecdot(face->bary+i,&p);
		s+=u;
		if (u<0.0 || s>1.0) {return;}
	}
	ray->max=dist;
	ray->dot=dot;
	ray->face=face;
	rtvecset(&ray->facenorm,&face->norm);
	ray->facemat=face->mat;
}

//---------------------------------------------------------------------------------
// Mesh Instances
//---------------------------------------------------------------------------------

void rtinstloadpy(rtinst* inst,PyObject* pyinst)
{
	inst->pymap=rtpymapadd(pyinst,inst,RT_TYPE_INST);
	// Find the target mesh. If it's not found, load it.
	PyObject* pymesh=pygetobj(pyinst,"mesh");
	inst->mesh=rtpymapget(pymesh);
	if (inst->mesh==0)
	{
		inst->mesh=rtmeshcreate();
		rtmeshloadpy(inst->mesh,pymesh);
	}
	// load any custom materials
	PyObject* pymatl=pygetobj(pyinst,"mat");
	inst->matl=rtpymapget(pymatl);
	if (inst->matl==0)
	{
		inst->matl=rtmatlcreate();
		rtmatlloadpy(inst->matl,pymatl);
	}
	// load the forward transform
	PyObject* pytrans=pygetobj(pyinst,"transform");
	rtmatloadpyname(&inst->transmat,pytrans,"mat");
	rtvecloadpyname(&inst->transoff,pytrans,"off");
	// load the inverse transform
	PyObject* pyinv=pygetobj(pyinst,"inv");
	rtmatloadpyname(&inst->invmat,pyinv,"mat");
	rtvecloadpyname(&inst->invoff,pyinv,"off");
}

void rtinstintersect(rtinst* inst,rtray* ray)
{
	// Apply the inverse instance transform to put the ray in the mesh's local space.
	// Don't normalize the direction here or distance metrics will be thrown off.
	rtray nray;
	rtvecmatmul(&nray.pos,&inst->invmat,&ray->pos);
	rtvecadd(&nray.pos,&nray.pos,&inst->invoff);
	rtvecmatmul(&nray.dir,&inst->invmat,&ray->dir);
	nray.max=ray->max;
	rtbvhraypick(inst->mesh->bvhroot,&nray);
	if (nray.face)
	{
		ray->max=nray.max;
		ray->face=nray.face;
		ray->facemat=nray.facemat;
		rtvecmatmul(&ray->facenorm,&inst->transmat,&nray.facenorm);
		rtvecnorm(&ray->facenorm,&ray->facenorm);
		if (inst->matl) {ray->facemat=inst->matl;}
	}
}

//---------------------------------------------------------------------------------
// Meshes
//---------------------------------------------------------------------------------

rtmesh* rtmeshcreate(void)
{
	rtmesh* mesh=rtalloc(sizeof(rtmesh));
	mesh->pymap=0;
	mesh->verts=0;
	mesh->vertarr=0;
	mesh->faces=0;
	mesh->facearr=0;
	mesh->insts=0;
	mesh->instarr=0;
	mesh->bvhnodes=0;
	mesh->bvhnodearr=0;
	mesh->bvhroot=0;
	return mesh;
}

void rtmeshfree(rtmesh* mesh)
{
	rtpymapnofree(mesh->pymap);
	rtfree(mesh->bvhnodearr);
	rtfree(mesh->instarr);
	rtfree(mesh->facearr);
	rtfree(mesh->vertarr);
	rtfree(mesh);
}

void rtmeshloadpy(rtmesh* mesh,PyObject* pymesh)
{
	// add to map
	mesh->pymap=rtpymapadd(pymesh,mesh,RT_TYPE_MESH);
	// load vertices
	mesh->verts=pygets32(pymesh,"verts");
	rtprint("verts: %d\n",mesh->verts);
	mesh->vertarr=rtalloc(sizeof(rtvert)*mesh->verts);
	PyObject* pyvertarr=pygetobj(pymesh,"vertarr");
	for (s32 i=0;i<mesh->verts;i++)
	{
		rtvert* vert=mesh->vertarr+i;
		PyObject* pyvert=PyList_GetItem(pyvertarr,i);
		rtvertloadpy(vert,pyvert);
	}
	// load all faces
	//      err if vert not found
	//      load material if not in map
	mesh->faces=pygets32(pymesh,"faces");
	rtprint("faces: %d\n",mesh->faces);
	mesh->facearr=rtalloc(sizeof(rtface)*mesh->faces);
	PyObject* pyfacearr=pygetobj(pymesh,"facearr");
	for (s32 i=0;i<mesh->faces;i++)
	{
		rtface* face=mesh->facearr+i;
		PyObject* pyface=PyList_GetItem(pyfacearr,i);
		rtfaceloadpy(face,pyface);
	}
	// load all insts
	//      load mesh if not in map
	mesh->insts=pygets32(pymesh,"insts");
	rtprint("insts: %d\n",mesh->insts);
	mesh->instarr=rtalloc(sizeof(rtinst)*mesh->insts);
	PyObject* pyinstarr=pygetobj(pymesh,"instarr");
	for (s32 i=0;i<mesh->insts;i++)
	{
		rtinst* inst=mesh->instarr+i;
		PyObject* pyinst=PyList_GetItem(pyinstarr,i);
		rtinstloadpy(inst,pyinst);
	}
	// load bvh
	//      use python to determine type
	PyObject_CallMethod(pymesh,"buildbvh",NULL);
	PyObject* pybvh=pygetobj(pymesh,"bvh");
	mesh->bvhnodes=pygets32(pybvh,"nodes");
	mesh->bvhnodearr=rtbvhloadpyarr(pybvh,mesh->bvhnodes);
	mesh->bvhroot=rtpymapget(pygetobj(pybvh,"root"));
}

//---------------------------------------------------------------------------------
// BVH
//---------------------------------------------------------------------------------

#define RT_BVH_DIVIDE 0
#define RT_BVH_FACE   1
#define RT_BVH_INST   2

void rtbvhnodeloadpy(rtbvhnode* node,PyObject* pynode)
{
	// load parent/child links for later mapping
	rtpymapadd(pynode,node,RT_TYPE_BVH);
	// node->parent=(rtbvhnode*)pygetobj(pynode,"parent");
	node->left=(void*)pygetobj(pynode,"left");
	node->right=(void*)pygetobj(pynode,"right");
	PyObject* pynextarr=pygetobj(pynode,"next");
	for (s32 i=0;i<(1<<DIM);i++)
	{
		node->next[i]=(void*)PyList_GetItem(pynextarr,i);
	}
	rtvecloadpyname(&node->bbmin,pynode,"bbmin");
	rtvecloadpyname(&node->bbmax,pynode,"bbmax");
	node->type=(u8)pygets32(pynode,"type");
	node->axis=(u8)pygets32(pynode,"axis");
	node->testray=(u8)pygets32(pynode,"testray");
}

rtbvhnode* rtbvhloadpyarr(PyObject* pybvh,s32 nodes)
{
	rtbvhnode* nodearr=rtalloc(sizeof(rtbvhnode)*nodes);
	PyObject* pybvhnodearr=pygetobj(pybvh,"nodearr");
	for (s32 i=0;i<nodes;i++)
	{
		PyObject* pybvhnode=PyList_GetItem(pybvhnodearr,i);
		rtbvhnodeloadpy(nodearr+i,pybvhnode);
	}
	for (s32 i=0;i<nodes;i++)
	{
		rtbvhnode* node=nodearr+i;
		// node->parent=rtpymapget((PyObject*)node->parent);
		node->left=rtpymapget((PyObject*)node->left);
		node->right=rtpymapget((PyObject*)node->right);
		for (u32 j=0;j<(1<<DIM);j++)
		{
			node->next[j]=rtpymapget((PyObject*)node->next[j]);
		}
	}
	return nodearr;
}

u32 rtbvhnodeintersect(rtbvhnode* node,rtray* ray)
{
	// Project the box onto the ray. The intersection of all projections will give us
	// the range of u where the ray intersects the box. If the intersection of all the
	// ranges is null, then the ray misses the box.
	//
	//             b3
	//              '. b2
	//              . '.              ray=pos+u*dir
	//              .  .'.            ranges: [b0,b1] [b2,b3]
	//              .  .  '.
	//      +----------+. . '.b1
	//      |          |      '.
	//      |          |        '.
	//      |          |          '.
	//      |          |            '.
	//      +----------+. . . . . . . '.b0
	//
	// Want pos[i]+u*dir[i]=box[i], thus u=(box[i]-pos[i])/dir[i].
	// We spend almost half of our time in this function, so optimize it.
	#ifdef RT_DIAGNOSTICS
		rt_bvh_hit++;
	#endif
	f64 *raypos=ray->pos.elem,*rayinv=ray->inv.elem;
	f64 *bbmin=node->bbmin.elem,*bbmax=node->bbmax.elem;
	f64 u0=ray->min,u1=ray->max;
	#if DIM==3
		#define intersect(i,x,y)\
			p=raypos[i];\
			d=rayinv[i];\
			x=(bbmin[i]-p)*d;\
			y=(bbmax[i]-p)*d;\
			u0=u0<b0?b0:u0;\
			u1=u1>b1?b1:u1;
		#define intersect3(x0,y0,x1,y1,x2,y2)\
			intersect(0,x0,y0)\
			intersect(1,x1,y1)\
			intersect(2,x2,y2)
		f64 p,d,b0,b1;
		switch (ray->swap)
		{
			case 0:
				intersect3(b0,b1,b0,b1,b0,b1)
				break;
			case 1:
				intersect3(b1,b0,b0,b1,b0,b1)
				break;
			case 2:
				intersect3(b0,b1,b1,b0,b0,b1)
				break;
			case 3:
				intersect3(b1,b0,b1,b0,b0,b1)
				break;
			case 4:
				intersect3(b0,b1,b0,b1,b1,b0)
				break;
			case 5:
				intersect3(b1,b0,b0,b1,b1,b0)
				break;
			case 6:
				intersect3(b0,b1,b1,b0,b1,b0)
				break;
			case 7:
				intersect3(b1,b0,b1,b0,b1,b0)
				break;
			default:
				break;
		}
		#undef intersect3
		#undef intersect
	#else
		for (u32 i=0;i<DIM;i++)
		{
			f64 p=raypos[i];
			f64 d=rayinv[i];
			f64 b0=(bbmin[i]-p)*d;
			f64 b1=(bbmax[i]-p)*d;
			if (b0>b1) {d=b0;b0=b1;b1=d;}
			u0=u0<b0?b0:u0;
			u1=u1>b1?b1:u1;
			// if (u0>u1) {return 0;}
		}
	#endif
	// return 1;
	return u0<=u1;
}

void rtbvhraypick(rtbvhnode* root,rtray* ray)
{
	// Finds the nearest surface that the ray intersects. Surface information is
	// returned in the ray object.
	rtbvhnode *node=0,*next=root;
	rtrayprecalc(ray);
	u8 swap=ray->swap;
	while (next)
	{
		rtbvhnode* prev=node;
		node=next;
		next=node->parent;
		u32 down=prev==next;
		// Check if we're intersecting the current node.
		if (down && node->testray && rtbvhnodeintersect(node,ray)==0)
		{
			continue;
		}
		void *left=node->left,*right=node->right,*tmp;
		switch (node->type)
		{
			case RT_BVH_DIVIDE:
				// This is a dividing node. Determine which child to visit first using the dividing
				// axis and sign of the ray. Note that a better heuristic won't greatly help here.
				if (swap&node->axis) {tmp=left;left=right;right=tmp;}
				if (down) {next=left;}
				else if (prev==left) {next=right;}
				break;
			case RT_BVH_FACE:
				// We are intersecting a mesh face.
				rtfaceintersect(left,ray);
				break;
			case RT_BVH_INST:
				// We are intersecting a mesh instance.
				rtinstintersect(left,ray);
			default:
				break;
		}
	}
}

//---------------------------------------------------------------------------------
// Scene
//---------------------------------------------------------------------------------

rtscene* rtscenecreate(s32 dim,s32 imgwidth,s32 imgheight)
{
	rtassert(dim==DIM);
	rtscene* scene=rtalloc(sizeof(rtscene));
	memset(scene,0,sizeof(rtscene));
	scene->pymap=0;
	scene->raysperpixel=128;
	scene->maxbounces=16;
	scene->dim=dim;
	scene->imgwidth=imgwidth;
	scene->imgheight=imgheight;
	scene->imgpixels=imgwidth*imgheight;
	u32 size=imgwidth*imgheight*3*sizeof(f64);
	scene->imgrgb=rtalloc(size);
	memset(scene->imgrgb,0,size);
	scene->mesh=rtmeshcreate();
	return scene;
}

void rtscenefree(rtscene* scene)
{
	rtpymapnofree(scene->pymap);
	rtmeshfree(scene->mesh);
	rtfree(scene->imgrgb);
	rtfree(scene);
}

void rtsceneloadpy(rtscene* scene,PyObject* pyscene)
{
	scene->pymap=rtpymapadd(pyscene,scene,RT_TYPE_SCENE);
	s32 imgwidth=pygets32(pyscene,"imgwidth");
	s32 imgheight=pygets32(pyscene,"imgheight");
	scene->raysperpixel=pygets32(pyscene,"raysperpixel");
	scene->maxbounces=pygets32(pyscene,"maxbounces");
	scene->dim=pygets32(pyscene,"dim");
	rtassert(scene->dim==DIM);
	scene->imgwidth=imgwidth;
	scene->imgheight=imgheight;
	scene->imgpixels=imgwidth*imgheight;
	u32 size=imgwidth*imgheight*3*sizeof(f64);
	rtfree(scene->imgrgb);
	scene->imgrgb=rtalloc(size);
	memset(scene->imgrgb,0,size);
	rtvecloadpyname(&scene->campos,pyscene,"campos");
	rtvecloadpyname(&scene->cambl ,pyscene,"cambl");
	rtvecloadpyname(&scene->camu  ,pyscene,"camu");
	rtvecloadpyname(&scene->camv  ,pyscene,"camv");
	rtmeshloadpy(scene->mesh,pygetobj(pyscene,"mesh"));
}

void rtsceneraytrace(rtscene* scene,rtray* ray,f64* rgb)
{
	// Shoot a ray into the scene, and follow it as it bounces around. Track what
	// material we're inside of for ambient properties of the medium.
	// Situations to consider:
	//      Coplanar faces will be fairly common.
	//      Rays may start inside a mesh.
	//      Inside-out geometry will define an infinitely large space.
	rtvec tmpvec0;
	rtvec* tmpvec=&tmpvec0;
	rtmaterial* ambient=0;
	f64 col[3]={1.0,1.0,1.0};
	f64 ret[3]={0.0,0.0,0.0};
	rtvec* pos=&ray->pos;
	rtvec* dir=&ray->dir;
	rtbvhnode* bvhroot=scene->mesh->bvhroot;
	for (s32 bounce=scene->maxbounces;bounce>0;bounce--)
	{
		#ifdef RT_DIAGNOSTICS
			rt_ray_count++;
		#endif
		// Perform scattering before interacting with the face. Use the Beer-Lambert
		// scattering law to limit scattering length.
		f64 scatterlen=ambient?ambient->scatterlen:RT_INF;
		if (scatterlen<RT_INF) {scatterlen*=-log(rtrandf());}
		ray->max=scatterlen;
		// Find the closest face the ray collides with. If we can't find one, or the ray
		// gets absorbed, abort.
		rtbvhraypick(bvhroot,ray);
		f64 dist=ray->max;
		if (dist>=RT_INF) {break;}
		rtvec* norm=&ray->facenorm;
		rtmaterial* mat=ray->facemat;
		if (mat==0) {mat=ambient;}
		if (mat==0) {break;}
		if (rtrandf()<mat->absorbprob) {break;}
		f64 cosi=ray->face==0?0.0:rtvecdot(dir,norm);
		s32 inside=cosi>0.0;
		if (bounce==inside) {break;}
		// If we didn't hit anything or scatter, we escape into the void.
		rtvecaddmul(pos,pos,dir,dist);
		// If we're performing subsurface scattering, randomly bounce around.
		if (dist>=scatterlen)
		{
			rtvecrand(dir);
			continue;
		}
		if (inside)
		{
			// We're inside and pointing out.
			rtvecneg(norm,norm);
			ambient=mat;
		}
		else
		{
			// We're outside and pointing in.
			cosi=-cosi;
			f64* matcol=mat->color;
			f64 matlum=mat->luminosity;
			for (u32 i=0;i<3;i++)
			{
				col[i]*=matcol[i];
				ret[i]+=matlum*col[i];
			}
		}
		u32 refract=0;
		f64 cost,ior;
		if (rtrandf()<mat->refractprob)
		{
			// Perform refraction and determine if we have total internal reflection.
			ior=inside?mat->refractindex:mat->refractinv;
			f64 disc=1.0-ior*ior*(1.0-cosi*cosi);
			if (disc>0.0)
			{
				cost=sqrt(disc);
				// Fresnel reflectance equations.
				f64 a=ior*cost;
				f64 rs=(cosi-a)/(cosi+a);
				a=ior*cosi;
				f64 rp=(a-cost)/(a+cost);
				f64 prob=1.0-(rs*rs+rp*rp)*0.5;
				refract=rtrandf()<prob;
			}
		}
		if (refract)
		{
			// Refraction.
			rtvecscale(dir,dir,ior);
			rtvecaddmul(dir,dir,norm,ior*cosi-cost);
			ambient=inside?0:mat;
		}
		else if (rtrandf()<mat->reflectprob)
		{
			// Lambertian scattering.
			rtvecrand(tmpvec);
			if (rtvecdot(tmpvec,norm)<0.0) {rtvecneg(tmpvec,tmpvec);}
			rtvecaddmul(dir,dir,norm,2.0*cosi);
			rtvecsub(tmpvec,tmpvec,dir);
			rtvecaddmul(dir,dir,tmpvec,mat->diffusion);
		}
		rtvecnorm(dir,dir);
	}
	for (u32 i=0;i<3;i++) {rgb[i]+=ret[i];}
}

void rtscenerender(rtscene* scene,u32 printprog)
{
	u32 rpp=scene->raysperpixel;
	f64 norm=rpp<1?0.0:1.0/rpp;
	rtvec* campos=&scene->campos;
	rtvec* cambl=&scene->cambl;
	rtvec* camu=&scene->camu;
	rtvec* camv=&scene->camv;
	s32 imgwidth=scene->imgwidth;
	s32 pixels=scene->imgpixels;
	u32 prog=printprog>0?(pixels+9999)/10000:0;
	// MSVC complains about variable declarations in the for loop.
	s32 i;
	#pragma omp parallel for schedule(dynamic,1)
	for (i=0;i<pixels;i++)
	{
		// Print progress.
		if (prog && (i%prog)==0)
		{
			printf("\rprogress: %.2f%%",i*100.0/pixels);
			fflush(stdout);
		}
		f64 x=i%imgwidth;
		f64 y=i/imgwidth;
		f64* rgb=scene->imgrgb+i*3;
		memset(rgb,0,3*sizeof(f64));
		rtray ray;
		rtvec *raypos=&ray.pos,*raydir=&ray.dir;
		for (u32 r=0;r<rpp;r++)
		{
			f64 u=x+rtrandf(),v=y+rtrandf();
			rtvecset(raypos,campos);
			rtvecaddmul(raydir,cambl ,camu,u);
			rtvecaddmul(raydir,raydir,camv,v);
			rtvecnorm(raydir,raydir);
			rtsceneraytrace(scene,&ray,rgb);
		}
		for (u32 j=0;j<3;j++) {rgb[j]*=norm;}
	}
	if (prog) {printf("\rprogress: 100.00%%\n");}
}

static PyObject* render(PyObject* self,PyObject* args)
{
	// Disable unused variable warning.
	((void)self);
	// Load and render scene.
	PyObject* pyscene;
	int progress;
	PyArg_ParseTuple(args,"Op",&pyscene,&progress);
	rtscene* scene=rtscenecreate(DIM,0,0);
	rtsceneloadpy(scene,pyscene);
	rtscenerender(scene,progress);
	// Transfer pixels to python.
	PyObject* pyrgb=pygetobj(pyscene,"imgrgb");
	u32 rgb=scene->imgwidth*scene->imgheight*3;
	for (u32 i=0;i<rgb;i++)
	{
		PyObject* obj=PyFloat_FromDouble(scene->imgrgb[i]);
		PyList_SetItem(pyrgb,i,obj);
	}
	// Clean up.
	rtscenefree(scene);
	rtpymapfree();
	rtprint("face: %lld\n",rt_face_hit);
	rtprint("bvh : %lld\n",rt_bvh_hit);
	rtprint("rays: %lld\n",rt_ray_count);
	rtprint("mem : %lld\n",rt_alloc_count);
	rtassert(rt_alloc_count==0);
	Py_RETURN_NONE;
}

