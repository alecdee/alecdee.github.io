import sys,time
from RayTracer import *

def to2d(p):
	# bl+u*right+v*up=p
	# bl=(0,0,1)
	# right=(1,0,0)
	# up=(0,1,0)
	# want pos+w*(z+u*x+v*z)=p for some w
	# pos=(0,0,0)
	# set w*z=pz
	# w=pz/z=pz
	# u*x*pz=px
	# u=px/pz
	# v=py/pz
	return Vector((p[0]/p[2],p[1]/p[2]))

def addline(a,b,args=""):
	if args: args=" "+args
	fmt="\t<line x1=\"{0:.0f}\" y1=\"{1:.0f}\" x2=\"{2:.0f}\" y2=\"{3:.0f}\""+args+"/>\n"
	return fmt.format(*a,*b)

def addarrow(a,b,l):
	turn=math.pi*40.0/360.0
	dif=b-a
	ang=math.atan2(dif[1],dif[0])
	# s=" stroke=
	fmt="\t<line x1=\"{0:.0f}\" y1=\"{1:.0f}\" x2=\"{2:.0f}\" y2=\"{3:.0f}\"/>\n"
	arr0=b-Vector((math.cos(ang-turn),math.sin(ang-turn)))*l
	arr1=b-Vector((math.cos(ang+turn),math.sin(ang+turn)))*l
	return fmt.format(*a,*b)+fmt.format(*arr0,*b)+fmt.format(*arr1,*b)

def addcircle(p,r,args=""):
	if args: args=" "+args
	fmt="\t<circle cx=\"{0:.0f}\" cy=\"{1:.0f}\" r=\"{2:.0f}\""+args+"/>\n"
	return fmt.format(*p,r)

def image1():
	ret="<svg version=\"1.1\" viewBox=\"0 0 1000 500\" class=\"diagram\">\n"
	cen=Vector((0,0))
	for i in range(6):
		ang=math.pi*i/6.0
		v=Vector((math.cos(ang),math.sin(ang)))*80
		ret+=addline(cen+v,cen-v)
	ret+=addcircle(cen,25,'fill="#000000" stroke="#f0f0f0" stroke-width="4px"')
	ret+=addline((500,0),(500,1000))
	# a=Vector((0,0))
	# b=Vector((100,100))
	# ret+=addarrow(a,b,20)
	ret+="</svg>"
	print(ret)

def image2():
	ret="<svg version=\"1.1\" viewBox=\"0 0 1000 500\" class=\"diagram\">\n"
	ul=Vector((100,50))
	w,h=Vector((300,0)),Vector((0,150))
	for i in range(2):
		u=i/1.0
		ret+=addline(ul+w*u,ul+w*u+h)
		ret+=addline(ul+h*u,ul+h*u+w)
	ul2=Vector((0,0))
	ul3=Vector((-100,-75,2))
	w,h=Vector((200,0,-1)),Vector((0,150,0))
	for i in range(7):
		u=i/6.0
		a,b=to2d(ul3+w*u),to2d(ul3+w*u+h)
		ret+=addline(ul2+a,ul2+b)
		a,b=to2d(ul3+h*u),to2d(ul3+h*u+w)
		ret+=addline(ul2+a,ul2+b)
	ret+="</svg>"
	print(ret)

def image3():
	ret="<svg version=\"1.1\" viewBox=\"0 0 1000 500\" class=\"diagram\">\n"
	rot=Matrix(3,3).one().rotate((0,1,0))*100
	off=Vector((0,1,0))
	vert=[(0,0),(0.2,-0.4),(1,0),(1.2,-0.4),
	      (0,-1),(0.2,-1.4),(1,-1),(1.2,-1.4)]
	for i in range(8):
		vert[i]=Vector(vert[i])*130
	# for i in range(8):
	# 	arr=[((i>>j)&1)-0.5 for j in range(3)]
	# 	a,b,c=[((i>>j)&1)-0.5 for j in range(3)]
	# 	arr=[a*100+b*30+15,b*100+c
	# 	print((rot*Vector(arr)+off).elem)
	# 	vert+=[(rot*Vector(arr)+off)[:2]]
	"""
		5_____________7
		/|           /|
	    / |          / |
	   /  |         /  |
	 4+------------+6  |
	  |   |        |   |
	  |   |        |   |
	  | 1 |________|___|3
	  |  /         |  /
	  | /          | /
	  |/           |/
	  +------------+
	 0              2
	"""
	edges=((0,1),(1,3),(3,2),(2,0),
	       (4,5),(5,7),(7,6),(6,4),
	       (0,4),(1,5),(2,6),(3,7),
	       (0,3),(4,7),(0,6),(2,7),
	       (3,5),(1,4)
	)
	for v in vert:
		ret+=addcircle(v,5)
	for e in edges:
		a,b=vert[e[0]],vert[e[1]]
		ret+=addline(a,b)
	ret+="</svg>"
	print(ret)

def image4():
	# sphere refraction
	cen=Vector([0,0])
	rad=80
	ior=1.2
	ret=""
	def collide(p,dir,mul):
		# (pos+u*dir-cen)^2=rad^2
		# p=pos-cen
		# (p+u*dir)^2=rad^2
		# u^2+u*(2*p*dir)+(p*p-rad^2)=0
		# u=(-(2*p*dir)+-sqrt((2*p*dir)^2-4*(p*p-rad^2)))/2
		p=p-cen
		u=-(p*dir)+mul*math.sqrt((p*dir)**2-(p*p-rad**2))
		return u*dir
	def refract(p,dir):
		norm=(p-cen).normalize()
		cosi=dir*norm
		tor=ior
		if cosi>0.0:
			norm=-norm
		else:
			cosi=-cosi
			tor=1.0/ior
		disc=1.0-tor*tor*(1.0-cosi*cosi)
		cost=math.sqrt(disc)
		return (tor*dir+(tor*cosi-cost)*norm).normalize()
	ret=addcircle(cen,rad,"fill=\"#ffffff\"")
	args="stroke=\"#a0a000\""
	for i in range(4):
		p0=Vector([-150,-60+120.0*i/3.0])
		dir=Vector([1,0])
		p1=p0+collide(p0,dir,-1)
		ret+=addline(p0,p1,args)
		dir=refract(p1,dir)
		p2=p1+collide(p1,dir,1)
		ret+=addline(p1,p2,args)
		dir=refract(p2,dir)
		p3=p2+dir*((150.0-p2[0])/dir[0])
		ret+=addline(p2,p3,args)
	print(ret)

def image5():
	# star
	ret=""
	vert=[]
	for i in range(10):
		ang=math.pi*2*(i-0.5)/10.0
		rad=8 if i&1 else 20
		vert+=[(math.cos(ang)*rad,math.sin(ang)*rad)]
	for i in range(10):
		a,b=vert[i],vert[(i+1)%10]
		ret+=addline(a,b)
	print(ret)

def image6():
	# bounding types
	ret=""
	for i in range(30):
		x=(random.random()-0.5)*120
		y=(random.random()-0.5)*120
		ret+=addcircle((x,y),3)
	print(ret)

def image7():
	# circle subdivision
	ret="<svg version=\"1.1\" viewBox=\"0 0 1000 300\" class=\"diagram\">\n"
	rad=80.0
	for sub in range(3):
		ret+="<g transform=\"translate({0},150)\">\n".format(200+sub*300)
		ret+=addcircle((0,0),rad,"class=\"highstroke bgfill\"")
		m=RayTracer.Mesh(2)
		m.addsphere([0]*2,1.0,1<<(2+sub),None)
		larr=[]
		for i in range(m.faces):
			f=m.facearr[i]
			larr.append(sorted([v.id for v in f.vertarr]))
		larr.sort()
		larr=[larr[i] for i in range(len(larr)) if i==0 or larr[i]!=larr[i-1]]
		for i in range(m.verts):
			v=m.vertarr[i].pos
			v[0]=v[0]*rad
			v[1]=v[1]*rad
		for l in larr:
			v0=m.vertarr[l[0]].pos
			v1=m.vertarr[l[1]].pos
			ret+=addline(v0,v1)
		for i in range(m.verts):
			v=m.vertarr[i].pos
			ret+=addcircle(v,3)
		ret+="</g>\n"
	ret+="</svg>"
	print(ret)

def image8():
	# sphere subdivision
	ret="<svg version=\"1.1\" viewBox=\"0 0 1000 300\" class=\"diagram\">\n"
	rad=80.0
	for sub in range(3):
		ret+="<g transform=\"translate({0},150)\">\n".format(200+sub*300)
		m=RayTracer.Mesh(3)
		m.addsphere([0]*3,1.0,1<<(3+2*sub),None)
		m.buildbvh()
		larr=[]
		for i in range(m.faces):
			f=m.facearr[i]
			for j in range(3):
				for k in range(j):
					v0=f.vertarr[j]
					v1=f.vertarr[k]
					# if v0.pos[2]>=0.0 and v1.pos[2]>=0.0:
					larr.append(sorted([v0.id,v1.id]))
		larr.sort()
		larr=[larr[i] for i in range(len(larr)) if i==0 or larr[i]!=larr[i-1]]
		trans=RayTracer.Transform([0,0,-2],[0.0,-0.2,0.2])
		for i in range(m.verts):
			v=m.vertarr[i]
			v.show=v.pos[2]>=0.0
			v.pos=to2d(trans.apply(v.pos))*rad*2
		for l in larr:
			v0=m.vertarr[l[0]]
			v1=m.vertarr[l[1]]
			if v0.show==0 and v1.show==0:
				ret+=addline(v0.pos,v1.pos,"class=\"dimstroke\"")
		for i in range(m.verts):
			v=m.vertarr[i]
			if v.show==0: ret+=addcircle(v.pos,3,"class=\"dimstroke dimfill\"")
		for l in larr:
			v0=m.vertarr[l[0]]
			v1=m.vertarr[l[1]]
			if v0.show or v1.show:
				ret+=addline(v0.pos,v1.pos)
		for i in range(m.verts):
			v=m.vertarr[i]
			if v.show: ret+=addcircle(v.pos,3)
		ret+="</g>\n"
	ret+="</svg>"
	print(ret)

def image9():
	# 1D line to 2D circle rotation.
	ret="<svg version=\"1.1\" viewBox=\"0 0 1000 300\" class=\"diagram\">\n"
	rad=80.0
	pi=math.pi
	segs=12
	segarc=2*math.pi/segs
	m=Mesh(2)
	m.addsphere([0]*2,1.0,segs,None)
	for sub in range(4):
		ret+="<g transform=\"translate({0},150)\">\n".format(100+sub*266)
		ret+=addcircle((0,0),rad,"class=\"dimstroke bgfill\"")
		sec=(0,1,2,segs)[sub]*segarc+0.01
		if sub<3:
			ang=segarc*sub
			x=math.cos(ang)*rad
			y=math.sin(ang)*rad
			ret+=addline((x,y),(-x,-y),"class=\"highstroke\"")
		for i in range(m.verts):
			v=m.vertarr[i]
			ang=math.atan2(v.pos[1],v.pos[0])+pi
			if 2*pi-ang<1e-5: ang=0.0
			v.display=ang<sec or (ang>=pi and ang<pi+sec)
			v.highlight=abs(ang-sec)<0.1*segarc
			if abs(ang-(pi+sec))<0.1*segarc: v.highlight=True
			if sub==3: v.highlight=False
		for i in range(m.faces):
			f=m.facearr[i]
			v0,v1=f.vertarr
			if v0.display and v1.display:
				ret+=addline(v0.pos*rad,v1.pos*rad)
		for i in range(m.verts):
			v=m.vertarr[i]
			if v.display:
				args=""
				if v.highlight: args="class=\"highstroke highfill\""
				ret+=addcircle(v.pos*rad,3,args)
		ret+="</g>\n"
	ret+="</svg>"
	print(ret)

def image10():
	# 2D line to 3D circle rotation.
	ret="<svg version=\"1.1\" viewBox=\"0 0 1000 300\" class=\"diagram\">\n"
	rad=80.0
	pi=math.pi
	segs=12
	segarc=2*math.pi/segs
	faces=segs*segs
	trans=Transform([0,-0.1,-2],[0.0,-0.2+pi*0.5,0.0+pi*0.5])
	for sub in range(4):
		m=Mesh(3)
		m.addsphere([0]*3,1.0,faces,None)
		m.buildbvh()
		ret+="<g transform=\"translate({0},150)\">\n".format(100+sub*266)
		sec=(0,1,2,segs)[sub]*segarc+0.01
		for i in range(m.verts):
			v=m.vertarr[i]
			x,y=v.pos[1],v.pos[2]
			ang=math.atan2(y,x)+pi
			if 2*pi-ang<1e-5: ang=0.0
			if x*x+y*y<1e-2: ang=sec
			v.display=ang<=sec or (ang>=pi and ang<=pi+sec)
			v.highlight=abs(ang-sec)<0.1*segarc
			if abs(ang-(pi+sec))<0.1*segarc: v.highlight=True
			if sub==3: v.highlight=False
		larr=[]
		for i in range(m.faces):
			f=m.facearr[i]
			for j in range(3):
				for k in range(j):
					v0=f.vertarr[j]
					v1=f.vertarr[k]
					# if v0.pos[2]>=0.0 and v1.pos[2]>=0.0:
					if v0.display and v1.display:
						larr.append(sorted([v0.id,v1.id]))
		larr.sort()
		larr=[larr[i] for i in range(len(larr)) if i==0 or larr[i]!=larr[i-1]]
		for i in range(m.verts):
			v=m.vertarr[i]
			pos=trans.apply(v.pos)
			v.front=pos[2]>=-2
			v.pos=to2d(pos)*rad*2
		for l in larr:
			v0=m.vertarr[l[0]]
			v1=m.vertarr[l[1]]
			if v0.front==0 or v1.front==0:
				args="class=\"dimstroke\""
				if v0.highlight and v1.highlight: args="class=\"highstroke\""
				ret+=addline(v0.pos,v1.pos,args)
		for i in range(m.verts):
			v=m.vertarr[i]
			if v.display and v.front==0:
				args="class=\"dimstroke dimfill\""
				if v.highlight: args="class=\"highstroke highfill\""
				ret+=addcircle(v.pos,3,args)
		for l in larr:
			v0=m.vertarr[l[0]]
			v1=m.vertarr[l[1]]
			if v0.front and v1.front:
				args=""
				if v0.highlight and v1.highlight: args="class=\"highstroke\""
				ret+=addline(v0.pos,v1.pos,args)
		for i in range(m.verts):
			v=m.vertarr[i]
			if v.display and v.front:
				args=""
				if v.highlight: args="class=\"highstroke highfill\""
				ret+=addcircle(v.pos,3,args)
		ret+="</g>\n"
	ret+="</svg>"
	print(ret)

# image1()
# image2()
# image3()
# image4()
# image5()
# image6()
# image7()
# image8()
image9()
# image10()

