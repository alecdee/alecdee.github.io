"""
Weight balanced tree testing functions.

worst case = ln( 2 ) / ln( 1 + 1/ratio )


"""

import time,random,math
from SBTree import SBTree


def SBInvariantTest():
	#Create a left leaning tree that satisfies a given invariant. Then unbalance the
	#tree by adding or removing a single node, restore balance, and check that the
	#invariant is maintained.
	#
	#         A
	#        / \
	#       B   z
	#      / \
	#     y   C
	#        / \
	#       x   w
	#
	#Results:
	#
	#     3 1 3 -1 / 1
	#     3 1 3  0 / 1
	#     5 2 5  0 / 2
	#     5 2 5  1 / 2
	#     5 2 5  2 / 2

	def WeightBounds(weight):
		#Want weight*mul+con>=x*den and x*mul+con>=weight*den
		#That is: given a weight, find the inclusive bounds of x, [min,max].
		min=weight*den-pcon+pmul-1
		min= 0 if min<0 else min//pmul
		max=weight*pmul+pcon
		if max<0:
			max=-1 if max<-den else 0
		else:
			max//=den
		#if min>max: min,max=None,None
		#Sanity checks.
		assert(min<=0 or min*pmul+pcon>=weight*den)
		assert(min<=0 or (min-1)*pmul+pcon<weight*den)
		assert(max<=0 or weight*pmul+pcon>=max*den)
		assert(max<=0 or weight*pmul+pcon<(max+1)*den)
		return (min,max)

	def PInvariant(lw,rw):
		#Return true if lw or rw violate the primary invariant.
		return lw<0 or rw<0 or lw*pmul+pcon<rw*den or rw*pmul+pcon<lw*den

	den=1
	wmax=30

	#Primary invariant constant bounds.
	pmulmin=1
	pmulmax=3*den
	pmuldif=pmulmax-pmulmin+1
	pconmin=-4*den
	pconmax=4*den
	pcondif=pconmax-pconmin+1

	#Secondary invariant constant bounds. Used to determine single/double rotation.
	smulmin=1
	smulmax=4*den
	smuldif=smulmax-smulmin+1
	sconmin=-4*den
	sconmax=4*den
	scondif=sconmax-sconmin+1

	params=pmuldif*pcondif*smuldif*scondif
	print("testing {0} parameters\n".format(params))
	passed=0
	for param in range(params):

		#Calculate actual invariants to test.
		param0=param
		scon=param0%scondif+sconmin
		param0//=scondif
		smul=param0%smuldif+smulmin
		param0//=smuldif
		pcon=param0%pcondif+pconmin
		param0//=pcondif
		pmul=param0+pmulmin
		#print(pmul,pcon,smul,scon)
		count=0
		err=False

		#We want trees with two descendants to be perfectly balanced.
		if not PInvariant(0,2): err=True

		for wweight in range(0,wmax+1):

			xmin,xmax=WeightBounds(wweight)
			if xmin>xmax: err=True
			if err: break
			for xweight in range(xmin,xmax+1):

				cweight=xweight+wweight+1
				ymin,ymax=WeightBounds(cweight)
				if ymin>ymax: err=True
				if err: break
				for yweight in range(ymin,ymax+1):

					bweight=yweight+cweight+1
					zmin,zmax=WeightBounds(bweight)
					if zmin>zmax: err=True
					if err: break
					#We don't need to check the entire range of z; only it's minimum.
					zweight=zmin

					aweight=bweight+zweight+1

					for add in range(4):
						if err: break
						ww,xw,yw,zw=wweight,xweight,yweight,zweight

						#Remove a node from z, or add a node to w, x, or y.
						if   add==0 and zw>0: zw-=1
						elif add==1: ww+=1
						elif add==2: xw+=1
						elif add==3: yw+=1
						cw=xw+ww+1
						bw=yw+cw+1
						aw=bw+zw+1
						if   PInvariant(ww,xw): continue
						elif PInvariant(yw,cw): continue

						#Rebalance.
						if zw*pmul+pcon<bw*den:
							if yw*smul+scon<bw*den:
								#Left rotate B, then right rotate A.
								#
								#         A               C
								#        / \             / \
								#       B   z           /   \
								#      / \      ->     B     A
								#     y   C           / \   / \
								#        / \         y   x w   z
								#       x   w
								#
								bw=xw+yw+1
								aw=ww+zw+1
								cw=aw+bw+1
								if   PInvariant(xw,yw): err=True
								elif PInvariant(ww,zw): err=True
								elif PInvariant(aw,bw): err=True
							else:
								#Right rotate A.
								#
								#         A            B
								#        / \          / \
								#       B   z        y   A
								#      / \      ->      / \
								#     y   C            C   z
								#        / \          / \
								#       x   w        x   w
								#
								aw=cw+zw+1
								bw=yw+aw+1
								if   PInvariant(xw,ww): err=True
								elif PInvariant(cw,zw): err=True
								elif PInvariant(yw,aw): err=True
						elif bw*pmul+pcon<zw*den:
							err=True
						else:
							#No need to rebalance.
							if   PInvariant(xw,ww): err=True
							elif PInvariant(yw,cw): err=True
							elif PInvariant(bw,zw): err=True
						count+=1

		if count and not err:
			passed+=1
			print(pmul,pcon,smul,scon)
			"""
			print("\nif right.weight * {0} + {1} < left.weight * {2}:".format(pmul,pcon,den))
			print("\tif left.left.weight * {0} + {1} < left.weight * {2}\n".format(smul,scon,den))
			"""
			print(count,"\n")

	print("passed: {0}".format(passed))


def SBWorstTree(nodes):
	#Build the worst tree possible
	#
	#To build the tree, always try to add a node to the left-hand side if the
	#primary invariant allows it.
	def PInvariant(lw,rw):
		#Return true if lw or rw violate the primary invariant.
		mul,con,den=5,2,2#3,1,1#
		return lw*mul+con<rw*den or rw*mul+con<lw*den
	tree=SBTree(False)
	for i in range(nodes):
		next=SBTree.Node(None)
		node=tree.root
		if node is None:
			tree.root=next
			continue
		while True:
			node.weight+=1
			lw=node.left.weight if node.left else 0
			rw=node.right.weight if node.right else 0
			if PInvariant(lw+1,rw):
				if node.right is None:
					node.right=next
					break
				node=node.right
			else:
				if node.left is None:
					node.left=next
					break
				node=node.left
		next.parent=node
	return tree


def SBHeightLimit():
	#Calculate the worst tree possible.
	#worst case = ln( 2 ) / ln( 1 + 1/ratio )
	def WeightBounds(weight):
		min=weight*den-con+mul-1
		min= 0 if min<0 else min//mul
		max=weight*mul+con
		if max<0:
			max=-1 if max<-den else 0
		else:
			max//=den
		return (min,max)
	mul,con,den=5,2,2#3,1,1#8,3,3#
	weight=1
	for height in range(0,65537):
		calcheight=math.log(weight)/math.log(2)
		if (height&(height-1))==0:
			print(height,calcheight,height/calcheight if calcheight>0 else 0)
		#print(height/calcheight if calcheight>0 else 0)
		min,max=WeightBounds(weight)
		#print(min,weight)
		weight+=min+1


def SBTreeInspect(tree):
	#Traverse a tree and inspect all links and weights.
	#
	#We traverse in an order that inspects the next node before traversing to it. In
	#this way, we make sure there is a path from the root to any node in the tree.
	node=tree.root
	nodes=0
	maxheight=-1
	#Don't process an empty tree.
	if node is None:
		return (nodes,maxheight)
	if not node.parent is None:
		print("root parent is not null")
		exit()
	height=0
	prev=node
	while True:
		if node is None:
			#We traversed a null child link.
			height-=1
			node=prev
			prev=None
		elif prev is node.right:
			#Going up #2.
			height-=1
			prev=node
			node=node.parent
			if node is None: break
		elif prev is node.left:
			#Going up #1.
			height+=1
			prev=node
			node=node.right
		else:
			#Going down.
			nodes+=1
			#Measure the height of the tree.
			if maxheight<height:
				maxheight=height
			#Check that both siblings point back to the parent.
			left=node.left
			if left and not left.parent is node:
				print("left has no parent")
				exit()
			right=node.right
			if right and not right.parent is node:
				print("right has no parent")
				exit()
			#Check for twins.
			if left and left is right:
				print("children are twins")
				exit()
			#Check weight and weight invariant.
			leftweight=left.weight if left else 0
			rightweight=right.weight if right else 0
			weight=leftweight+rightweight+1
			if node.weight!=weight:
				print("node weight: {0}, {1}".format(node.weight,weight))
				exit()
			if rightweight*5+2<leftweight*2 or leftweight*5+2<rightweight*2:
				print("weight balance: {0}, {1}".format(leftweight,rightweight))
				exit()
			height+=1
			prev=node
			node=left
	if (not prev is tree.root) or nodes!=prev.weight:
		print("improper node count")
		exit()
	return (nodes,maxheight)


def SBManualSearch(valarr,nodes,val,search):
	#Return the bounds that we expect the node to be in.
	pos=None
	if search==SBTree.EQ:
		for i in range(nodes):
			if valarr[i]==val: pos=i;break
	elif search==SBTree.EQG:
		for i in range(nodes-1,-1,-1):
			if valarr[i]==val: pos=i;break
	elif search==SBTree.LT:
		for i in range(nodes):
			if valarr[i]>=val: break
			pos=i
	elif search==SBTree.LE:
		for i in range(nodes):
			if valarr[i]>val: break
			pos=i
	elif search==SBTree.GT:
		for i in range(nodes-1,-1,-1):
			if valarr[i]<=val: break
			pos=i
	elif search==SBTree.GE:
		for i in range(nodes-1,-1,-1):
			if valarr[i]<val: break
			pos=i
	return pos


def SBTreeTest():
	print("Testing SB trees")

	#A mock integer type to test sorting stability of the tree.
	class IndexInt(object):
		def __init__(self,val,idx):
			if isinstance(val,IndexInt): val=val.val
			self.val=val
			self.idx=idx
		def __str__(a): return "("+str(a.val)+","+str(a.idx)+")"
		#def __int__(a): return a.val
		@staticmethod
		def get(a): return a.val if isinstance(a,IndexInt) else a
		def __eq__(a,b): return a.val==IndexInt.get(b)
		def __ne__(a,b): return a.val!=IndexInt.get(b)
		def __le__(a,b): return a.val<=IndexInt.get(b)
		def __lt__(a,b): return a.val< IndexInt.get(b)
		def __ge__(a,b): return a.val>=IndexInt.get(b)
		def __gt__(a,b): return a.val> IndexInt.get(b)

	#Perform multiple trials.
	trials=1000000
	maxnodes=2048
	nodes=0
	maxratio=0.0
	valnum=0
	createprob=128
	createrun=0
	valarr=[None]*maxnodes
	tree=SBTree(False)
	for trial in range(trials):
		if (trial&4095)==0:
			print("{0}/{1}: {2}, {3:.6f}".format(trial,trials,nodes,maxratio))

		#Make sure the tree is in compliance.
		weight,height=SBTreeInspect(tree)
		if nodes!=weight:
			print("missing nodes: {0}, {1}".format(nodes,weight))
			exit()
		if nodes>1:
			minlim=math.log(nodes)/math.log(2.0)
			maxlim=2.06*minlim
			ratio=height/minlim
			if maxratio<ratio: maxratio=ratio
			if height<minlim-1 or height>maxlim:
				print("tree height: {0}, {1}, {2}, {3}".format(nodes,height,minlim,maxlim))
				exit()

		#Traverse the tree and compare it with the sorted array.
		node=tree.first()
		rev=tree.last()
		for i in range(nodes):
			if (not tree[i] is node) or node.index()!=i:
				print("index out of order")
				exit()
			if (not node.value is valarr[i]) or (not rev.value is valarr[nodes-1-i]):
				print("walk out of order")
				exit()
			node=node.next()
			rev=rev.prev()
		if (not node is None) or (not rev is None):
			print("didn't finish walking")
			exit()

		#Test searching the tree for a value.
		valmin,valmax=-2,3
		if tree.root:
			valmin=tree.first().value.val-2
			valmax=tree.last().value.val+3
		val=random.randrange(valmin,valmax)
		search=random.randrange(6)
		pos=SBManualSearch(valarr,nodes,val,search)
		find=tree.find(val,search)
		if (pos is None)!=(find is None) or (find and pos!=find.index()):
			print("Cound not find node")
			exit()

		#Add or remove a value.
		if createrun<=0:
			createrun=1<<random.randrange(9)
			createprob=random.randrange(257)
		createrun-=1
		if random.randrange(256)<createprob:
			if nodes<maxnodes:
				#Add a value.
				valnum=valnum+random.randrange(65)-32
				val=IndexInt(valnum,trial)
				node=tree.add(val)
				i=nodes
				nodes+=1
				while i>0 and valarr[i-1]>val:
					valarr[i]=valarr[i-1]
					i-=1
				valarr[i]=val
		elif nodes:
			#Remove a value.
			i=random.randrange(nodes)
			tree.removenode(tree[i])
			nodes-=1
			while i<nodes:
				valarr[i]=valarr[i+1]
				i+=1

	print("passed")


def SBRebalanceTest():
	#Create an imbalanced tree with random weights. Then see how many rebalance
	#operations are needed before the tree follows the invariant.
	print("Testing rebalancing")
	trials=1000
	for trial in range(trials):
		#Generate the tree. At each node, randomly allocate its weight to the left or
		#right child.
		tree=SBTree(False)
		nodes=random.randrange((1<<random.randrange(14)))+1
		n=SBTree.Node(None)
		n.weight=nodes
		tree.root=n
		nodepos=1
		nodearr=[None]*nodes
		nodearr[0]=n
		for i in range(nodes):
			node=nodearr[i]
			left=random.randrange(node.weight)
			right=node.weight-left-1
			if left>0:
				n=SBTree.Node(None)
				n.weight=left
				n.parent=node
				node.left=n
				nodearr[nodepos]=n
				nodepos+=1
			if right>0:
				n=SBTree.Node(None)
				n.weight=right
				n.parent=node
				node.right=n
				nodearr[nodepos]=n
				nodepos+=1
			node.weight=random.randrange(1<<random.randrange(32))
		#While the tree is not balanced.
		loops=0
		while True:
			#Order nodes from top to bottom, left to right.
			nodepos=1
			nodearr[0]=tree.root
			leafstart=None
			for i in range(nodes):
				node=nodearr[i]
				if node.left:
					nodearr[nodepos]=node.left
					nodepos+=1
				if node.right:
					nodearr[nodepos]=node.right
					nodepos+=1
				elif leafstart is None and node.left is None:
					leafstart=i
			#Check if the tree is balanced.
			errors=0
			for i in range(nodes-1,-1,-1):
				node=nodearr[i]
				lw=node.left._weight if node.left else 0
				rw=node.right._weight if node.right else 0
				weight=lw+rw+1
				node._weight=weight
				if weight!=node.weight or lw*5+2<rw*2 or rw*5+2<lw*2:
					errors+=1
			if errors==0:
				break
			loops+=1
			#Pick a random leaf to rebalance from.
			i=random.randrange(nodes-leafstart)+leafstart
			node=nodearr[i]
			tree.rebalance(node)
		print("{0:4d}: {1:4d}, {2:5d}".format(trial,nodes,loops))
	print("passed")


def SBTreeSpeedTest():
	#pypy
	#insert: 5.652349
	#search: 2.964924
	#delete: 5.891137
	#
	#python3
	#insert: 71.099872
	#search: 32.186564
	#delete: 28.795181
	print("Testing SB tree speed")
	random.seed(1)
	shuffle=random.shuffle
	randrange=random.randrange
	timeinsert,timesearch,timedelete=0.0,0.0,0.0
	optrials=1000
	for trial in range(10000):
		tree=SBTree(False)
		valarr=[randrange(64) for i in range(optrials)]
		t0=time.time()
		for i in range(optrials):
			tree.add(valarr[i])
		timeinsert+=time.time()-t0
		t0=time.time()
		for i in range(optrials):
			tree.find(valarr[i],randrange(6))
		timesearch+=time.time()-t0
		for i in range(len(tree)):
			valarr[i]=tree[i]
		shuffle(valarr)
		t0=time.time()
		for i in range(optrials):
			tree.removenode(valarr[i])
		timedelete+=time.time()-t0
	print("#insert: {0:6f}".format(timeinsert))
	print("#search: {0:6f}".format(timesearch))
	print("#delete: {0:6f}".format(timedelete))
	print("passed")


if __name__=="__main__":
	#SBInvariantTest()
	#SBHeightLimit()
	SBTreeTest()
	#SBRebalanceTest()
	#SBTreeSpeedTest()

