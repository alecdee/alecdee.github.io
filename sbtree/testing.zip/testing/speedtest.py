import random,gc,os,sys
from time import time,sleep

authornames=("dee","mozmanavl","mozmanrb","msingh","pathak","pgrafov","reid","stanisl","yoo")
#"girish" omitted

def loadtree(name):
	if name=="dee":
		sys.path.insert(0,"../")
		from SBTree import SBTree as dee_avl
		sys.path.pop(0)
		return (dee_avl,"add","remove","find")
	elif name=="girish":
		from girish3_avl import AVLTree as girish_avl
		return (girish_avl,"insert","delete","")
	elif name=="mozmanavl":
		sys.path.insert(0,"bintrees")
		from avltree import AVLTree as mozman_avl
		sys.path.pop(0)
		return (mozman_avl,"insert","remove","get_value")
	elif name=="mozmanrb":
		sys.path.insert(0,"bintrees")
		from rbtree import RBTree as mozman_rb
		sys.path.pop(0)
		return (mozman_rb,"insert","remove","get_value")
	elif name=="msingh":
		from msingh3012_rb import RBTree as msingh_rb
		return (msingh_rb,"insertNode","remove","findNode")
	elif name=="pathak":
		from pathak_avl import AVL_Tree as pathak_avl
		return (pathak_avl,"insertD","","")
	elif name=="pgrafov":
		from pgrafov_avl import AVLTree as pgrafov_avl
		return (pgrafov_avl,"insert","remove","find")
	elif name=="reid":
		from reid_rb import rbtree as reid_rb
		return (reid_rb,"insert_key","","search")
	elif name=="stanisl":
		from stanislavkozlovski_rb import RedBlackTree as stanisl_rb
		return (stanisl_rb,"add","remove","find_node")
	elif name=="yoo":
		from yoo_rb import Tree as yoo_rb
		return (yoo_rb,"insert","","")
	else:
		print("Unknown name: "+str(name))
		exit()

def timingtest(name):
	treeclass,addname,remname,findname=loadtree(name)
	random.seed(1)
	trials=100
	points=100
	pointgap=1000
	samples=points*pointgap
	data=list(range(samples))
	addtime=[0.0]*(points+1)
	remtime=[0.0]*(points+1)
	findtime=0.0
	for trial in range(trials):
		#gc.collect()
		tree=treeclass()
		#Add data to the tree.
		random.shuffle(data)
		if addname:
			addfunc=getattr(tree,addname)
			t0=time()
			p,mark=1,pointgap-1
			for i in range(samples):
				addfunc(data[i])
				if i==mark:
					addtime[p]+=time()-t0
					p,mark=p+1,mark+pointgap
		#Find all data points.
		random.shuffle(data)
		if findname:
			findfunc=getattr(tree,findname)
			t0=time()
			for i in range(samples):
				findfunc(data[i])
			findtime+=time()-t0
		#Remove all data.
		random.shuffle(data)
		if remname:
			remfunc=getattr(tree,remname)
			t0=time()
			p,mark=1,pointgap-1
			for i in range(samples):
				remfunc(data[i])
				if i==mark:
					remtime[p]+=time()-t0
					p,mark=p+1,mark+pointgap
	for i in range(points+1):
		j=i*pointgap
		addtime[i]=(j,addtime[i]/trials)
		remtime[i]=(j,remtime[i]/trials)
	findtime/=trials
	with open("speeddata.py","a") as f:
		f.write(name+"=(\n")
		s=repr(addtime) if addname else "None"
		f.write("\t"+s+",\n")
		s=repr(remtime) if remname else "None"
		f.write("\t"+s+",\n")
		s=repr(findtime) if findname else "None"
		f.write("\t"+s+"\n)\n\n")

def timingtestall():
	if os.path.isfile("speeddata.py"):
		os.remove("speeddata.py")
	for name in authornames:
		print("timing "+name)
		gc.collect()
		sleep(30)
		timingtest(name)
	print("timing done")

def timinggraph():
	import speeddata
	import matplotlib
	import matplotlib.pyplot as plt
	#Add graph.
	maxx,maxy=100000,4.0
	for i in range(2):
		matplotlib.rcParams["font.sans-serif"]="Consolas"
		plt.figure(figsize=(12,6),dpi=100)
		plt.grid(True,linestyle="dashed")
		title=plt.title(("Adding Keys","Removing Keys")[i],y=1.04)
		plt.setp(title,color="black",fontweight="bold",fontsize=22)
		plt.xlabel("N",fontsize=15)
		plt.ylabel("Seconds",fontsize=15)
		plt.xlim(0,maxx)
		plt.ylim(0,maxy)
		for name in authornames:
			data=getattr(speeddata,name)[i]
			if data==None: continue
			xaxis=[d[0] for d in data]
			yaxis=[d[1] for d in data]
			#Find the point of the graph on the upper/right border.
			x,y=xaxis[0],yaxis[0]
			for j in range(1,len(data)):
				x0,y0=x,y
				x,y=xaxis[j],yaxis[j]
				if x>=maxx:
					y=y0+(y-y0)*(maxx-x0)/(x-x0)-maxy*0.01
					x=maxx+maxx*0.002
					break
				elif y>=maxy:
					x=x0+(x-x0)*(maxy-y0)/(y-y0)+maxx*0.002
					y=maxy+maxy*0.005
					break
			plt.plot(xaxis,yaxis)
			#Kludge to prevent overlapping labels.
			if i==0:
				if name=="dee": y-=maxy*0.015
				if name=="stanisl":  y+=maxy*0.015
			plt.text(x,y,name)
		#plt.show()
		plt.savefig(("add_graph.svg","rem_graph.svg")[i],bbox_inches="tight")
	#Table for find times.
	print("Time to search through "+str(maxx)+" elements")
	print("<table>")
	print("<tr><td>Name</td><td>Search Time</td></tr>")
	for name in authornames:
		data=getattr(speeddata,name)[2]
		if data: data="{0:>6f} s".format(data)
		else   : data="N/A"
		print("<tr><td>{0}</td><td>{1}</td></tr>".format(name,data))
	print("</table>")

#timingtestall()
timinggraph()
