import random
#Python2 compatibility.
import sys
if sys.version_info[0]<=2:
	range=xrange
	input=raw_input

def FindImplementations(self,key,flag=0):
	#pypy
	#insert: 5.617682
	#search: 3.408276
	#delete: 5.690273
	#
	#python3
	#insert: 68.582931
	#search: 44.779392
	#delete: 28.841509
	"""node,ret,cmp=self.root,None,self.cmp
	table=((4,1,2),#EQ
	       (5,5,2),#LE
	       (5,2,2),#LT
	       (4,3,3),#GE
	       (4,4,3))#GT
	ref=table[flag]
	while node:
		c=ref[cmp(node.key,key)+1]
		if   c&1: ret=node
		if   c&2: node=node.left
		elif c&4: node=node.right
		else: break
	return ret"""
	#Search for a specific value or inequality.
	#pypy
	#insert: 6.066254
	#search: 2.998471
	#delete: 5.898282
	#
	#python3
	#insert: 68.911149
	#search: 32.715053
	#delete: 29.083173
	"""node,ret,cmp=self.root,None,self.cmp
	if flag==SBTree.EQ:
		while node:
			c=cmp(node.key,key)
			if c==0: ret=node;break
			node=node.right if c<0 else node.left
	elif flag==SBTree.EQL:
		while node:
			c=cmp(node.key,key)
			if c==0: ret=node
			node=node.right if c<0 else node.left
	elif flag==SBTree.EQG:
		while node:
			c=cmp(node.key,key)
			if c==0: ret=node
			node=node.right if c<=0 else node.left
	elif flag==SBTree.LT:
		while node:
			if cmp(node.key,key)< 0: ret,node=node,node.right
			else: node=node.left
	elif flag==SBTree.LE:
		while node:
			if cmp(node.key,key)<=0: ret,node=node,node.right
			else: node=node.left
	elif flag==SBTree.GT:
		while node:
			if cmp(node.key,key)> 0: ret,node=node,node.left
			else: node=node.right
	elif flag==SBTree.GE:
		while node:
			if cmp(node.key,key)>=0: ret,node=node,node.left
			else: node=node.right
	return ret"""
	#pypy
	#insert: 5.970586
	#search: 3.674386
	#delete: 5.862216
	#
	#python3
	#insert: 68.540503
	#search: 52.840786
	#delete: 29.007679
	"""#Search for a specific value or inequality.
	#
	#      set    right
	#c : -1 0 1  -1 0 1
	#---------------------
	#LT:  1 0 0   1 0 0
	#LE:  1 1 0   1 1 0
	#EQ:  0 1 0   1 0 0
	#GE:  0 1 1   1 0 0
	#GT:  0 0 1   1 1 0
	node,ret,cmp=self.root,None,self.cmp
	con=(0x0a,0x1b,0x09,0x0e,0x1c)[flag]
	while node:
		c=cmp(node.key,key)
		c=con>>((c>0)-(c<0)+1)
		if c&1: ret=node
		node=node.right if c&8 else node.left
	return ret"""

def RotLeftBalance():
	#Raise z, lower x, and maintain the sorted order of the nodes.
	#
	#       A              B
	#      / \            / \
	#     x   B    ->    A   z
	#        / \        / \
	#       y   z      x   y
	#
	for i in range(1000):
		A =SBTree.Node(None)
		B =SBTree.Node(None)
		c0=SBTree.Node(None)
		c1=SBTree.Node(None)
		c2=SBTree.Node(None)
		A.left=c0
		A.right=B
		c0.parent=A
		B.parent=A
		B.left=c1
		B.right=c2
		c1.parent=B
		c2.parent=B
		c0.height=i%10
		c1.height=(i//10)%10
		c2.height=i//100
		B.calcheight()
		A.calcheight()
		abal=getbal(A)
		bbal=getbal(B)
		if abs(abal)>2 or abs(bbal)>2: continue
		A.rotleft()
	for key,val in SBTree.bmap.iteritems():
		print(str(key)+": "+str(val))
	for key,val in SBTree.bmap.iteritems():
		a0,b0=key
		a0-=1+max(b0,0)
		b0-=1-min(a0,0)
		a1,b1=list(val)[0]
		print(a0,a1,b0,b1)
		assert(a0==a1 and b0==b1)

def RotRightBalance():
	#Raise x, lower z, and maintain the sorted order of the nodes.
	#
	#         A          B
	#        / \        / \
	#       B   z  ->  x   A
	#      / \            / \
	#     x   y          y   z
	#
	for i in range(1000):
		A =SBTree.Node(None)
		B =SBTree.Node(None)
		c0=SBTree.Node(None)
		c1=SBTree.Node(None)
		c2=SBTree.Node(None)
		A.left=B
		A.right=c0
		c0.parent=A
		B.parent=A
		B.left=c1
		B.right=c2
		c1.parent=B
		c2.parent=B
		c0.height=i%10
		c1.height=(i//10)%10
		c2.height=i//100
		B.calcheight()
		A.calcheight()
		abal=getbal(A)
		bbal=getbal(B)
		if abs(abal)>2 or abs(bbal)>2: continue
		A.rotright()
	for key,val in SBTree.bmap.iteritems():
		print(str(key)+": "+str(val))
	for key,val in SBTree.bmap.iteritems():
		a0,b0=key
		a0+=1-min(b0,0)
		b0+=1+max(a0,0)
		a1,b1=list(val)[0]
		print(a0,a1,b0,b1)
		assert(a0==a1 and b0==b1)

def SBTreeScan(node,keymin,keymax):
	#Scan the tree to make sure nodes are ordered and links are set properly.
	if node==None:
		return 0
	if isinstance(node,SBTree):
		return SBTreeScan(node.root,keymin,keymax)
	key=node.key
	if key<keymin or key>keymax:
		print("Key not in bounds: "+str(keymin)+"<="+str(key)+"<="+str(keymax))
		exit()
	left,right=node.left,node.right
	if left and not left.parent is node:
		print("Left has no parent")
		exit()
	if right and not right.parent is node:
		print("Right has no parent")
		exit()
	lh=SBTreeScan(left ,keymin,key   )
	rh=SBTreeScan(right,key   ,keymax)
	if abs(rh-lh)>1:
		print("children imbalanced")
		SBTreePrint(node)
		exit()
	#If nodes use height, check it.
	height=(lh if lh>rh else rh)+1
	try:
		if node.height!=height:
			print("Node height: "+str(node.height)+", "+str(height))
			exit()
	except AttributeError: pass
	#If nodes use relative balance, check it.
	try:
		bal=rh-lh
		if node.bal!=bal:
			print("Node balance: "+str(node.bal)+", "+str(bal))
			exit()
	except AttributeError: pass
	return height

def SBTreePrint(node):
	def H(n): return n.height if n else 0
	if isinstance(node,SBTree):
		print("-"*50)
		print("Tree:")
		SBTreePrint(node.root)
		return
	if node==None: return
	print("  "+str(node.key)+","+str(H(node)))
	print("  /   \\")
	n=node.left
	s =str(n.key)+","+str(H(node)) if n else "@,0"
	s+="   "
	n=node.right
	s+=str(n.key)+","+str(H(node)) if n else "@,0"
	print(s+"\n")
	SBTreePrint(node.left)
	SBTreePrint(node.right)

def SBTreeTest():
	print("Testing SB trees")
	#A mock integer type to test sorting stability of the tree.
	class IndexInt(object):
		def __init__(self,val):
			if isinstance(val,IndexInt): val=val.val
			self.val=val
			self.ind=0
		def __str__(a): return "("+str(a.val)+","+str(a.ind)+")"
		#def __int__(a): return a.val
		@staticmethod
		def get(a): return a.val if isinstance(a,IndexInt) else a
		def __eq__(a,b): return a.val==IndexInt.get(b)
		def __ne__(a,b): return a.val!=IndexInt.get(b)
		def __le__(a,b): return a.val<=IndexInt.get(b)
		def __lt__(a,b): return a.val< IndexInt.get(b)
		def __ge__(a,b): return a.val>=IndexInt.get(b)
		def __gt__(a,b): return a.val> IndexInt.get(b)
	#Perform multiple trials.
	for trial in range(100):
		TestType=int if trial&3 else IndexInt
		tree=SBTree(False)
		nodetrials=2**12
		keyarr=[]
		nodearr=[]
		keymin,keymax=0,1<<randrange(20)
		newprob=128
		newgap=(nodetrials+9)//10
		maxratio=0.0
		for nodetrial in range(nodetrials):
			#Make sure the tree is in compliance.
			height=SBTreeScan(tree,keymin,keymax)
			nodes=len(keyarr)
			minlim=log(nodes+1)/log(2.0)
			maxlim=1.440*minlim+1
			if height<minlim or height>maxlim:
				print("{0}, {1}, {2}".format(height,minlim,maxlim))
				exit()
			if nodes>10:
				ratio=(height-1)/minlim
				if maxratio<ratio: maxratio=ratio
			#Traverse the tree and compare it with the sorted array.
			fwd=tree.first()
			rev=tree.last()
			prev=None
			for i in range(nodes):
				if fwd==None or rev==None or fwd.key!=keyarr[i] or rev.key!=keyarr[-1-i]:
					print("walk out of order")
					exit()
				#Make sure traversal is stable.
				if prev!=None and prev==fwd.key and prev.ind>=fwd.key.ind:
					print("insertion not stable")
					exit()
				if TestType is IndexInt:
					prev=fwd.key
				fwd=fwd.next()
				rev=rev.prev()
			if (not fwd is None) or (not rev is None):
				print("didn't finish walking")
				exit()
			#Test searching the tree for a key.
			val=randrange(keymin,keymax+1)
			flag=randrange(7)
			pos=None
			find=tree.find(val,flag)
			if flag==SBTree.EQ:
				for i in range(nodes):
					if keyarr[i]==val: pos=i;break
			elif flag==SBTree.EQL:
				for i in range(nodes):
					if keyarr[i]==val: pos=i;break
			elif flag==SBTree.EQG:
				for i in range(nodes-1,-1,-1):
					if keyarr[i]==val: pos=i;break
			elif flag==SBTree.LT:
				for i in range(nodes):
					if keyarr[i]>=val: break
					pos=i
			elif flag==SBTree.LE:
				for i in range(nodes):
					if keyarr[i]>val: break
					pos=i
			elif flag==SBTree.GT:
				for i in range(nodes-1,-1,-1):
					if keyarr[i]<=val: break
					pos=i
			elif flag==SBTree.GE:
				for i in range(nodes-1,-1,-1):
					if keyarr[i]<val: break
					pos=i
			for i in range(-1,2):
				if flag==SBTree.EQ and i: continue
				n=find
				if i==-1 and n: n=n.prev()
				if i==1  and n: n=n.next()
				j=None if (pos==None or pos+i<0 or pos+i>=nodes) else pos+i
				if (j==None)!=(n==None):
					print("Found missing node: "+str(flag)+", "+str(val))
					exit()
				if n and keyarr[j]!=n.key:
					print("Found misaligned: "+str(flag)+", "+str(i))
					exit()
			#Add or remove a key.
			if nodetrial%newgap==0:
				newprob=random.randrange(257)
			if random.randrange(256)<newprob:
				val=TestType(random.randrange(keymin,keymax+1))
				if TestType is IndexInt:
					val.ind=nodetrial
				keyarr.append(val)
				keyarr.sort()
				node=tree.add(val)
				nodearr.append(node)
			elif nodes:
				node=nodearr[random.randrange(nodes)]
				keyarr.remove(node.key)
				nodearr.remove(node)
				tree.removenode(node)
		print("{0}/{1}: {2}, {3:.6f}".format(trial,100,nodes,maxratio))
	print("passed")

def SBTreeSpeedTest():
	#pypy
	#insert: 5.652349
	#search: 2.964924
	#delete: 5.891137
	#
	#python3
	#insert: 71.099872
	#search: 32.186564
	#delete: 28.795181
	print("Testing SB tree speed")
	seed(1)
	timeinsert,timesearch,timedelete=0.0,0.0,0.0
	optrials=1000
	for trial in range(10000):
		tree=SBTree(False)
		keyarr=[randrange(64) for i in range(optrials)]
		t0=time.time()
		for i in range(optrials):
			tree.add(keyarr[i])
		timeinsert+=time.time()-t0
		t0=time.time()
		for i in range(optrials):
			tree.find(keyarr[i],randrange(7))
		timesearch+=time.time()-t0
		node=tree.first()
		for i in range(optrials):
			keyarr[i]=node
			node=node.next()
		shuffle(keyarr)
		t0=time.time()
		for i in range(optrials):
			tree.removenode(keyarr[i])
		timedelete+=time.time()-t0
	print("#insert: {0:6f}".format(timeinsert))
	print("#search: {0:6f}".format(timesearch))
	print("#delete: {0:6f}".format(timedelete))
	print("passed")

sys.path.insert(0,"../")
from SBTree import SBTree
#from avl_relative import SBTree
from random import randrange,shuffle,seed
from math import log
import time
#RotLeftBalance()
#RotRightBalance()
SBTreeTest()
#SBTreeSpeedTest()

