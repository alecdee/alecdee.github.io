"""
RayTracer_C.py - v1.01

Copyright (C) 2020 by Alec Dee - alecdee.github.io - akdee144@gmail.com

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
"""

import sys,time
from RayTracer import *

#Setup the C raytracer and overload the default python render function.
import RayTracer_C_Ext
Scene.render=lambda self,prog=0: RayTracer_C_Ext.render(self,prog)

if __name__=="__main__":
	start=time.time()
	highquality=sys.argv[-1]=="-HQ"
	pixels,rays,sphere=((300,1<<7,1<<13),(600,1<<16,1<<19))[highquality]
	path="render3d.bmp"
	hpi=math.pi*0.5
	sc=Scene(3,pixels,pixels)
	sc.raysperpixel=rays
	sc.setcamera((278,273,800),(0,0,0),37.5)
	lightmat=MeshMaterial((1.0,1.0,1.0),25.0)
	wallmat =MeshMaterial((0.9,0.9,0.9))
	rightmat=MeshMaterial((0.2,0.9,0.2))
	leftmat =MeshMaterial((0.9,0.2,0.2))
	mirmat  =MeshMaterial((1.0,1.0,1.0),0.0,1.0,0.0)
	submat  =MeshMaterial((0.4,0.4,0.9),0.0,0.0,0.0,1.0,1.0,5.0)
	glassmat=MeshMaterial((1.0,1.0,1.0),0.0,1.0,0.0,1.0,1.5)
	sc.addcube((130,0.2,105),lightmat,Transform((278,548.7,-279.5)))
	sc.addcube((556,559.2),wallmat,Transform((278,0,-279.6),(0,0,hpi)))
	sc.addcube((556,559.2),wallmat,Transform((278,548.8,-279.6),(0,0,-hpi)))
	sc.addcube((556,-548.8),wallmat,Transform((278,274.4,-559.2)))
	sc.addcube((559.2,548.8),leftmat,Transform((0,274.4,-279.6),(0,hpi,0)))
	sc.addcube((559.2,548.8),rightmat,Transform((556,274.4,-279.6),(0,-hpi,0)))
	sc.addcube((166,166,166),submat,Transform((371,83,-168.5),(0,0.2856,0)))
	sc.addsphere((250,280,-370),100,sphere,mirmat)
	sc.addsphere((135,125,-125),80,sphere,glassmat)
	print("rendering {0} triangles".format(sc.faces))
	sc.render(True)
	print("saving image to "+path)
	sc.savebmp(path)
	print("time: {0:.6f}".format(time.time()-start))

