import sys,math,random
from timeit import default_timer as timer
from RayTracer import *

#Speed, no printing:
#     python3 skip   : 7403.545194
#     python3 no skip: 8367.594478
#     pypy2 skip     : 1011.066045
#     pypy2 no skip  : 1120.137663
#     pypy3 skip     :  998.523907
#     pypy3 no skip  : 1038.064289

#--------------------------------------------------------------------------------
#Helper Functions
#--------------------------------------------------------------------------------

"""
def raypick(self,ray):
	#Finds the nearest surface that the ray intersects.
	node,next=None,self.root
	ray.precalc()
	dir=ray.dir.elem
	swap=0
	for i in range(len(dir)): swap+=(dir[i]<0)<<i
	while next is not None:
		prev,node=node,next
		next=node.parent
		down=prev is next
		#Check if we're intersecting the current node.
		if down and node.testray:
			if not node.intersect(ray): continue
		nl,nr=node.left,node.right
		if node.type==BVHNode.DIVIDE:
			#This is a dividing node. Determine which child to visit first using the dividing
			#axis and sign of the ray. Note that a better heuristic won't greatly help here.
			if swap&node.axis: nl,nr=nr,nl
			if down: next=nl
			elif prev is nl: next=nr
		else:
			#We are intersecting a mesh instance or a face.
			nl.intersect(ray)
"""

"""
def intersect(self,ray):
	den=ray.dir*self.norm
	if abs(den)<=1e-20: return False
	re,ve=ray.pos.elem,self.vertarr[0].pos.elem
	dim=len(re)
	pe=[re[i]-ve[i] for i in range(dim)]
	ne=self.norm.elem
	dist=0.0
	for i in range(dim): dist-=pe[i]*ne[i]
	dist/=den
	if dist<ray.min or dist>=ray.max: return False
	de=ray.dir.elem
	for i in range(dim): pe[i]+=de[i]*dist
	#Make sure the barycentric coordinates of the point are within the face.
	s=0.0
	for bary in self.bary:
		be=bary.elem
		u=0.0
		for i in range(dim): u+=pe[i]*be[i]
		s+=u
		if u<0.0 or s>1.0:
			return False
	ray.max=dist
	ray.face=self
	ray.facenorm=self.norm
	ray.facemat=self.mat
	return True
"""

"""
def getpca(nodearr,left,right,dim):
	r=Vector(dim).randomize()
	cen=Vector(dim)
	for j in range(left,right):
		cen+=nodearr[j].center
	cen*=1.0/(right-left)
	for i in range(3):
		s=Vector(dim)
		for j in range(left,right):
			x=nodearr[j].center-cen
			s+=(x*r)*x
		r=s.normalize()
	return r
"""

def printvec(v):
	print("["+", ".join(["{0:.6f}".format(x) for x in v.elem])+"]")

def FaceArea(face):
	vertarr=face.vertarr
	dim=len(vertarr)
	if dim==0: return 0.0
	den=1
	for i in range(2,dim): den*=i
	difarr=[vertarr[i].pos-vertarr[0].pos for i in range(1,dim)]
	return abs(Vector.cross(difarr))/den

#--------------------------------------------------------------------------------
#Testing
#--------------------------------------------------------------------------------
"""
pypy3
setup: 0.023951, render: 0.160404, hits: 134432, tests: 29156748
setup: 0.014988, render: 0.083064, hits: 70240, tests: 16156597
setup: 0.010262, render: 0.089248, hits: 82926, tests: 18538636
setup: 0.054599, render: 1.210081, hits: 199688, tests: 263495635
setup: 0.058215, render: 0.561373, hits: 105154, tests: 127433348
setup: 0.056216, render: 0.701928, hits: 86030, tests: 157823893
setup: 0.645940, render: 23.740662, hits: 292454, tests: 3007782726
setup: 0.653684, render: 9.070539, hits: 143341, tests: 1187841588
setup: 0.659143, render: 11.274410, hits: 126172, tests: 1387499417
"""

def setuplogging():
	MeshFace.tests=0
	BVHNode.tests=0
	oldmesh=MeshFace.intersect
	def newmesh(self,ray):
		MeshFace.tests+=1
		return oldmesh(self,ray)
	MeshFace.intersect=newmesh
	oldbvh=BVHNode.intersect
	def newbvh(self,ray):
		BVHNode.tests+=1
		return oldbvh(self,ray)
	BVHNode.intersect=newbvh
	return (oldmesh,oldbvh)


def removelogging(loginfo):
	oldmesh,oldbvh=loginfo
	MeshFace.intersect=oldmesh
	BVHNode.intersect=oldbvh
	return (MeshFace.tests,BVHNode.tests)

def SceneSpeedMain(faces,facesize,spacing,rays,trials):
	def randvec(dim,mul): return Vector(dim).randomize()*random.gauss(0,mul)
	def makemesh(dim,faces,mat,depth):
		mesh=Mesh(dim)
		dim2=dim*(dim-1)//2
		while faces>0:
			pos=randvec(dim,spacing)
			angs=[random.random()*6.283185 for i in range(dim2)]
			trans=Transform(pos,angs,random.gauss(0,facesize))
			if random.randrange(16) or depth>0:
				v=[mesh.addvertex(randvec(dim,facesize),trans) for i in range(dim)]
				mesh.addface(v,mat)
				faces-=1
			else:
				cnt=random.randrange(faces+1)
				mesh.addmesh(makemesh(dim,cnt,mat,depth+1),trans)
				faces-=cnt
		mesh.buildbvh()
		return mesh
	loginfo=setuplogging()
	setuptime=0.0
	rendertime=0.0
	facehits=0
	for trial in range(trials):
		t0=timer()
		dim=random.randrange(5)
		sc=Scene(dim,1,1)
		sc.maxbounces=8
		mat=MeshMaterial((1.0,1.0,1.0),1.0,0.5,0.5,0.5,1.5,spacing)
		sc.mesh=makemesh(dim,faces,mat,0)
		setuptime+=timer()-t0
		t0=timer()
		for r in range(rays):
			col=sc.raytrace(randvec(dim,spacing),Vec(dim).randomize())
			facehits+=col[0]
		rendertime+=timer()-t0
	facehits=int(facehits)
	tests=sum(removelogging(loginfo))
	setuptime/=trials
	rendertime/=trials
	print("setup: {0:.6f}, render: {1:.6f}, hits: {2}, tests: {3}".format(setuptime,rendertime,facehits,tests))

def SceneSpeedTest():
	random.seed(1)
	for faces in (100,1000,10000):
		for space in (1.0,10.0,100.0):
			SceneSpeedMain(faces,1.0,space,1000,100)

def SceneRenderTest():
	print("testing scene rendering")
	for dim in range(5):
		print("dim: {0}".format(dim))
		sc=Scene(dim,100,100)
		mat=MeshMaterial((0.4,0.4,0.9),0.0,0.0,0.0,1.0,1.0,5.0)
		sc.addcube([1.0]*dim,mat,Transform([2.0]*dim))
		sc.render(True)
	print("passed")

def TransformTest():
	#T3(T2(T1(x)))=(T3(T2(T1)))(x)
	dim=3
	def randomtrans():
		t=Transform(dim)
		for i in range(dim):
			t.off[i]=random.random()*4-2
		for i in range(dim*dim):
			t.mat.elem[i]=random.random()*4-2
		return t
	for trial in range(100):
		T1=randomtrans()
		T2=randomtrans()
		T3=randomtrans()
		x=Vector(dim)
		for i in range(dim):
			x[i]=random.random()*4-2
		y0=T3.apply(T2.apply(T1.apply(x)))
		T=T3.apply(T2.apply(T1))
		y1=T.apply(x)
		assert((y1-y0).mag()<1e-10)

#--------------------------------------------------------------------------------
#BVH
#--------------------------------------------------------------------------------

def BVHAnalyzeTree(bvh):
	#Check the properties of the BVH tree.
	nodearr,nodes=bvh.nodearr,bvh.nodes
	swaps=1<<bvh.dim
	leafs=(nodes+1)//2
	dmin,dmax,davg=nodes+1,0,0
	for i in range(nodes):
		node=nodearr[i]
		parent=node.parent
		#Set depth and make sure this node is a child of its parent.
		if parent is None:
			assert(bvh.root is node)
			node.depth=0
		else:
			node.depth=parent.depth+1
			assert(parent.left is node or parent.right is node)
		if node.type==BVHNode.DIVIDE:
			#Every dividing node should have 2 children.
			left,right=node.left,node.right
			assert(not (left is None) and not (right is None))
			#The left bounding box should be less than the right bounding box along the
			#sorted axis.
			axis=0
			while (node.axis&(1<<axis))==0: axis+=1
			lcen=left.bbmin[axis]+left.bbmax[axis]
			rcen=right.bbmin[axis]+right.bbmax[axis]
			assert(lcen<=rcen)
		else:
			#Record leaf depth.
			dmin=min(dmin,node.depth)
			dmax=max(dmax,node.depth)
			davg+=node.depth
	#The next[] node should be at the same level or above the current node.
	for i in range(nodes):
		node=nodearr[i]
		for swap in range(swaps):
			next=node.next[swap]
			assert(next is None or next.depth<=node.depth)
	print("depth min: {0}".format(dmin))
	print("depth max: {0}".format(dmax))
	print("depth avg: {0:.6f}".format(float(davg)/leafs))

def BVHRayPickSub(self,ray):
	#Finds the nearest surface that the ray intersects.
	node=self.root
	ray.precalc()
	hitid=Ray.hitid
	Ray.hitid+=1
	traverse=0
	dir=ray.dir.elem
	swap=0
	for i in range(len(dir)): swap+=(dir[i]<0)<<i
	while node:
		assert(node.hitid!=hitid)
		node.hitid=hitid
		traverse+=1
		next=node.next[swap]
		if node.testray==0 or node.intersect(ray):
			left=node.left
			if node.type==BVHNode.DIVIDE:
				#This is a dividing node. Determine which child to visit first using the dividing
				#axis and sign of the ray.
				next=node.right if (swap&node.axis) else left
			else:
				#We are intersecting a mesh instance or a face.
				left.intersect(ray)
		node=next
	Ray.travmin=min(Ray.travmin,traverse)
	Ray.travmax=max(Ray.travmax,traverse)
	Ray.travavg+=traverse
	Ray.travrays+=1

def BVHTestScene():
	#Create a scene and test the BVH properties of it.
	#nodes    : 31747
	#leafs    : 15874
	#trav min : 1
	#trav max : 263
	#trav avg : 30.243318
	#depth min: 4
	#depth max: 19
	#depth avg: 15.665680
	print("testing BVH properties")
	sphere=1<<13
	hpi=math.pi*0.5
	sc=Scene(3,300,300)
	sc.raysperpixel=16
	sc.setcamera((278,273,800),(0,0,0),37.5)
	lightmat=MeshMaterial((1.0,1.0,1.0),25.0)
	wallmat =MeshMaterial((0.9,0.9,0.9))
	rightmat=MeshMaterial((0.2,0.9,0.2))
	leftmat =MeshMaterial((0.9,0.2,0.2))
	mirmat  =MeshMaterial((1.0,1.0,1.0),0.0,1.0,0.0)
	submat  =MeshMaterial((0.4,0.4,0.9),0.0,0.0,0.0,1.0,1.0,5.0)
	glassmat=MeshMaterial((1.0,1.0,1.0),0.0,1.0,0.0,1.0,1.5)
	sc.addcube((130,0.2,105),lightmat,Transform((278,548.7,-279.5)))
	sc.addcube((556,559.2),wallmat,Transform((278,0,-279.6),(0,0,hpi)))
	sc.addcube((556,559.2),wallmat,Transform((278,548.8,-279.6),(0,0,-hpi)))
	sc.addcube((556,-548.8),wallmat,Transform((278,274.4,-559.2)))
	sc.addcube((559.2,548.8),leftmat,Transform((0,274.4,-279.6),(0,hpi,0)))
	sc.addcube((559.2,548.8),rightmat,Transform((556,274.4,-279.6),(0,-hpi,0)))
	sc.addcube((166,166,166),submat,Transform((371,83,-168.5),(0,0.2856,0)))
	sc.addsphere((250,280,-370),100,sphere,mirmat)
	sc.addsphere((135,125,-125),80,sphere,glassmat)
	sc.mesh.buildbvh()
	bvh=sc.mesh.bvh
	Ray.travmin=bvh.nodes+1
	Ray.travmax=0
	Ray.travavg=0
	Ray.travrays=0
	Ray.hitid=0
	for i in range(bvh.nodes):
		node=bvh.nodearr[i]
		node.hitid=-1
	BVH.raypick=BVHRayPickSub
	sc.render(True)
	print("nodes    : {0}".format(bvh.nodes))
	print("leafs    : {0}".format((bvh.nodes+1)//2))
	print("trav min : {0}".format(Ray.travmin))
	print("trav max : {0}".format(Ray.travmax))
	print("trav avg : {0:.6f}".format(float(Ray.travavg)/Ray.travrays))
	BVHAnalyzeTree(sc.mesh.bvh)
	print("passed")

#--------------------------------------------------------------------------------
#AABB
#--------------------------------------------------------------------------------

def AABBProbTest():
	#Confirm that the probability of a ray hitting a box inside another box is
	#surface(inside)/surface(outside).
	def surfacearea(bbmin,bbmax):
		dim=len(bbmin)
		area=0.0
		for i in range(dim):
			tmp=1.0
			for j in range(dim):
				if j!=i: tmp*=bbmax[j]-bbmin[j]
			area+=tmp
		return area
	def intersect(bbmin,bbmax,raypos,raydir):
		#want pos[i]+u*dir[i]=box[i]
		#u=(box[i]-pos[i])/dir[i]
		dim=len(bbmin)
		u0,u1=-float("inf"),float("inf")
		for i in range(dim):
			p,d=raypos[i],raydir[i]
			b0,b1=bbmin[i],bbmax[i]
			if abs(d)<=1e-20:
				if p<b0 or p>b1: return 0
				continue
			b0=(b0-p)/d
			b1=(b1-p)/d
			if b0>b1: b0,b1=b1,b0
			u0=b0 if b0>u0 else u0
			u1=b1 if b1<u1 else u1
			if u0>u1: return 0
		return 1
	def rand(): return random.random()*4-2
	def randn(m): return random.gauss(0,m)
	trials=1000
	samples=1000000
	for trial in range(trials):
		dim=trial%4+1
		outmin,outmax=[0]*dim,[0]*dim
		inmin,inmax=[0]*dim,[0]*dim
		for i in range(dim):
			a,b=rand(),rand()
			if a>b: a,b=b,a
			c,d=rand(),rand()
			if c>d: c,d=d,c
			if c<a: c=a
			if c>b: c=b
			if d<a: d=a
			if d>b: d=b
			outmin[i],outmax[i]=a,b
			inmin[i],inmax[i]=c,d
		outhits,inhits=0,0
		for sample in range(samples):
			raypos=[randn(4) for i in range(dim)]
			raydir=[randn(1) for i in range(dim)]
			if intersect(outmin,outmax,raypos,raydir):
				outhits+=1
				inhits+=intersect(inmin,inmax,raypos,raydir)
		calc=inhits/(outhits+1e-20)
		outarea=surfacearea(outmin,outmax)
		inarea=surfacearea(inmin,inmax)
		prob=inarea/(outarea+1e-20)
		print(dim,inhits,outhits)
		print("{0:.6f}".format(calc))
		print("{0:.6f}".format(prob))
		print("")

def AABBSpeedMain(triangles,trisize,spacing,rays,trials):
	def randvec(mul): return Vector(3).randomize()*random.gauss(0,mul)
	def makemesh(triangles,mat):
		mesh=Mesh(3)
		while triangles>0:
			pos=randvec(spacing)
			angs=[random.random()*6.283185 for i in range(3)]
			trans=Transform(pos,angs,random.gauss(0,trisize))
			if random.randrange(16):
				v=(mesh.addvertex(randvec(trisize),trans),
				   mesh.addvertex(randvec(trisize),trans),
				   mesh.addvertex(randvec(trisize),trans))
				mesh.addface(v,mat)
				triangles-=1
			else:
				tris=random.randrange(triangles+1)
				mesh.addmesh(makemesh(tris,mat),trans)
				triangles-=tris
		mesh.buildbvh()
		return mesh
	rendertime=0.0
	for trial in range(trials):
		t0=timer()
		sc=Scene(3,1,1)
		sc.maxbounces=8
		mat=MeshMaterial((1.0,1.0,1.0),1.0,0.3,0.5,0.5,0.5,0.5)
		sc.mesh=makemesh(triangles,mat)
		t0=timer()
		for r in range(rays):
			sc.raytrace(randvec(spacing),Vec(3).randomize())
		rendertime+=timer()-t0
	return rendertime

def AABBSpeedTest():
	import gc
	from time import sleep
	trials=11
	for trial in range(trials):
		gc.collect()
		sleep(5)
		time=0.0
		cost=(trial/float(trials-1))*1.0+0.0
		BVH.boxcost=cost
		random.seed(1)
		for tris in (100,1000):#,10000):
			for space in (1.0,10.0,100.0):
				time+=AABBSpeedMain(tris,1.0,space,1000,100)
		print("{0:.6f}: {1:.6f}".format(cost,time))

def AABBIntersectionTest():
	#Make sure that the BVH AABB calculates intersections correctly.
	print("testing AABB intersection test")
	def aabbdist(pos,bbmin,bbmax):
		u=0.0
		for i in range(len(pos)):
			p=pos[i]
			assert(math.isnan(p)==False)
			b0=bbmin[i]-p
			b1=bbmax[i]-p
			if b0<=0.0 and b1>=0.0: t=0.0
			else: t=min(abs(b0),abs(b1))
			if u<t: u=t
		return u
	def guessproj(raypos,raydir,raymin,raymax,bbmin,bbmax):
		ru=(raymin+raymax)*0.5
		rrad=(raymax-raymin)*0.5
		minu=ru
		mindist=float("inf")
		for i in range(20):
			for j in range(21):
				u=ru+rrad*(-1.0+j/10.0)
				dist=aabbdist(raypos+raydir*u,bbmin,bbmax)
				if u>=raymin and u<raymax:
					if mindist>dist or (mindist==dist and minu>u):
						mindist,minu=dist,u
			ru=minu
			rrad*=0.5
		return minu if mindist==0.0 else raymax
	def rand(x): return (random.random()-0.5)*2.0*x
	randrange=random.randrange
	Vec=Vector
	trials=10000
	for trial in range(trials):
		dim=randrange(6)+1
		raypos=Vec(dim).randomize()*20.0
		raydir=Vec(dim).randomize()
		if trial%8==0:
			raydir[randrange(dim)]=0.0
		raydir.normalize()
		raymin=rand(100.0)
		raymax=rand(100.0)
		if raymin>raymax:
			raymin,raymax=raymax,raymin
		bbmin,bbmax=Vec(dim),Vec(dim)
		for i in range(dim):
			a,b=rand(5.0),rand(5.0)
			if a>b: a,b=b,a
			bbmin[i],bbmax[i]=a,b
		node=BVHNode(dim)
		node.bbmin=bbmin
		node.bbmax=bbmax
		calc0=guessproj(raypos,raydir,raymin,raymax,bbmin,bbmax)
		calc1=node.intersect(raypos,raydir,raymin,raymax)
		#dist0=aabbdist(raypos+raydir*calc0,bbmin,bbmax)
		#dist1=aabbdist(raypos+raydir*calc1,bbmin,bbmax)
		if abs(calc0-calc1)>1e-4:
			print("calc",calc0,calc1)
			exit()
	print("passed")

#--------------------------------------------------------------------------------
#Bounding Sphere
#--------------------------------------------------------------------------------

"""
(v0+u*v1-c)^2=r^2
(v0+u*v1-c)^2=r^2
v2=v0-c

v2*v2+2*u*(v1*v2)+u*u*v1*v1-r^2=0
v2*v2+2*u*(v1*v2)+u*u*v1*v1-r^2=0
a=v1*v1
b=2*(v1*v2)
c=v2*v2-r*r
(-b+-sqrt(b^2-4ac))/(2a)
(-(v1*v2)+-sqrt((v1*v2)^2-(v1*v1)*(v2*v2-r*r)))/(v1*v1)

a=v1*v1
b=v1*v2
c=v2*v2-r*r
(-b+-sqrt(b^2-4ac))/(2a)
u=(-b+-sqrt(b*b-a*c))/a

want u0<u<u1

disc=b*b-a*c
u0*a<-b+-sqrt(disc)<u1*a
if -b+sqrt(disc)<u0*a or -b-sqrt(disc)>u1*a
if sqrt(disc)<(u0*a-b) or -sqrt(disc)>(u1*a+b)
if sqrt(disc)<(u0*a-b) or -sqrt(disc)>(u1*a+b)
"""

def BSMaxVector0(vecarr):
	def rand(): return (random.random()*2-1)
	dim=len(vecarr[0])
	maxsum=-float("inf")
	maxu=Vector(dim)
	for s in range(10):
		scale=1.0/(1<<s)
		baseu=maxu
		for trial in range(10000):
			u=Vector([x+rand()*scale for x in baseu]).normalize()
			sum=0.0
			for v in vecarr:
				d=u*v
				sum+=d*d
			if maxsum<sum:
				maxsum=sum
				maxu=u
	return (maxu,maxsum)

def BSMaxVector0(vecarr):
	def rand(): return (random.random()*2-1)
	dim=len(vecarr[0])
	maxsum=-float("inf")
	maxu=Vector(dim)
	for s in range(10):
		scale=1.0/(1<<s)
		baseu=maxu
		for trial in range(10000):
			u=Vector([x+rand()*scale for x in baseu]).normalize()
			sum=0.0
			for v in vecarr:
				d=u*v
				sum+=d*d
			if maxsum<sum:
				maxsum=sum
				maxu=u
	return (maxu,maxsum)

def BSMaxTest():
	dim=3
	def randvec(dim):
		return Vector([(random.random()-0.5)*10 for i in range(dim)])
	vecarr=[randvec(dim) for i in range(dim)]
	for i in range(dim):
		printvec(vecarr[i])
	print("")
	for i in range(5):
		u,s=BCMaxVector0(vecarr)
		printvec(u)
		print(s)

#--------------------------------------------------------------------------------
#OBB
#--------------------------------------------------------------------------------

#Guess vector that has the smallest min/max dot product among points.
#Make this the first column of the OBB rotation matrix.
#Find a new vector orthogonal to previous vectors.
#vec=Random(); vec-=prev*(prev*vec); vec.normalize()
#Repeat until all columns filled.

#({-1,0,1},{-1,0,1},...)*scale
#scale=2^-s
#Make orthogonal
#normalize
#find minproj maxproj

#--------------------------------------------------------------------------------
#Cube Primitive
#--------------------------------------------------------------------------------

def CubeCreateTest():
	sidearr=(1,1,1,1,1)
	mesh=Mesh(5)
	dim=mesh.dim
	sides=len(sidearr)
	assert(sides<=dim)
	verts=mesh.verts
	for i in range(1<<sides):
		v=Vector(dim)
		for j in range(sides):
			v[j]=sidearr[j]*(((i>>j)&1)-0.5)
		mesh.addvertex(v)
	if mesh.verts-verts<=dim:
		mesh.addface(range(verts,mesh.verts),mat)
		return
	sim=min(dim-1,sides)
	combos,perm=1,[0]*sim
	for i in range(sim): combos*=i+1
	for f in range(2*dim):
		axis=f>>1
		base=verts+((f&1)<<axis)
		#if base>=mesh.verts: continue
		for combo in range(combos):
			#print("----")
			for i in range(sim):
				j=combo%(i+1)
				combo//=i+1
				perm[i],perm[j]=perm[j],1<<(i+(i>=axis))
			#Find the vertices of the simplex. If the number of permutation inversions is
			#odd, then the sign of the normal will be negative.
			vertarr=[base]*(sim+1)
			for i in range(sim): vertarr[i+1]=vertarr[i]+perm[i]
			if vertarr[sim]>=mesh.verts: continue
			inv=sum(sum(perm[j]>perm[i] for j in range(i)) for i in range(sim))
			#print(perm,axis,f&1,inv)
			if ((inv^axis^f)&1)==0: vertarr[1],vertarr[2]=vertarr[2],vertarr[1]
			#if vertarr in ([2, 7, 6],[2, 3, 7]):
			#	vertarr[1],vertarr[2]=vertarr[2],vertarr[1]
			#print(vertarr)
			mesh.addface(vertarr,None)
			face=mesh.facearr[mesh.faces-1]
			print(face.vertarr[0].pos*face.norm)

def CubeTest():
	#Test our cube creation function.
	print("testing cube creation")
	raytests=1<<13
	inf=float("inf")
	for dim in range(0,7):
		print("dim: {0}".format(dim))
		mesh=Mesh(dim)
		cen=Vector(dim)
		minarea,maxarea=inf,-inf
		minedge,maxedge=inf,-inf
		mesh.addcube([1]*dim,None,None)
		print("faces: {0}".format(mesh.faces))
		for f in range(mesh.faces):
			face=mesh.facearr[f]
			vertarr=face.vertarr
			verts=len(vertarr)
			#Measure the face area.
			difarr=[vertarr[i].pos-vertarr[0].pos for i in range(1,verts)]
			area=abs(Vector.cross(difarr))
			if minarea>area: minarea=area
			if maxarea<area: maxarea=area
			#Measure the edge lengths.
			for i in range(1,verts):
				vpos=vertarr[i].pos
				for j in range(i):
					elen=abs(vpos-vertarr[j].pos)
					if minedge>elen: minedge=elen
					if maxedge<elen: maxedge=elen
			#Make sure the face normal is pointed outwards.
			faceoff=vertarr[0].pos if dim else cen
			facevert=set([x.id for x in vertarr])
			dot=face.norm*(faceoff-cen)
			if (dim!=0 and dot<1e-10) or (dim==0 and dot!=0.0):
				print("face normal not pointing out: {0:.10f}".format(dot))
				exit()
			for i in range(mesh.verts):
				vert=mesh.vertarr[i]
				dot=face.norm*(vert.pos-faceoff)
				if i in facevert:
					#All face vertices should have the same dot product.
					if abs(dot)>1e-10:
						print("face dot: {0:.10f}".format(dot))
						exit()
				else:
					#Otherwise, the vertex should be behind the face.
					if dot>0.0:
						print("other dot: {0:.10f}".format(dot))
						exit()
		#Shoot random rays and make sure they hit exactly 1 face.
		for i in range(raytests):
			ray=Ray(cen,Vector(dim).randomize())
			count=0
			for f in range(mesh.faces):
				face=mesh.facearr[f]
				count+=face.intersect(ray)
			if count!=1 and dim>0:
				print("ray test: {0}".format(count))
				exit()
		print("min area: {0:.9f}".format(minarea))
		print("max area: {0:.9f}".format(maxarea))
		print("min edge: {0:.9f}".format(minedge))
		print("max edge: {0:.9f}".format(maxedge))
	print("passed")

#--------------------------------------------------------------------------------
#Sphere Primitive
#--------------------------------------------------------------------------------
#Creating spheres based on tessalations will always be warped because there
#will be limited connectivity for each vertex. For instance, a vertex in an
#isometric sphere will always have 6 lines going off of it.

def SphereSimplexSplit(self,pos,rad,maxfaces,mat,transform=None):
	#Generates a sphere with at most maxfaces number of faces. First, generate a
	#diamond. Then, recursively subdivide each face.
	fbase=self.faces
	vbase=self.verts
	dim=self.dim
	minfaces=1<<dim
	base,pow,pow0=0,0,1
	while minfaces*pow0<=maxfaces and dim>1:
		base,pow,pow0=base+1,pow0,1
		for i in range(dim-1): pow0*=base+1
	print(base,minfaces*pow,maxfaces)
	pointarr=[Vector(dim) for i in range(dim*2)]
	for i in range(dim*2):
		pointarr[i][i>>1]=(i&1)*2.0-1.0
	pointmap=dict()
	def getpoint(idx,weights):
		arr=[(idx[i],weights[i]) for i in range(dim) if weights[i]]
		arr=tuple(sorted(arr))
		if not arr in pointmap:
			v=Vector(dim)
			for i,w in arr: v+=pointarr[i]*w
			pointmap[arr]=self.addvertex(v.normalize()).id
		return pointmap[arr]
	for f in range(minfaces):
		#Map out how to subdivide each face for each iteration. Simplex subdivision
		#algorithm by Goncalves, Palhares, Takahashi, and Mesquita.
		sidearr=[2*j+((f>>j)&1) for j in range(dim)]
		for n0 in range(pow):
			#Get the weights of the new face for existing vertices.
			weights=[[0]*dim for i in range(dim)]
			cor=0
			for b in range(base):
				weights[0][cor]+=1
				n=n0
				for i in range(1,dim):
					cor+=(n%base)==b
					weights[i][cor]+=1
					n//=base
			#Add the new face.
			arr=[getpoint(sidearr,weights[i]) for i in range(dim)]
			face=self.addface(arr,None)
			varr=face.vertarr
			if face.norm*varr[0].pos<0.0:
				varr[0],varr[1]=varr[1],varr[0]
	#Transform the vertices to global space and recalculate face values. Orient
	#normals before transforming.
	trans=Transform(pos,scale=rad)
	if transform: trans=transform.apply(trans)
	for v in range(vbase,self.verts):
		vert=self.vertarr[v]
		vert.pos=trans.apply(vert.pos)
	for f in range(fbase,self.faces):
		face=self.facearr[f]
		face.__init__(face.vertarr,mat)
		if dim==1 and f==fbase: face.norm=-face.norm

def SphereAddSpread(self,pos,rad,maxfaces,mat):
	#Creates a sphere mesh by evenly spreading out vertices and hull wrapping.
	#Default construction: 2^dim faces, 2*dim points. Every vertex adds dim-1 faces.
	#Thus we need 2^dim+k*(dim-1)=faces, k=(faces-2^dim)//(dim-1)+2*dim.
	iters=100
	dim=self.dim
	minfaces=(1<<dim)-(dim-1)
	minverts=2*dim-1
	if maxfaces<minfaces: return
	verts=(maxfaces-minfaces)//(dim-1)+minverts
	#Randomly seed the initial vertices. Use a custom PRNG for reproducibility.
	tr,mul=[1],2.0*2.0**-32
	def trand(): tr[0]=(tr[0]>>1)^(0xb4bcd35c&-(tr[0]&1));return tr[0]*mul-1.0
	varr=[Vector([trand() for j in range(dim)]).normalize() for i in range(verts)]
	buf=[Vector(dim) for i in range(verts)]
	#Evenly spread out the vertices. Uses algorithm from Joel Berman and Kit Hanes.
	for iter in range(iters):
		for i in range(verts): buf[i].zero()
		for i in range(1,verts):
			vi,bi=varr[i],buf[i]
			for j in range(i):
				dif=(vi-varr[j]).normalize()
				bi+=dif
				buf[j]-=dif
		for i in range(verts):
			varr[i]=buf[i].norm()
	#A helper function. Given an existing face and a vertex to replace, find a new
	#vertex flush with the hull and with a normal pointing outwards.
	faceset=set()
	def addface(farr,i):
		#The new face will have opposite rotation compared to its parent.
		farr[0],farr[1]=farr[1],farr[0]
		if i<2: i^=1
		off=farr[(i+1)%dim].pos
		cross=Vector(dim)
		best=None
		for j in range(vbase,self.verts):
			v=self.vertarr[j]
			#We've found a better vertex. See if the new normal points outward.
			if (v.pos-off)*cross>1e-10 or best is None:
				farr[i]=v
				off0=farr[0].pos
				cross2=Vector.cross([k.pos-off0 for k in farr[1:]])
				if cross2*off>1e-10:
					cross=cross2
					best=v
		#With the new vertex, create a new face.
		farr[i]=best
		farr=[v.id for v in farr]
		sarr=tuple(sorted(farr))
		if sarr in faceset: return
		faceset.add(sarr)
		self.addface(farr,None)
	#Calculate a set of vertices close to vertex 0. Use this as our first face.
	vsum=Vector(varr[0])
	for d in range(1,dim-1):
		mindist,minvert=-float("inf"),None
		for i in range(d,verts):
			dist=varr[i]*vsum
			if mindist<dist:
				mindist=dist
				minvert=i
		varr[minvert],varr[d]=varr[d],varr[minvert]
		vsum+=varr[d]
	vbase=self.verts
	fbase=self.faces
	for i in range(verts): self.addvertex(varr[i])
	addface(self.vertarr[vbase:vbase+dim],dim-1)
	#Create the rest of the faces.
	f=fbase
	while f<self.faces:
		face=self.facearr[f]
		for i in range(dim):
			farr=list(face.vertarr)
			addface(farr,i)
		f+=1
	#Transform the vertices to global space and recalculate face values.
	trans=Transform(pos,scale=rad)
	for v in range(vbase,self.verts):
		vert=self.vertarr[v]
		vert.pos=trans.apply(vert.pos)
	for f in range(fbase,self.faces):
		face=self.facearr[f]
		face.__init__(face.vertarr,mat)

def SphereEdgeSplit(self,pos,rad,maxfaces,mat,transform=None):
	dim=self.dim
	vbase=self.verts
	fbase=self.faces
	minfaces=1<<dim
	if maxfaces<minfaces: return
	if dim<=1: maxfaces=minfaces
	#Generate the initial diamond.
	for i in range(dim*2):
		point=[0.0]*dim
		point[i>>1]=(i&1)*2.0-1.0
		self.addvertex(point)
	class EdgeStats(object):
		def __init__(self,u,v):
			d=u.pos-v.pos
			self.len=d*d
			self.u=u
			self.v=v
			self.faceset=set()
			#self.weight=0
		def __lt__(a,b):
			if abs(a.len-b.len)>1e-10:
				return a.len>b.len
			return len(a.faceset)<len(b.faceset)
	#faceweight={}
	edgedict={}
	edgesort=[]
	edgepos=0
	def addedge(u,v,faceid):
		ui,vi=u.id,v.id
		assert(ui!=vi)
		tup=(ui,vi) if ui<vi else (vi,ui)
		if tup in edgedict:
			edge=edgedict[tup]
		else:
			edge=EdgeStats(u,v)
			edgedict[tup]=edge
			edge.sort=len(edgesort)
			edgesort.append(edge)
		if faceid is not None:
			edge.faceset.add(faceid)
			i=edge.sort
			while i>edgepos and edge<edgesort[i-1]:
				edgesort[i]=edgesort[i-1]
				edgesort[i].sort=i
				i-=1
			edgesort[i]=edge
			edge.sort=i
			#edge.weight+=faceweight[faceid]
		return edge
	def addface(arr):
		id=self.faces
		face=self.addface(arr,mat)
		#faceweight[id]=weight
		for i in range(1,dim):
			for j in range(i):
				u=face.vertarr[i]
				v=face.vertarr[j]
				addedge(u,v,id)
		return face
	for i in range(minfaces):
		arr=[vbase+2*j+((i>>j)&1) for j in range(dim)]
		face=addface(arr)
		varr=face.vertarr
		if dim>1 and face.norm*varr[0].pos<0.0:
			varr[0],varr[1]=varr[1],varr[0]
	arr=[0]*dim
	while True:
		if edgepos%128==0: print(edgepos)
		edge=edgesort[edgepos]
		edgepos+=1
		rem=fbase+maxfaces-self.faces
		if len(edge.faceset)>rem: break
		#edge=None
		#for e in edgedict.values():
		#	if (edge is None or edge>e) and len(e.faceset)<=rem:
		#		edge=e
		#if edge is None: break
		u,v=edge.u,edge.v
		#tup=(u.id,v.id) if u.id<v.id else (v.id,u.id)
		#del edgedict[tup]
		mid=self.addvertex((u.pos+v.pos).normalize())
		for faceid in edge.faceset:
			farr=self.facearr[faceid].vertarr
			#wt=faceweight[faceid]
			for i in range(dim):
				w=farr[i]
				arr[i]=w.id
				if w is u: arr[i]=mid.id
				if w is v: farr[i]=mid
				else:
					if w is not u:
						e=addedge(w,v,None)
						e.faceset.remove(faceid)
						#e.weight-=wt
					addedge(w,mid,faceid)
			#faceweight[faceid]+=1
			#for i in range(1,dim):
			#	for j in range(i):
			#		w0=farr[i]
			#		w1=farr[j]
			#		e=addedge(w0,w1,None)
			#		e.weight+=1
			addface(arr)
	trans=Transform(pos,scale=rad)
	if transform: trans=transform.apply(trans)
	"""for f in range(fbase,self.faces):
		face=self.facearr[f]
		varr=face.vertarr
		if face.norm*varr[0].pos<0.0:
			varr[0],varr[1]=varr[1],varr[0]"""
	for v in range(vbase,self.verts):
		vert=self.vertarr[v]
		vert.pos=trans.apply(vert.pos)
	for f in range(fbase,self.faces):
		face=self.facearr[f]
		face.__init__(face.vertarr,mat)
		#if dim==1 and f==fbase: face.norm=-face.norm

def SphereRotateCreate3(self,pos,rad,maxfaces,mat,transform=None):
	#Begin with a line and rotate it in "segs" segments to create a circle. Rotate
	#the circle in segments to create a sphere, etc. This will create square faces
	#that we tesselate like the face of a cube.
	dim=self.dim
	trans=Transform(pos,scale=rad)
	if transform: trans=transform.apply(trans)
	#Dimensions 0 and 1 are special cases.
	if dim<2 and maxfaces>dim:
		self.addcube([2.0]*dim,mat,trans)
		return
	#Find out how many segments we can support given maxfaces. We need at least 4
	#segments to create an enclosed volume.
	segs,hsegs,faces=0,0,0
	while faces<=maxfaces:
		segs,hsegs,faces=segs+2,hsegs+1,segs+4
		for i in range(dim-2):
			faces*=segs+(hsegs-1)*i
	if segs<4: return
	dim1=dim-1
	dim2=1<<dim1
	#There are several different rotations that can reach the same point on a sphere.
	#Reduce a given angle (with an offset) to a standard form. Also, generate the
	#vertex if it's new.
	vertmap=dict()
	def getangs(angs,offset):
		#Reduce angle to standard form. ang0=pi*2-ang0, ang1+=pi/2.
		std,carry=0,0
		for i in range(dim1):
			a=(angs//den[i]+carry+((offset>>i)&1))%segs
			if carry<0: a=0
			elif a==0 or a==hsegs: carry=-1
			else: carry=0
			if a>hsegs and i<dim-2:
				a=segs-a
				carry=hsegs
			std+=a*den[i]
		#Generate the vertex if it's new.
		if not std in vertmap:
			v=Vector([1.0]*dim)
			for d in range(dim1):
				u=((std//den[d])%segs)*(math.pi*2.0/segs)
				v[d+1]=v[d]*math.sin(u)
				v[d]*=math.cos(u)
			vertmap[std]=self.addvertex(v.normalize(),trans).id
		return std
	#Determine if a face is valid and unique.
	faceset=set()
	def facevalid(varr):
		varr=tuple(sorted(varr))
		for i in range(1,dim):
			if varr[i]==varr[i-1]: return False
		if varr in faceset: return False
		faceset.add(varr)
		return True
	#Loop through all possible square faces and tesselate them.
	cube=Mesh(dim)
	cube.addcube([1]*dim1,None)
	den=[1]*dim1
	for i in range(dim-3,-1,-1): den[i]=den[i+1]*segs
	basethres=segs if dim==2 else den[0]*hsegs
	for base in range(basethres):
		vertarr=[getangs(base,offset) for offset in range(dim2)]
		vertarr.sort()
		vertarr=[vertmap[p] for p in vertarr]
		#Certain faces need to be flipped to point outward.
		inv=(base%segs==segs-1)==((dim&2)>0)
		for f in range(cube.faces):
			idarr=cube.facearr[f].vertarr
			varr=[vertarr[v.id] for v in idarr]
			varr[0],varr[inv]=varr[inv],varr[0]
			if facevalid(varr): self.addface(varr,mat)

def SphereTest():
	#Test our sphere creation function.
	print("testing sphere creation")
	raytests=1<<13
	maxfaces=1<<11
	rad=1.0
	inf=float("inf")
	for dim in range(8):
		print("dim: {0}".format(dim))
		mesh=Mesh(dim)
		cen=Vector(dim)
		minarea,maxarea=inf,-inf
		minedge,maxedge=inf,-inf
		sumarea=0.0
		mesh.addsphere(cen,rad,maxfaces,None)
		#SphereSimplexSplit(mesh,cen,rad,maxfaces,None)
		#SphereEdgeSplit(mesh,cen,rad,maxfaces,None)
		#SphereAddSpread(mesh,cen,rad,maxfaces,None)
		#SphereRotateCreate3(mesh,cen,rad,maxfaces,None)
		#if dim==3: mesh.save("test_sphere.obj")
		print("faces: {0}".format(mesh.faces))
		if mesh.faces>maxfaces:
			print("incorrect faces: {0}".format(maxfaces))
			exit()
		#Verify that the distance from the center to the vertices is the radius.
		for i in range(mesh.verts):
			dist=abs(mesh.vertarr[i].pos-cen)
			dif=abs(dist-rad)
			if dif>=1e-10:
				print("radius:\n{0:.10f}\n{1:.10f}".format(dif,rad))
				exit()
		for f in range(mesh.faces):
			face=mesh.facearr[f]
			vertarr=face.vertarr
			verts=len(vertarr)
			#Measure the face area.
			area=FaceArea(face)
			sumarea+=area
			if minarea>area: minarea=area
			if maxarea<area: maxarea=area
			#Measure the edge lengths.
			for i in range(1,verts):
				vpos=vertarr[i].pos
				for j in range(i):
					elen=abs(vpos-vertarr[j].pos)
					if minedge>elen: minedge=elen
					if maxedge<elen: maxedge=elen
			#Make sure the face normal is pointed outwards.
			faceoff=vertarr[0].pos if dim else cen
			facevert=set([x.id for x in vertarr])
			dot=face.norm*(faceoff-cen)
			if (dim!=0 and dot<1e-10) or (dim==0 and dot!=0.0):
				print("face normal not pointing out: {0:.10f}".format(dot))
				exit()
			for i in range(mesh.verts):
				vert=mesh.vertarr[i]
				dot=face.norm*(vert.pos-faceoff)
				if i in facevert:
					#All face vertices should have the same dot product.
					if abs(dot)>1e-10:
						print("face dot: {0:.10f}".format(dot))
						exit()
				else:
					#Otherwise, the vertex should be behind the face.
					if dot>1e-10:
						print("other dot: {0:.10f}".format(dot))
						exit()
		#Shoot random rays and make sure they hit exactly 1 face.
		for i in range(raytests):
			ray=Ray(cen,Vector(dim).randomize())
			count=0
			for f in range(mesh.faces):
				face=mesh.facearr[f]
				count+=face.intersect(ray)
			if count!=1 and dim>0:
				print("ray test: {0}".format(count))
				exit()
		print("min area : {0:.9f}".format(minarea))
		print("max area : {0:.9f}".format(maxarea))
		print("min edge : {0:.9f}".format(minedge))
		print("max edge : {0:.9f}".format(maxedge))
		print("area     : {0:.9f}".format(sumarea))
	print("passed")

def SphereSpeedTest():
	#Test the speed of different sphere creation algorithms.
	print("testing sphere speed")
	mindim,maxdim=0,9
	maxfaces=1<<14
	trials=3
	funcs=2
	timearr=[0.0]*funcs
	for f in range(funcs):
		func=None
		if f==0: continue#func=SphereRotateCreate2
		if f==1: func=SphereRotateCreate3
		t0=timer()
		for trial in range(trials):
			for dim in range(mindim,maxdim):
				#print(f,trial,dim)
				mesh=Mesh(dim)
				cen=Vector(dim)
				func(mesh,cen,1.0,maxfaces,None)
		timearr[f]=timer()-t0
	for f in range(funcs):
		print("func {0}: {1:.6f}".format(f,timearr[f]))
	print("passed")

#--------------------------------------------------------------------------------
#Main
#--------------------------------------------------------------------------------

if __name__=="__main__":
	#SceneSpeedTest()
	#SceneRenderTest()
	#TransformTest()
	#BVHTestScene()
	#AABBProbTest()
	#AABBSpeedTest()
	#AABBIntersectionTest()
	#BSMaxTest()
	#CubeCreateTest()
	#CubeTest()
	SphereTest()
	#SphereSpeedTest()

