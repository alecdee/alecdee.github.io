"""------------------------------------------------------------------------"""
#--------------------------------------------------------------------------------

#Things to Remember
#Write an outline, then fill in details.
#Draw a small example. If that doesn't help, draw a bigger one.
#Draw a solution and work towards the definition. If that doesn't help, draw a
#bigger one.
#Keep different solution attempts in different functions to allow for testing.
#See if parts of the problem can be separated. For example: in a chess problem,
#bishops on black squares will never interact with bishops on white squares.
#Maximizing problems can be solved with bin search and a issolution() function.
#If the answer is a sequence, check if it can be calculated by a polynomial.
#If the input is extremely limited, it may require a precomputed lookup table.
#A tree is best treated as a graph.
#
#Complexity
#n<10^2  | n^3      | matrix ops, bottom-up dynamic programming
#n<10^3  | n^2      | compare pairs
#n<10^5  | nlogn    | sorting, heaping
#n<10^6  | n        | cumulative array, graph traversal, dynamic programming
#n<10^12 | n^0.5    | factoring
#n>10^12 | log(n)   | heap queries, binary search, prime testing
#        | constant | hash, array access, closed form computation
#

#!/usr/bin/pypy
import sys
if sys.version_info[0]<=2:
	range=xrange
	input=raw_input

def solve0():
	return None

cases=int(input())
for cs in range(1,cases+1):
	n,m=[int(a) for a in input().strip().split()]
	print("Case #"+str(cs)+": "+str(solve0()))

#Top-down dynamic programming template.
def dp(x):
	if x<2: return int(x>0)
	try: return dp.table[x]
	except AttributeError: dp.table=dict()
	except KeyError: pass
	y=dp(x-1)+dp(x-2)
	dp.table[x]=y
	return y

#Bottom-up dynamic programming template
def dp(wvarr,maxweight):
	dpdict={0:0}
	for wv in wvarr:
		w0,v0=wv
		dp0=dict()
		for w1,v1 in dpdict.items():
			w2=w0+w1
			if w2<=maxweight: dp0[w2]=v0+v1
			else: dp0[w1]=v1
		dpdict=dp0
	return max(dpdict.values())

sys.setrecursionlimit(2000)

type(x)

#Ternary:
y="true" if x<10 else "false"
y=x<10 and "true" or "false"    #doesn't work for false values

#Default variables/functions
dir(__builtins__)

#Python rounds towards -inf.
# 13// 7=1
# 13//-7=-2
#-13// 7=-2
#-13//-7=1

#Strings
"{0:32b}".format(x)  #Format as binary
"{0:.10f}".format(x) #Format as float

#Allocation speed test for n=100000000:
#[0]*n  : 0.480717
#[0 for]: 1.556651
#append : 9.625169

#sqrt speed test:
#sqrt  : 0.108371
#m.sqrt: 0.110604
#**0.5 : 0.729807

#regex
#re.search is faster than re.match.
re.match(".*hello$",string) #if the regex is found in the string
re.find("\d+",string)       #find all integers

#dict
dict([(1,[]),(2,"a"),(3,3),(4,10)])
{1:[],2:"a",3:3,4:10}

#files
os.path.getsize("file")

#pygame
import sys,pygame
pygame.init()
screen=pygame.display.set_mode((800,600))
clock=pygame.time.Clock()
font=pygame.font.SysFont(None,20)
def drawtext(x,y,msg):
	text=font.render(msg,True,(255,0,0))
	screen.blit(text,(x,y))
while True:
	for evt in pygame.event.get():
		if evt.type==pygame.QUIT or (evt.type==pygame.KEYDOWN and evt.key==27):
			pygame.quit();sys.exit()
	screen.fill((0,0,0))
	for i in range(4):
		p=(-0.5+(i&1),-0.5+((i>>1)&1))
		p=(p[0]*50+400,p[1]*50+300)
		pygame.draw.ellipse(screen,(255,0,0),(p[0],p[1],5,5))
		drawtext(p[0],p[1],str(i))
	pygame.display.flip()
	clock.tick(30)

#OOP
class A:
	def __init__(self,name):
		self.name=name
	def print(self):
		print("A "+str(self.name))
class B:
	def __init__(self,name,age):
		self.name=name
		self.age=age
	def print(self):
		print("B "+str(self.name)+" "+str(self.age))
class C(A,B):
	def __init__(self,name,age):
		A.__init__(self,name)
		B.__init__(self,name,age)
	def print(self):
		A.print(self)
		B.print(self)
c=C("name1",3)
c.print()

#Highlighting
#Default: 0x000000, background: 0xffffff
#
#Comments: 0x0000ff
#
#Strings: 0xff00ff
#"text"
#"""text"""
#
#Numbers: 0xff00ff
#x=00000
#x=0x947
#
#Special value group: 0xff00ff
#Ellipsis False None True
#
#Import group: 0xa020f0
#as from import
#
#Builtin group: 0x008a9d
#__build_class__ __debug__ __doc__ __import__ __loader__ __name__ __package__
#__spec__ abs all any ascii bin bool bytearray bytes callable chr classmethod
#compile complex copyright credits delattr dict dir divmod enumerate eval exec
#exit filter float format frozenset getattr globals hasattr hash help hex id
#input int isinstance issubclass iter len license list locals map max memoryview
#min next object oct open ord pow print property quit range repr reversed round
#set setattr slice sorted staticmethod str sum super tuple type vars zip
#
#Keyword group: 0xa52a2a bold
#and assert break class continue def del elif else except exec finally for global
#if in is lambda not or pass print raise return try while with yield
#
#Exception group: 0x2e8b57 bold
#ArithmeticError AssertionError AttributeError BaseException BlockingIOError
#BrokenPipeError BufferError BytesWarning ChildProcessError
#ConnectionAbortedError ConnectionError ConnectionRefusedError
#ConnectionResetError DeprecationWarning EOFError EnvironmentError Exception
#FileExistsError FileNotFoundError FloatingPointError FutureWarning GeneratorExit
#IOError ImportError ImportWarning IndentationError IndexError InterruptedError
#IsADirectoryError KeyError KeyboardInterrupt LookupError MemoryError NameError
#NotADirectoryError NotImplemented NotImplementedError OSError OverflowError
#PendingDeprecationWarning PermissionError ProcessLookupError RecursionError
#ReferenceError ResourceWarning RuntimeError RuntimeWarning StopAsyncIteration
#StopIteration SyntaxError SyntaxWarning SystemError SystemExit TabError
#TimeoutError TypeError UnboundLocalError UnicodeDecodeError UnicodeEncodeError
#UnicodeError UnicodeTranslateError UnicodeWarning UserWarning ValueError Warning
#ZeroDivisionError

