# SuffixArrayTest - v1.00
#
# Copyright 2022 Alec Dee - MIT license - SPDX: MIT
# alecdee.github.io - akdee144@gmail.com

# Python2 compatibility.
import sys
if sys.version_info[0]<=2:
	range=xrange
	input=raw_input

#---------------------------------------------------------------------------------
# Sorting Prototypes
#---------------------------------------------------------------------------------

def SuffixSort0(self):
	snt=[0x7ffffff]*self.sufs
	for s in self.sentinels:
		snt[s]=s
	def lt(a,b):
		return snt[a]<snt[b] or (snt[a]==snt[b] and (seq[a]<seq[b] or (seq[a]==seq[b] and lt(a+1,b+1))))
	def eq(a,b):
		return snt[a]==snt[b] and seq[a]==seq[b]
	seq=self.seq
	sa=self.sa
	sufs=self.sufs
	for i in range(1,sufs):
		j=i
		suf=sa[j]
		while j and lt(suf,sa[j-1]):
			sa[j]=sa[j-1]
			j-=1
		sa[j]=suf
	# Build inverse.
	inv=self.inv
	for i in range(sufs):
		inv[sa[i]]=i
	# Kasai LCP construction
	lcp=self.lcp
	k=0
	for a in range(sufs):
		i=inv[a]
		if i:
			b=sa[i-1]
			l=sufs-max(a,b)
			while k<l and eq(a+k,b+k):
				k+=1
		lcp[i]=k
		k-=k>0

def SuffixSort1(self):
	snt=[0x7ffffff]*self.sufs
	for s in self.sentinels:
		snt[s]=s
	def lt(a,b):
		return snt[a]<snt[b] or (snt[a]==snt[b] and (seq[a]<seq[b] or (seq[a]==seq[b] and inv[a+1]<inv[b+1])))
	def eq(a,b):
		return snt[a]==snt[b] and seq[a]==seq[b]
	seq=self.seq
	sa=self.sa
	sufs=self.sufs
	inv=self.inv
	for i in range(sufs):
		j=sufs-1-i
		sa[i]=j
		inv[j]=i
	for i in range(1,sufs):
		j=i
		suf=sa[j]
		while j and lt(suf,sa[j-1]):
			sa[j]=sa[j-1]
			inv[sa[j]]=j
			j-=1
		sa[j]=suf
		inv[suf]=j
	# Kasai LCP construction
	lcp=self.lcp
	k=0
	for a in range(sufs):
		i=inv[a]
		if i:
			b=sa[i-1]
			while eq(a+k,b+k):
				k+=1
		lcp[i]=k
		k-=k>0

def SuffixSort2(self):
	sufs=self.sufs
	sents=len(self.sentinels)
	rank=[0x7ffffff]*sufs
	for i in range(sents):
		rank[self.sentinels[i]]=i
	def lt0(a,b):
		return rank[a]<rank[b] or (rank[a]==rank[b] and seq[a]<seq[b])
	seq=self.seq
	sa=self.sa
	inv=self.inv
	lcp=self.lcp
	step=1
	while step<sufs:
		dst,end1=0,0
		while dst<sufs:
			if dst==end1:
				pos0=dst
				end0=dst+step
				pos1=end0
				end1=min(end0+step,sufs)
			if pos0<end0 and (pos1>=end1 or lt0(sa[pos0],sa[pos1])):
				lcp[dst]=sa[pos0]
				pos0+=1
			else:
				lcp[dst]=sa[pos1]
				pos1+=1
			dst+=1
		sa,lcp=lcp,sa
		step+=step
	cnt=sents
	for i in range(cnt,sufs):
		if i!=cnt and seq[sa[i]]!=seq[sa[i-1]]:
			cnt=i
		rank[sa[i]]=cnt
	self.sa,self.lcp=sa,lcp
	# for i in range(sufs):
	# 	line="{0:02d} ".format(rank[sa[i]])+self.sufstr(i)
	# 	print(line)
	# exit()
	def lt(a,b):
		return rank[a]<rank[b] or (rank[a]==rank[b] and inv[a+1]<inv[b+1])
	for i in range(sufs):
		j=sufs-1-i
		sa[i]=j
		inv[j]=i
	for i in range(1,sufs):
		j=i
		suf=sa[j]
		while j and lt(suf,sa[j-1]):
			sa[j]=sa[j-1]
			inv[sa[j]]=j
			j-=1
		sa[j]=suf
		inv[suf]=j
	# Kasai's LCP construction
	l=0
	for a in range(sufs):
		i=inv[a]
		if i:
			b=sa[i-1]+l
			l+=a
			while inv[l]>=sents and inv[b]>=sents and seq[l]==seq[b]:
				l+=1
				b+=1
			l-=a
		lcp[i]=l
		l-=l>0

def SuffixSort3(self):
	sufs=self.sufs
	if sufs==0:
		return
	sents=len(self.sentinels)
	inv=self.inv
	seq=self.seq
	sa=self.sa
	lcp=self.lcp
	for i in range(sufs):
		sa[i]=i
	for i in range(sents):
		s=self.sentinels[i]
		inv[s]=i
		sa[s]=sa[i]
		sa[i]=s
		lcp[i]=s
	# Perform order 1 sorting.
	step=1
	while step<sufs:
		dst,stop1=sents,0
		while dst<sufs:
			if dst>=stop1:
				start0=dst
				stop0=dst+step
				start1=stop0
				stop1=min(stop0+step,sufs)
			if start0<stop0 and (start1>=stop1 or seq[sa[start0]]<seq[sa[start1]]):
				lcp[dst]=sa[start0]
				start0+=1
			else:
				lcp[dst]=sa[start1]
				start1+=1
			dst+=1
		sa,lcp=lcp,sa
		step+=step
	self.sa,self.lcp=sa,lcp
	# Group into buckets. [next,end,....]
	prev,start=0,sents
	for i in range(start,sufs+1):
		if i==sufs or seq[sa[i]]!=seq[sa[start]]:
			if i-start>1:
				lcp[prev]=start
				prev=start
				lcp[prev+1]=i
			start=i
		if i<sufs:
			inv[sa[i]]=start
	lcp[prev]=sufs
	# Perform group sorting.
	bits=(sufs-1).bit_length()
	count=[0]*256
	step=1
	while lcp[0]<sufs:
		prev,start=0,lcp[0]
		while start<sufs:
			next,stop=lcp[start],lcp[start+1]
			if stop-start<20:
				for i in range(start+1,stop):
					j,s=i,sa[i]
					r=inv[s+step]
					while j>start and r<inv[sa[j-1]+step]:
						sa[j]=sa[j-1]
						j-=1
					sa[j]=s
			else:
				src,dst=sa,lcp
				for shift in range(0,bits,8):
					for i in range(256):
						count[i]=0
					for i in range(start,stop):
						v=(inv[src[i]+step]>>shift)&255
						count[v]+=1
					total=start
					for i in range(256):
						tmp=count[i]
						count[i]=total
						total+=tmp
					for i in range(start,stop):
						v=(inv[src[i]+step]>>shift)&255
						dst[count[v]]=src[i]
						count[v]+=1
					src,dst=dst,src
				for i in range(start,stop):
					sa[i]=src[i]
			# Store the sorting values ahead of time, or we'll be using values as they're
			# being modified.
			for i in range(start,stop):
				lcp[i]=inv[sa[i]+step]
			for i in range(start+1,stop+1):
				if i==stop or lcp[i]!=lcp[start]:
					if i-start>1:
						lcp[prev]=start
						prev=start
						lcp[prev+1]=i
					start=i
				if i<stop:
					inv[sa[i]]=start
			lcp[prev]=next
			start=next
		step+=step
	# Kasai's LCP construction.
	l=0
	for a in range(sufs):
		i=inv[a]
		if i:
			b=sa[i-1]+l
			l+=a
			while inv[l]>=sents and inv[b]>=sents and seq[l]==seq[b]:
				l+=1
				b+=1
			l-=a
		lcp[i]=l
		l-=l>0

#---------------------------------------------------------------------------------
# Operation Prototypes
#---------------------------------------------------------------------------------

def SuffixFindFirst0(self,s):
	"""Finds the first i such that sa[i][0,1,2,...]=s."""
	global ops
	lo,hi=0,self.sufs-1
	seq=self.seq
	sa,la=self.sa,self.la
	slen=len(s)
	while lo<hi:
		mid=(lo+hi)//2
		mlen=min(la[mid],slen)
		suf=sa[mid]
		lt=mlen<slen
		eq=0
		while eq<mlen:
			ops+=1
			if seq[suf+eq]!=s[eq]:
				lt=seq[suf+eq]<s[eq]
				break
			eq+=1
		if lt:
			lo=mid+1
		else:
			hi=mid
	if lo>=self.sufs or la[lo]<slen:
		return None
	suf=sa[lo]
	eq=0
	while eq<slen and seq[suf+eq]==s[eq]:
		eq+=1
	if eq==slen:
		return lo
	return None

def SuffixFindFirst1(self,s):
	"""Finds the first i such that sa[i][0,1,2,...]=s."""
	# Avoids worst case when sa=s="aaaaaaa...".
	global ops
	lo,hi=0,self.sufs-1
	if lo>hi:
		return None
	loeq,hieq=0,0
	seq=self.seq
	sa,la=self.sa,self.la
	slen=len(s)
	suf=sa[hi]
	while hieq<slen:
		ops+=1
		if seq[suf+hieq]!=s[hieq]:
			break
		hieq+=1
	while lo<hi:
		mid=(lo+hi)//2
		mlen=min(la[mid],slen)
		suf=sa[mid]
		lt=mlen<slen
		eq=min(loeq,hieq)
		while eq<mlen:
			ops+=1
			if seq[suf+eq]!=s[eq]:
				lt=seq[suf+eq]<s[eq]
				break
			eq+=1
		if lt:
			lo=mid+1
			loeq=eq
		else:
			hi=mid
			hieq=eq
	return None if hieq<slen else hi

#---------------------------------------------------------------------------------
# Testing
#---------------------------------------------------------------------------------

def SuffixArrayTest():
	print("Testing suffix array.")
	# Canary for the suffix array sentinels. Should never be read/compared with.
	class Canary(object):
		def __init__(self):
			pass
		def __lt__(self,other):
			assert(False)
		def __eq__(self,other):
			assert(False)
	# Test suffix.
	class Suffix(object):
		def __init__(self,seq,idx,id):
			self.seq=seq
			self.idx=idx
			self.id=id
		def __str__(a):
			seq=a.seq
			line="{0:02d}: ".format(a.idx+a.id)
			for i in range(a.idx,len(seq)):
				line+=str(seq[i])+","
			line+="$"+str(len(seq)+a.id)
			return line
		def __lt__(a,b):
			la=len(a.seq)-a.idx
			lb=len(b.seq)-b.idx
			for i in range(min(la,lb)):
				ca,cb=a.seq[a.idx+i],b.seq[b.idx+i]
				if ca!=cb:
					return ca<cb
			if la!=lb:
				return la<lb
			return a.id<b.id
		def lcp(a,b):
			l=min(len(a.seq)-a.idx,len(b.seq)-b.idx)
			lcp=0
			while lcp<l and a.seq[a.idx+lcp]==b.seq[b.idx+lcp]:
				lcp+=1
			return lcp
		def eqsa(a,sa,b):
			orig=b
			lb=sa.la[b]
			b=sa.sa[b]
			if a.idx+a.id!=b:
				print("idx mismatch: "+str(orig))
				return False
			la=len(a.seq)-a.idx
			if la!=lb:
				print("len mismatch")
				return False
			for i in range(la):
				if a.seq[a.idx+i]!=sa.seq[b+i]:
					print("char mismatch")
					return False
			return True
	# Error reporting.
	def error(sa,sb,arr):
		print("seqarr=(")
		for seq in arr:
			print("\t("+",".join(map(str,seq))+",),")
		print(")")
		print("-"*64)
		for i in range(sa.sufs):
			print(sa.sufstr(i))
		print("-"*64)
		for b in sb:
			print(str(b))
		exit()
	# Begin testing sequences.
	# seed(0)
	t0=time()
	ts=0.0
	trials=100000
	maxseqs=10
	maxlen=32
	for trial in range(trials):
		maxoff=1<<randrange(8)
		maxval=1<<randrange(16)
		seqs=randrange(maxseqs+1)
		seqarr=[None]*seqs
		sa=SuffixArray()
		sb=[]
		for i in range(len(seqarr)):
			# If we haven't supplied a test sequence, generate one.
			if seqarr[i]==None:
				n=randrange(maxlen)
				off=randrange(-maxoff,maxoff+1)
				l,r=off-maxval,off+maxval+1
				seqarr[i]=tuple([randrange(l,r) for j in range(n)])
			# Load the test sequence.
			seq=seqarr[i]
			base=sa.addstr(seq)
			sa.seq[sa.sufs-1]=Canary()
			for j in range(len(seq)+1):
				sb.append(Suffix(seq,j,base))
		# Perform the suffix sort.
		try:
			t1=time()
			sa.sort()
			ts+=time()-t1
			sb.sort()
		except:
			print("sorting error")
			error(sa,sb,seqarr)
		# Compare the default sort with the suffix array.
		if sa.sufs!=len(sb):
			print("sufs!=len")
			error(sa,sb,seqarr)
		for i in range(len(sb)):
			# Test order.
			if not sb[i].eqsa(sa,i):
				error(sa,sb,seqarr)
			# Test lcp.
			lcp=sb[i].lcp(sb[i-1]) if i else 0
			if sa.lcp[i]!=lcp:
				print("lcp mismatch")
				error(sa,sb,seqarr)
			# Test inverse mapping.
			if sa.inv[sa.sa[i]]!=i:
				print("inv mismatch")
				error(sa,sb,seqarr)
	print("sort time : {0:0.6f}".format(ts))
	print("total time: {0:0.6f}".format(time()-t0))
	print("Passed.")

def SuffixArraySpeedTest():
	print("Testing suffix array speed.")
	# Begin testing sequences.
	seed(0)
	trials=10000
	maxseqs=10
	maxlen=3000
	t0=time()
	for trial in range(trials):
		maxoff=1<<randrange(8)
		maxval=1<<randrange(16)
		seqs=randrange(maxseqs+1)
		# Add sequences to the suffix array.
		sa=SuffixArray()
		for i in range(seqs):
			n=randrange(maxlen)
			off=randrange(-maxoff,maxoff+1)
			l,r=off-maxval,off+maxval+1
			seq=[randrange(l,r) for j in range(n)]
			sa.addstr(seq)
		# Perform the suffix sort.
		sa.sort()
	print("time: {0:0.6f}".format(time()-t0))
	print("Passed.")

def SuffixOperationTest():
	print("Testing suffix array operations.")
	# Canary for the suffix array sentinels. Should never be read/compared with.
	class Canary(object):
		def __init__(self):
			pass
		def __lt__(self,other):
			assert(False)
		def __eq__(self,other):
			assert(False)
	# Trivial implementations of the suffix array operations.
	def FindFirst(sa,s):
		slen=len(s)
		seq=sa.seq
		for i in range(sa.sufs):
			l=sa.la[i]
			if l<slen:
				continue
			j,idx=0,sa.sa[i]
			while j<slen and seq[idx+j]==s[j]:
				j+=1
			if j==slen:
				return i
		return None
	def FindLast(sa,s):
		slen=len(s)
		seq=sa.seq
		for i in range(sa.sufs-1,-1,-1):
			l=sa.la[i]
			if l<slen:
				continue
			j,idx=0,sa.sa[i]
			while j<slen and seq[idx+j]==s[j]:
				j+=1
			if j==slen:
				return i
		return None
	# Error reporting.
	def error(sa,arr):
		print("seqarr=(")
		for seq in arr:
			print("\t("+",".join(map(str,seq))+",),")
		print(")")
		# for i in range(sa.sufs):
		# 	print("{0:02d} ".format(i)+sa.sufstr(i))
		exit()
	# Begin testing operations.
	seed(0)
	trials=10000
	maxseqs=10
	maxlen=64
	for trial in range(trials):
		maxoff=1<<randrange(8)
		maxval=1<<randrange(16)
		seqs=randrange(maxseqs+1)
		seqarr=[None]*seqs
		sa=SuffixArray()
		for i in range(len(seqarr)):
			# If we haven't supplied a test sequence, generate one.
			if seqarr[i]==None:
				n=randrange(maxlen)
				off=randrange(-maxoff,maxoff+1)
				l,r=off-maxval,off+maxval+1
				seqarr[i]=[randrange(l,r) for j in range(n)]
			# Load the test sequence.
			seq=seqarr[i]
			base=sa.addstr(seq)
			sa.seq[sa.sufs-1]=Canary()
		sa.sort()
		# Test the substring finding operations.
		for f in range(100):
			if randrange(2) and seqs:
				# Pick a substring from the generating strings.
				seq=seqarr[randrange(seqs)]
				slen=len(seq)
				i,j=randrange(slen+1),randrange(slen+1)
				i,j=min(i,j),max(i,j)
				seq=tuple(seq[i:j])
			else:
				# Generate a random string.
				slen=randrange(maxlen)
				off=randrange(-maxoff,maxoff+1)
				l,r=off-maxval,off+maxval+2
				seq=tuple([randrange(l,r) for j in range(slen)])
			# Find the first occurrence in the suffix array.
			first0=FindFirst(sa,seq)
			first1=sa.findfirst(seq)
			if first0!=first1 or first0!=None and (first0<0 or first0>=sa.sufs):
				print("find first mismatch: "+str(first0)+", "+str(first1))
				print("seq: "+str(seq))
				error(sa,seqarr)
			# Find the last occurrence in the suffix array.
			last0=FindLast(sa,seq)
			last1=sa.findlast(seq)
			if last0!=last1 or last0!=None and (last0<0 or last0>=sa.sufs):
				print("find last mismatch: "+str(last0)+", "+str(last1))
				print("seq: "+str(seq))
				error(sa,seqarr)
			if (first0==None and last0!=None) or (first0!=None and first0>last0):
				print("first>last: "+str(first0)+" > "+str(last0))
				error(sa,seqarr)
		# Test unique substring counting.
		st=set()
		for seq in seqarr:
			for i in range(1,len(seq)+1):
				for j in range(i):
					st.add(tuple(seq[j:i]))
		if len(st)!=sa.substrings():
			print("miscount unique substrings: "+str(len(st))+", "+str(sa.substrings()))
			error(sa,seqarr)
	print("Passed.")

def SuffixCompTest():
	print("Testing suffix array complexity.")
	# global ops
	# slen=256
	# sa=SuffixArray("a"*slen)
	# for i in range(slen):
	# 	ops=0
	# 	sa.findfirst("a"*i)
	# 	est=3*i+int(log(slen+1)/log(2))+1
	# 	print("{0:02d}: {1:d} {2:d}".format(i,ops,est))
	sa=SuffixArray("abcd")
	print(sa.substrings())
	print("Passed.")

if __name__=="__main__":
	from random import randrange,seed
	from time import time
	from math import log
	# sa=SuffixArray("banana","ananab","hammock")
	# print(str(sa))
	SuffixArrayTest()
	# SuffixArraySpeedTest()
	SuffixOperationTest()
	# SuffixCompTest()

