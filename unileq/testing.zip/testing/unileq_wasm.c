/*
unileq.c - v1.32

Copyright (C) 2020 by Alec Dee - alecdee.github.io - akdee144@gmail.com

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies
of the Software, and to permit persons to whom the Software is furnished to do
so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS
FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

--------------------------------------------------------------------------------
The Unileq Architecture

The goal of unileq is to create the functionality of a normal computer using
only one computing instruction. This is like trying to build a working car out
of legos while only using one type of lego piece. Since we only have one
instruction, most modern conveniences are gone. Things like multiplying numbers
or memory allocation need to built from scratch using unileq's instruction.

The instruction is fairly simple: Given A, B, and C, compute mem[A]-mem[B] and
store the result in mem[A]. Then, if mem[A] was less than or equal to mem[B],
jump to C. Otherwise, jump by 3. We use the instruction pointer (IP) to keep
track of our place in memory. The pseudocode below shows a unileq instruction:


     A=mem[IP+0]
     B=mem[IP+1]
     C=mem[IP+2]
     if mem[A]<=mem[B]
          IP=C
     else
          IP=IP+3
     mem[A]=mem[A]-mem[B]


The instruction pointer and memory values are all 64 bit unsigned integers.
Overflow and underflow are handled by wrapping values around to be between 0 and
2^64-1 inclusive.

Interaction with the host environment is done by reading and writing from
special memory addresses. For example, writing anything to -1 will end execution
of the unileq program.

--------------------------------------------------------------------------------
Unileq Assembly Language

We can write a unileq program by setting the raw memory values directly, but it
will be easier to both read and write a program by using an assembly language.
Because there's only one instruction, we can omit any notation specifying what
instruction to execute on some given memory values. The flow of the program will
decide what gets executed and what doesn't.

An outline of our language is given below:

#Single line comment.

#|
     multi line
     comment
|#

?
     Inserts the current memory address.

Label:
     Label declaration. Declarations mark the current memory address for later
     recall. Declarations can't appear within an expression, ex: "0 label: +1".
     Duplicate declarations are an error.

     Labels are case sensitive and support UTF-8.
     First character    : a-zA-Z_.    and any character with a high bit
     Trailing characters: a-zA-Z_.0-9 and any character with a high bit

Label
     Inserts the memory address marked by "Label:". There must be whitespace or
     an operator between any two label recalls or numbers.

.Sublabel
     Shorthand for placing a label under another label's scope.
     Ex: "lbl:0 .sub:1" will be treated as "lbl:0 lbl.sub:1" internally.

Number
     Inserts the number's value. A number must be in decimal or hexadecimal
     form, such as "123" or "0xff".

Operator +-
     Adds or subtracts the number or label from the previous value. Parentheses
     are not supported. To express a negative number, use its unsigned form or
     the identity "0-x=-x".

     There cannot be two consecutive operators, ex: "0++1". Also, the program
     cannot begin or end with an operator.

Input/Output
     Interaction with the host environment can be done by reading or writing
     from special addresses.

     A = -1: End execution.
     A = -2: Write mem[B] to stdout.
     B = -3: Subtract stdin from mem[A].
     B = -4: Subtract current time from mem[A].

Difficult to interact with page.
Have to create a virtual memory pool to dynamically allocate memory and pass
data between javascript and webassembly.
Still slow on some platforms.
Wait until host bindings and garbage collection become standard.

--------------------------------------------------------------------------------

Embed with base64 so it doesn't need to be dynamically loaded.

Python:
import base64
with open("unileq_wasm.wasm","rb") as f: bytearr=f.read()
base=str(base64.b64encode(bytearr))
for i in range(2,len(base)-2,99):
	line=base[i:i+99]
	if line[-1]=="'": line=line[:-1]
	print(line+"\\")

Javascript:
var unileq_binary=Uint8Array.from(window.atob("..."),(c)=>c.charCodeAt(0));

--------------------------------------------------------------------------------
*/

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>
#include <time.h>

typedef uint32_t u32;
typedef uint64_t u64;
typedef unsigned char uchar;

const char* SOURCE="\
#|==============================================================================\n\
\n\
Unsigned Integer Testing - v1.05\n\
\n\
Author: Alec Dee - alecdee.github.io - akdee144@gmail.com\n\
\n\
--------------------------------------------------------------------------------\n\
\n\
Linux:\n\
rm unileq\n\
rm unileq.gcda\n\
gcc -fprofile-generate -march=native -O3 ../site/unileq/unileq.c -o unileq\n\
./unileq perftest.unl\n\
gcc -fprofile-use -march=native -O3 ../site/unileq/unileq.c -o unileq\n\
rm unileq.gcda\n\
time ./unileq perftest.unl\n\
\n\
Windows:\n\
remove-item \"unileq.exe\"\n\
remove-item \"default.*\"\n\
clang -O3 -fprofile-instr-generate -march=native unileq.c -o unileq.exe\n\
.\\unileq.exe\n\
remove-item \"default.*\"\n\
.\\unileq.exe perftest.unl\n\
llvm-profdata merge -output=\"default.profdata\" \"*.profraw\"\n\
clang -O3 -fprofile-instr-use=\"default.profdata\" -march=native unileq.c -o unileq.exe\n\
.\\unileq.exe\n\
(measure-command {.\\unileq.exe perftest.unl | Out-Default}).TotalSeconds\n\
\n\
--------------------------------------------------------------------------------\n\
Notes\n\
\n\
To compile the necessary files together, run\n\
cat uinttest.unl uint.unl print.unl random.unl > test.unl\n\
./unileq test.unl\n\
\n\
average instructions per function\n\
cmp: 28\n\
set: 24\n\
neg: 25\n\
add: 30\n\
sub: 31\n\
mul: 878\n\
div: 911\n\
shl: 83\n\
shr: 131\n\
not: 26\n\
and: 469\n\
 or: 470\n\
xor: 471\n\
\n\
|#\n\
\n\
0 0 test.main\n\
\n\
test.main:\n\
	#Starting integer tests.\n\
	0 ? print 115 116 97 114 116 105 110 103 32 105 110 116 101 103 101 114 32 116 101 115 116 115 10 0\n\
\n\
	#------------------------- Bits -------------------------\n\
	#Calculate how many bits we're using. Set [hbit]=1<<(bits-1).\n\
	.tmp0     .z-1   ?+1\n\
	.bitloop:\n\
	.tmp0     .z     .bitdone\n\
	.hbit     .hbit  ?+1\n\
	.hbit     .tmp0  ?+1\n\
	.tmp0     .hbit  ?+1\n\
	.bits     .z-1   .bitloop\n\
	.bitdone:\n\
\n\
	#Set other bit related values.\n\
	.nbits    .bits  ?+1\n\
	.nbits-1  .bits  ?+1\n\
	.bits+1   .nbits ?+1\n\
	.bits+2   .nbits ?+1\n\
	.shiftmax .nbits ?+1\n\
	.shiftmax .nbits ?+1\n\
	.shiftmax .nbits ?+1\n\
	.shiftsub .nbits ?+1\n\
	.shiftsub .z-2   ?+1\n\
\n\
	0 ? print 98 105 116 115 58 32 0-1 .bits 10 0\n\
\n\
.loop:\n\
	#While trial<trials.\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .trials ?+1\n\
	.tmp1 .tmp1 ?+1\n\
	.tmp1 .tmp0 ?+1\n\
	.tmp1 .trial .done\n\
\n\
	#---------------------- Parameters ----------------------\n\
	#Generate A, B, and C parameters.\n\
	0 ? test.rand.uint .a\n\
	0 ? test.rand.uint .b\n\
	0 ? random.mod     .c .shiftmax\n\
	.c .shiftsub ?+1\n\
\n\
	#Randomly set A=B.\n\
	0 ? random.mod     .tmp0 .eqprob\n\
	.tmp0 .z    ?+4\n\
	.tmp0 .tmp0 .nosetab\n\
	.tmp0 .b    ?+1\n\
	.a    .a    ?+1\n\
	.a    .tmp0 ?+1\n\
	.nosetab:\n\
\n\
	#Copy A, B, and C to compare later.\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .a    ?+1\n\
	.a0   .a0   ?+1\n\
	.a0   .tmp0 ?+1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .b    ?+1\n\
	.b0   .b0   ?+1\n\
	.b0   .tmp0 ?+1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .c    ?+1\n\
	.c0   .c0   ?+1\n\
	.c0   .tmp0 ?+1\n\
\n\
	#0 ? print 0-1 .trial 32 0-1 .a 32 0-1 .b 32 0-1 .c 10 0\n\
\n\
	#----------------------- Compare ------------------------\n\
	#Compare A and B manually.\n\
	.exp0 .exp0 ?+1\n\
	.exp0 .z-1  ?+1\n\
	.b    .a    ?+4\n\
	.exp0 .z+1  ?+7\n\
	.b    .z    ?+4\n\
	.exp0 .z-1  ?+1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .a    ?+1\n\
	.b    .tmp0 ?+1\n\
\n\
	.ret0 .ret0 ?+1\n\
	0 ? test.measure .cmpops .cmplt 0 ? uint.cmp .a .b .cmplt .cmpeq .cmpgt\n\
	0-1 0 0\n\
	.cmpgt: .ret0   .z-1  ?+1\n\
	.cmpeq: .ret0   .z-1  ?+1\n\
	.cmplt: .cmpops .ret0 ?+1\n\
	0 ? test.cmp .exp0 .ret0 0\n\
\n\
	#------------------------- Set --------------------------\n\
	0 ? test.measure .setops ?+6 0 ? uint.set .ret0 .a\n\
	0 ? test.cmp .a .ret0 1\n\
\n\
	#----------------------- Negation -----------------------\n\
	#Calculate -A manually.\n\
	.exp0 .exp0 ?+1\n\
	.exp0 .a    ?+1\n\
\n\
	0 ? test.measure .negops ?+6 0 ? uint.neg .ret0 .a\n\
	0 ? test.cmp .exp0 .ret0 2\n\
\n\
	#----------------------- Addition -----------------------\n\
	#Calculate A+B manually.\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .a    ?+1\n\
	.tmp0 .b    ?+1\n\
	.exp0 .exp0 ?+1\n\
	.exp0 .tmp0 ?+1\n\
\n\
	0 ? test.measure .addops ?+7 0 ? uint.add .ret0 .a .b\n\
	0 ? test.cmp .exp0 .ret0 3\n\
\n\
	#--------------------- Subtraction ----------------------\n\
	#Calculate A-B manually.\n\
	.exp0 .b    ?+1\n\
	.exp0 .b    ?+1\n\
\n\
	0 ? test.measure .subops ?+7 0 ? uint.sub .ret0 .a .b\n\
	0 ? test.cmp .exp0 .ret0 4\n\
\n\
	#-------------------- Multiplication --------------------\n\
	#Calculate A*B manually.\n\
	.exp0 .exp0 ?+1\n\
	#[tmp1]=[a]\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .a    ?+1\n\
	.tmp1 .tmp1 ?+1\n\
	.tmp1 .tmp0 ?+1\n\
	#[tmp2]=65\n\
	.tmp2 .tmp2 ?+1\n\
	.tmp2 .nbits-1 ?+1\n\
	.mulloop:\n\
	.tmp2 .z+1  .muldone\n\
	#exp<<=1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .exp1 ?+1\n\
	.exp1 .tmp0 ?+1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .exp0 ?+1\n\
	.tmp0 .z+1  ?+1\n\
	.exp0 .tmp0 ?+4\n\
	#If [exp0] carries.\n\
	.exp1 .z-1  ?+1\n\
	.exp0 .z+1  ?+1\n\
	#[tmp1]<<=1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .tmp1 ?+1\n\
	.tmp0 .z+1  ?+1\n\
	.tmp1 .tmp0 .mulloop\n\
	#[exp0]+=[b]\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .b    ?+1\n\
	.tmp0 .z+1  ?+1\n\
	.exp0 .tmp0 ?+4\n\
	.exp1 .z-1  ?+1\n\
	.exp0 .z+1  ?+1\n\
	.tmp0 .tmp0 .mulloop\n\
	.muldone:\n\
\n\
	0 ? test.measure .mulops ?+8 0 ? uint.mul .ret1 .ret0 .a .b\n\
	0 ? test.cmp .exp0 .ret0 5\n\
	0 ? test.cmp .exp1 .ret1 6\n\
\n\
	#----------------------- Division -----------------------\n\
	#For B!=0, q=A/B, and r=A%B, we have A=q*B+r and r<B.\n\
	.b .z .div0\n\
	.divden .z-1 ?+1\n\
	0 ? test.measure .divops ?+8 0 ? uint.div .ret0 .ret1 .a .b\n\
	0 ? uint.cmp .ret1 .b .remlt ?+2 ?+1\n\
	0 ? test.cmp .z .b 7\n\
	.remlt:\n\
	0 ? uint.mul .tmp0 .tmp1 .ret0 .b\n\
	0 ? test.cmp .z .tmp0 8\n\
	0 ? uint.add .tmp1 .ret1 .tmp1\n\
	0 ? test.cmp .a .tmp1 9\n\
	.div0:\n\
\n\
	#---------------------- Shift Left ----------------------\n\
	#Calculate A<<C manually.\n\
	#[exp0]=[a]\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .a    ?+1\n\
	.exp0 .exp0 ?+1\n\
	.exp0 .tmp0 ?+1\n\
	#[tmp2]=-[c]\n\
	.tmp2 .tmp2 ?+1\n\
	.tmp2 .c    ?+1\n\
	.shlloop:\n\
	.exp0 .z    .shldone\n\
	.tmp2 .z    .shldone\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .exp0 ?+1\n\
	.exp0 .tmp0 ?+1\n\
	.tmp2 .z-1  .shlloop\n\
	.shldone:\n\
\n\
	0 ? test.measure .shlops ?+7 0 ? uint.shl .ret0 .a .c\n\
	0 ? test.cmp .exp0 .ret0 10\n\
\n\
	#--------------------- Shift Right ----------------------\n\
	#Calculate A>>C manually.\n\
	.exp0 .exp0 ?+1\n\
	#[tmp1]=[a]\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .a    ?+1\n\
	.tmp1 .tmp1 ?+1\n\
	.tmp1 .tmp0 ?+1\n\
	#[tmp2]=-[c]-1\n\
	.tmp2 .tmp2 ?+1\n\
	.tmp2 .c    ?+1\n\
	.tmp2 .z+1  ?+1\n\
	.shrloop:\n\
	.tmp2 .nbits-1 .shrdone\n\
	.tmp2 .bits+2 ?+1\n\
	#[exp0]<<=1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .exp0 ?+1\n\
	.exp0 .tmp0 ?+1\n\
	#[tmp1]<<=1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .tmp1 ?+1\n\
	.tmp0 .z+1  ?+1\n\
	.tmp1 .tmp0 .shrloop\n\
	.exp0 .z-1  .shrloop\n\
	.shrdone:\n\
\n\
	0 ? test.measure .shrops ?+7 0 ? uint.shr .ret0 .a .c\n\
	0 ? test.cmp .exp0 .ret0 11\n\
\n\
	#------------------------- Not --------------------------\n\
	#~A=-1-A\n\
	.exp0 .exp0 ?+1\n\
	.exp0 .z+1  ?+1\n\
	.exp0 .a    ?+1\n\
\n\
	0 ? test.measure .notops ?+6 0 ? uint.not .ret0 .a\n\
	0 ? test.cmp .exp0 .ret0 12\n\
\n\
	#------------------------- And --------------------------\n\
	#Calculate A&B manually.\n\
	#[exp0]=[a]\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .a    ?+1\n\
	.exp0 .exp0 ?+1\n\
	.exp0 .tmp0 ?+1\n\
	#[exp1]=[b]\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .b    ?+1\n\
	.exp1 .exp1 ?+1\n\
	.exp1 .tmp0 ?+1\n\
	#[tmp2]=65\n\
	.tmp2 .tmp2 ?+1\n\
	.tmp2 .nbits-1 ?+1\n\
	.andloop:\n\
	.tmp2 .z+1  .anddone\n\
	#[exp0]<<=1\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .exp0 ?+1\n\
	.exp0 .tmp0 ?+1\n\
	#[exp1]<<=1\n\
	.tmp1 .tmp1 ?+1\n\
	.tmp1 .exp1 ?+1\n\
	.tmp1 .z+1  ?+1\n\
	#Set [exp0] if both carry.\n\
	.exp1 .tmp1 .andloop\n\
	.tmp0 .z    .andloop\n\
	.tmp0 .hbit ?+4\n\
	.tmp0 .tmp0 .andloop\n\
	.exp0 .z-1  .andloop\n\
	.anddone:\n\
\n\
	0 ? test.measure .andops ?+7 0 ? uint.and .ret0 .a .b\n\
	0 ? test.cmp .exp0 .ret0 13\n\
\n\
	#-------------------------- Or --------------------------\n\
	#A|B=A+B-(A&B)\n\
	.ret0 .a    ?+1\n\
	.ret0 .b    ?+1\n\
	.exp1 .exp1 ?+1\n\
	.exp1 .ret0 ?+1\n\
\n\
	0 ? test.measure .orops ?+7 0 ? uint.or .ret0 .a .b\n\
	0 ? test.cmp .exp1 .ret0 14\n\
\n\
	#------------------------- Xor --------------------------\n\
	#A^B=(A|B)-(A&B)\n\
	.exp1 .exp0 ?+1\n\
\n\
	0 ? test.measure .xorops ?+7 0 ? uint.xor .ret0 .a .b\n\
	0 ? test.cmp .exp1 .ret0 15\n\
\n\
	#Make sure parameters haven't been modified.\n\
	0 ? test.cmp .a0 .a 16\n\
	0 ? test.cmp .b0 .b 17\n\
	0 ? test.cmp .c0 .c 18\n\
\n\
	.trial .z-1 .loop\n\
\n\
.done:\n\
	#Print instruction counts.\n\
	0 ? uint.div .cmpops 0 .cmpops .trial\n\
	0 ? uint.div .setops 0 .setops .trial\n\
	0 ? uint.div .negops 0 .negops .trial\n\
	0 ? uint.div .addops 0 .addops .trial\n\
	0 ? uint.div .subops 0 .subops .trial\n\
	0 ? uint.div .mulops 0 .mulops .trial\n\
	0 ? uint.div .divops 0 .divops .divden\n\
	0 ? uint.div .shlops 0 .shlops .trial\n\
	0 ? uint.div .shrops 0 .shrops .trial\n\
	0 ? uint.div .notops 0 .notops .trial\n\
	0 ? uint.div .andops 0 .andops .trial\n\
	0 ? uint.div  .orops 0  .orops .trial\n\
	0 ? uint.div .xorops 0 .xorops .trial\n\
	0 ? print 97 118 101 114 97 103 101 32 105 110 115 116 114 117 99 116 105 111\n\
	          110 115 32 112 101 114 32 102 117 110 99 116 105 111 110 10 0\n\
	0 ? print  99 109 112 58 32 0-1 .cmpops 10 0\n\
	0 ? print 115 101 116 58 32 0-1 .setops 10 0\n\
	0 ? print 110 101 103 58 32 0-1 .negops 10 0\n\
	0 ? print  97 100 100 58 32 0-1 .addops 10 0\n\
	0 ? print 115 117  98 58 32 0-1 .subops 10 0\n\
	0 ? print 109 117 108 58 32 0-1 .mulops 10 0\n\
	0 ? print 100 105 118 58 32 0-1 .divops 10 0\n\
	0 ? print 115 104 108 58 32 0-1 .shlops 10 0\n\
	0 ? print 115 104 114 58 32 0-1 .shrops 10 0\n\
	0 ? print 110 111 116 58 32 0-1 .notops 10 0\n\
	0 ? print  97 110 100 58 32 0-1 .andops 10 0\n\
	0 ? print  32 111 114 58 32 0-1  .orops 10 0\n\
	0 ? print 120 111 114 58 32 0-1 .xorops 10 0\n\
	0 ? print 112 97 115 115 101 100 10 0\n\
	0-1 0 0\n\
\n\
	#Variables\n\
	0-2 0-1 .z:0 1\n\
	.a:0\n\
	.b:0\n\
	.c:0\n\
	.eqprob:64\n\
	.hbit:0\n\
	0-1 .nbits:0\n\
	.bits:0 1 2\n\
	.shiftmax:0\n\
	.shiftsub:0\n\
	.cmpops:0\n\
	.setops:0\n\
	.negops:0\n\
	.addops:0\n\
	.subops:0\n\
	.mulops:0\n\
	.divops:0\n\
	.divden:0\n\
	.shlops:0\n\
	.shrops:0\n\
	.notops:0\n\
	.andops:0\n\
	.orops:0\n\
	.xorops:0\n\
	.trial:0\n\
	.trials:2048\n\
	.exp0:0\n\
	.exp1:0\n\
	.ret0:0\n\
	.ret1:0\n\
	.tmp0:0\n\
	.tmp1:0\n\
	.tmp2:0\n\
	#Place these far away from .a, .b, and .c in order to minimize accidental use\n\
	#by functions.\n\
	.a0:0\n\
	.b0:0\n\
	.c0:0\n\
\n\
test.rand.uint:\n\
	#Call  : 0 ? test.rand ret\n\
	#Effect: [ret]=(rand)\n\
	#Generate a random integer such that the probability of any bitcount is uniform.\n\
	#Setup new stack.\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .p0   ?+1\n\
	0     .z+2  ?+1\n\
	0     .tmp0 ?+1\n\
	.p0   0     ?+1\n\
	.addr 0     ?+1\n\
	0     0     ?+1\n\
	#Get [ret]\n\
	.tmp0 .tmp0 ?+1\n\
	.tmp0 .p0:0 ?+1\n\
	.p5   .p5   ?+1\n\
	.p5   .tmp0 ?+1\n\
	.p6   .p6   ?+1\n\
	.p6   .tmp0 ?+1\n\
	#Shuffle arr.\n\
	0 ? random.shuffle .arr0 test.main.bits\n\
	#Calculate how many bits we want to set.\n\
	0 ? random.mod .i test.main.bits\n\
	.tmp0 .tmp0 ?+1\n\
	.b0   .b0   ?+1\n\
	.b0   .narr ?+1\n\
	.i    .z-1  ?+1\n\
.setbits:\n\
	.i    .z+1  .setdone\n\
	.tmp0 .b0:0 ?+1\n\
	.b0   .z-1  .setbits\n\
.setdone:\n\
	#Return\n\
	.tmp1 .tmp1 ?+1\n\
	.tmp1 .p5:0 ?+1\n\
	.tmp0 .tmp1 ?+1\n\
	.p6:0 .tmp0 ?+1  #[ret]=[rand]\n\
	0     0     .addr:1\n\
	#Variables\n\
	0-1 .z:0 1 2\n\
	.tmp0:0\n\
	.tmp1:0\n\
	.i:0\n\
	.arr:\n\
		0x1 0x2 0x4 0x8 0x10 0x20 0x40 0x80 0x100 0x200 0x400 0x800 0x1000 0x2000 0x4000\n\
		0x8000 0x10000 0x20000 0x40000 0x80000 0x100000 0x200000 0x400000 0x800000\n\
		0x1000000 0x2000000 0x4000000 0x8000000 0x10000000 0x20000000 0x40000000\n\
		0x80000000 0x100000000 0x200000000 0x400000000 0x800000000 0x1000000000\n\
		0x2000000000 0x4000000000 0x8000000000 0x10000000000 0x20000000000 0x40000000000\n\
		0x80000000000 0x100000000000 0x200000000000 0x400000000000 0x800000000000\n\
		0x1000000000000 0x2000000000000 0x4000000000000 0x8000000000000 0x10000000000000\n\
		0x20000000000000 0x40000000000000 0x80000000000000 0x100000000000000\n\
		0x200000000000000 0x400000000000000 0x800000000000000 0x1000000000000000\n\
		0x2000000000000000 0x4000000000000000 0x8000000000000000\n\
	.arr0:.arr\n\
	.narr:0-.arr\n\
\n\
test.cmp:\n\
	#Call  : 0 ? test.cmp exp val id\n\
	#Setup stack.\n\
	.tmp  .tmp  ?+1\n\
	.tmp  .p0   ?+1\n\
	0     .tmp  ?+1\n\
	0     .z+2  ?+1\n\
	.p0   0     ?+1\n\
	.p2   0     ?+1\n\
	.id   0     ?+1\n\
	.ret  0     ?+1\n\
	0     0     ?+1\n\
	#Get [exp]\n\
	.tmp  .tmp  ?+1\n\
	.tmp  .p0:0 ?+1\n\
	.p1   .p1   ?+1\n\
	.p1   .tmp  ?+1\n\
	.tmp  .tmp  ?+1\n\
	.tmp  .p1:0 ?+1\n\
	.exp  .tmp  ?+1\n\
	#Get [val]\n\
	.tmp  .tmp  ?+1\n\
	.tmp  .p2:1 ?+1\n\
	.p3   .p3   ?+1\n\
	.p3   .tmp  ?+1\n\
	.tmp  .tmp  ?+1\n\
	.tmp  .p3:0 ?+1\n\
	.val  .val  ?+1\n\
	.val  .tmp  ?+1\n\
	#Compare [exp] and [val].\n\
	.exp  .val  ?+1\n\
	.exp  .z    .ret:3\n\
	.exp  .tmp  ?+1\n\
	#ERROR\n\
	0 ? print 69 82 82 79 82 10 0\n\
	#line\n\
	0 ? print 116 114 105 97 108 32 58 32 0-1 test.main.trial 10 0\n\
	#test\n\
	0 ? print 116 101 115 116 32 32 58 32 0-1 .id:2 10 0\n\
	#expect\n\
	0 ? print 101 120 112 101 99 116 58 32 0-1 .exp 10 0\n\
	#return\n\
	0 ? print 114 101 116 117 114 110 58 32 0-1 .val 10 0\n\
	0-1 0 0\n\
.exp:0\n\
.val:0\n\
.z:0 1 2\n\
.tmp:0\n\
\n\
test.measure:\n\
	#0 ? test.measure counter return 0 ? func arg0 arg1 ...\n\
	#counter = the address for counting instructions.\n\
	#return  = address the function will return to when finished.\n\
	#Emulates the execution of a function and measures how many instructions it uses.\n\
	#Uses 24+20*n instructions for n emulated instructions.\n\
	.tmp    .a0     ?+1\n\
	.nret   .tmp    ?+1\n\
	.tmp    0       ?+1\n\
	.dif    .tmp    ?+1\n\
	.dif    .z+4    ?+1\n\
	#Setup counter.\n\
	0       .z+2    ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     0       ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p0:0   ?+1\n\
	.cnt    .cnt    ?+1\n\
	.cnt    .tmp    ?+1\n\
	#Get the negative return address. If [nret]+[dif0]+[dif1]+...=0, then return.\n\
	0       .z+1    ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     0       ?+1\n\
	.nret   .p1:0   ?+1\n\
	#Reset stack address.\n\
	0       0       .loop\n\
.jmp:\n\
	#We jumped, set [dif]=[a0]-[c].\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .a0     ?+1\n\
	.dif    .tmp    ?+1\n\
.loop:\n\
	#Update a, b, and c addresses.\n\
	.a0     .dif    ?+1\n\
	.b0     .dif    ?+1\n\
	.c0     .dif    ?+1\n\
	.nret   .dif    ?+1\n\
	.dif    .dif    ?+1\n\
	#Return if ip=[ret].\n\
	.nret   .z      .ret\n\
	#Increment the instruction counter.\n\
	.cnt:0  .z-1    ?+1\n\
	#Load [a]. a0 will hold the return address when we're done.\n\
	.tmp    .tmp    ?+2\n\
	.ret:   .tmp\n\
	.tmp    .a0:0   ?+1\n\
	.a      .a      ?+1\n\
	.a      .tmp    ?+1\n\
	#Load [b].\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .b0:1   ?+1\n\
	.b      .b      ?+1\n\
	.b      .tmp    ?+1\n\
	#Set [dif]=-[c].\n\
	.dif    .c0:2   ?+1\n\
	#Execute instruction.\n\
	.a:0    .b:0    .jmp\n\
	#We failed to jump, set [dif]=-3.\n\
	.dif    .dif    ?+1\n\
	.dif    .z+3    .loop\n\
	#Variables\n\
	.tmp:0\n\
	.nret:0\n\
	.dif:0\n\
	0-2 0-1 .z:0 1 2 3 4\n\
\n\
#|==============================================================================\n\
\n\
Unsigned Integer Operations - v3.09\n\
\n\
Author: Alec Dee - alecdee.github.io - akdee144@gmail.com\n\
\n\
--------------------------------------------------------------------------------\n\
Notes\n\
\n\
This library provides functions for performing most of the common unsigned\n\
integer operations. In particular, it handles comparisons, arithmetic, and\n\
bitwise operations.\n\
\n\
Almost all functions are bit length agnostic. That is, they don't need to be\n\
modified even if unileq uses a something other than 64 bit integers. The only\n\
functions that need the bit length set are uint.mul and uint.div.\n\
\n\
The 0 address will always be 0 upon function return, even if one of the return\n\
value addresses is 0.\n\
\n\
This library does not depend on any other libraries.\n\
\n\
Worst case time complexity:\n\
\n\
       Function  |  Time  |     O(n)\n\
     ------------+--------+--------------\n\
          cmp    |    29  |  29\n\
          set    |    24  |  24\n\
          neg    |    25  |  25\n\
          add    |    30  |  30\n\
          sub    |    31  |  31\n\
          mul    |   993  |  33+15*bits\n\
          div    |  1006  |  46+15*bits\n\
          shl    |   185  |  56+17*((bits-1)//8)\n\
          shr    |   546  |  34+8*bits\n\
          not    |    26  |  26\n\
          and    |   485  |  44+7*bits\n\
           or    |   486  |  45+7*bits\n\
          xor    |   487  |  46+7*bits\n\
\n\
--------------------------------------------------------------------------------\n\
Index\n\
\n\
Comparisons\n\
uint.cmp a b lt eq gt\n\
\n\
Integer Arithmetic\n\
uint.set ret a\n\
uint.neg ret a\n\
uint.add ret a b\n\
uint.sub ret a b\n\
uint.mul high low a b\n\
uint.div quot rem num den\n\
\n\
Bitwise Arithmetic\n\
uint.shl ret num shift\n\
uint.shr ret num shift\n\
uint.not ret a\n\
uint.and ret a b\n\
uint.or  ret a b\n\
uint.xor ret a b\n\
\n\
--------------------------------------------------------------------------------\n\
Version History\n\
\n\
1.00\n\
     Initial version. Used uint.cmp, mem.get, and mem.set for proof of concept.\n\
     Functions take tens of thousands of instructions.\n\
2.00\n\
     Unrolled functions so they don't use mem.get and mem.set.\n\
     Functions take thousands of instructions.\n\
3.00\n\
     Optimized functions so they are all under 1100 instructions.\n\
3.01\n\
     Optimized uint.and, or, and xor so the final value is stored in [a]. This\n\
     removes the need for a temporary storage variable.\n\
     Cleaned up uint.cmp so its branching is more straight forward.\n\
3.02\n\
     Optimized uint.set and uint.add to remove 1 instruction.\n\
3.03\n\
     Fixed an error in uint.mul when carrying from low to high. Removed need to\n\
     offset [b] by 1 to check for carrying.\n\
     Updated formatting for uint.cmp.\n\
     Changed uint.div to abort with 0xd0 when dividing by 0.\n\
     Optimized AND/OR/XOR by skipping first loop check.\n\
3.04\n\
     Optimized AND/OR/XOR by 18%. [a] and [b] only need to be offset by 1 on the\n\
     first loop. This removes 2 decrement instructions per loop.\n\
3.05\n\
     Optimized AND/OR/XOR by 11%. Removed the iteration counter and instead\n\
     check if [b]=0. We only set the bottom bit of [a] in 1/4 of cases, and only\n\
     check if [b]=0 in 1/2 of cases. OR/XOR are based off of AND for their loop.\n\
3.06\n\
     Updated comments.\n\
3.07\n\
     Replaced average case time complexity with worst case time complexity.\n\
     Standardized formatting to 8 spaces per column.\n\
3.08\n\
     Updated comments.\n\
3.09\n\
     Changed division-by-0 abort instruction.\n\
     Made uint.shl bit length agnostic and lowered run time by 36%.\n\
     Made uint.shr bit length agnostic and lowered run time by 11%.\n\
\n\
--------------------------------------------------------------------------------\n\
TODO\n\
\n\
Abort if shift is greater than bit length in uint.shl and uint.shr.\n\
Use global \"uint\" scope and shared variables (.z:, .tmp:, etc).\n\
Add effects to index section.\n\
Add better overview explanations for uint.and, uint.mul, and uint.div.\n\
Remove loop counter from uint.mul. Optimize if high=0.\n\
Remove loop counter from uint.div. Optimize if quot=0 or den>num.\n\
Calculating A&B might be faster by looking at bit changes in A-B. Use the changes\n\
in runs of 0's and 1's to determine where bit differences are.\n\
|#\n\
\n\
#--------------------------------------------------------------------------------\n\
#Comparisons\n\
\n\
uint.cmp:\n\
	#Call  : 0 ? uint.cmp a b lt eq gt\n\
	#Effect:\n\
	#     if [a]<[b]: goto lt\n\
	#     if [a]=[b]: goto eq\n\
	#     if [a]>[b]: goto gt\n\
	#Time  : 29\n\
	.z      .arg2   ?+1\n\
	0       .z      ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	.arg6   0       ?+1\n\
	0       0       ?+1\n\
	#get [a]\n\
	.z      .z      ?+1\n\
	.z      .arg2:2 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .z      ?+1\n\
	.z      .z      ?+1\n\
	.z      .p0:0   ?+1\n\
	.a      .a      ?+1\n\
	.a      .z      ?+1\n\
	#get [b]\n\
	.z      .z      ?+1\n\
	.z      .arg3:3 ?+1\n\
	.b      .b      ?+1\n\
	.b      .z      ?+1\n\
	#[a]-[b]\n\
	.z      .z      ?+1\n\
	.a      .b:0    .le\n\
	#[a]>[b]\n\
	.z      .arg6:6 .ret\n\
.le:\n\
	.a      .z      .eq\n\
	#[a]<[b]\n\
	.z      .arg4:4 .ret\n\
.eq:\n\
	#[a]=[b]\n\
	.z      .arg5:5 .ret\n\
.ret:\n\
	.r0     .r0     ?+1\n\
	.r0     .z      ?+1\n\
	.z      .z      .r0:0\n\
	#Variables\n\
	.a:0\n\
	.z:0 1 2\n\
\n\
\n\
#--------------------------------------------------------------------------------\n\
#Integer Arithmetic\n\
\n\
uint.set:\n\
	#Call  : 0 ? uint.set ret a\n\
	#Effect: [ret]=[a]\n\
	#Time  : 24\n\
	#Setup the stack.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2   ?+1\n\
	0       .tmp    ?+1\n\
	0       .off    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	#Get [ret]\n\
	.p0     .arg2:2 ?+1\n\
	.p1     .p0     ?+1\n\
	.p2     .p0     ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p1     ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	#Get [a]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.p3     .p3     ?+1\n\
	.p3     .tmp    ?+1\n\
	#Set [ret]\n\
	.ret    .ret    ?+1\n\
	.ret    .p3:0   ?+1  #[ret]=-[a]\n\
	.p0:0   .p1:0   ?+1\n\
	.p2:0   .ret    ?+1  #[ret]=[a]\n\
	0       0       .arg4:4\n\
	#Variables\n\
	.off:2\n\
	.ret:0\n\
	.tmp:0\n\
\n\
\n\
uint.neg:\n\
	#Call  : 0 ? uint.neg ret a\n\
	#Effect: [ret]=-[a]\n\
	#Time  : 25\n\
	#Setup the stack.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2   ?+1\n\
	0       .tmp    ?+1\n\
	0       .off    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	#Get [ret]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2:2 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     .tmp    ?+1\n\
	#Get [a]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.p2     .p2     ?+1\n\
	.p2     .tmp    ?+1\n\
	#Set [ret]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p0:0   ?+1  #[tmp]=-[ret]\n\
	.tmp    .p2:0   ?+1  #[tmp]=-[ret]-[a]\n\
	.ret    .ret    ?+1\n\
	.ret    .tmp    ?+1  #[ret]=[ret]+[a]\n\
	.p1:0   .ret    ?+1  #[ret]=[ret]-([ret]+[a])=-[a]\n\
	0       0       .arg4:4\n\
	#Variables\n\
	.off:2\n\
	.ret:0\n\
	.tmp:0\n\
\n\
\n\
uint.add:\n\
	#Call  : 0 ? uint.add ret a b\n\
	#Effect: [ret]=[a]+[b]\n\
	#Time  : 30\n\
	#Setup the stack.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg0   ?+1\n\
	0       .tmp    ?+1\n\
	.arg0   0       ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	#Get [ret]\n\
	.p0     .arg2:2 ?+1\n\
	.p1     .p0     ?+1\n\
	.p2     .p0     ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p1     ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	#Get [a]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.p3     .p3     ?+1\n\
	.p3     .tmp    ?+1\n\
	#Get [b]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg4:4 ?+1\n\
	.p4     .p4     ?+1\n\
	.p4     .tmp    ?+1\n\
	#Set [ret]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p3:0   ?+1  #[tmp]=-[a]\n\
	.tmp    .p4:0   ?+1  #[tmp]=-[a]-[b]\n\
	.p0:0   .p1:0   ?+1\n\
	.p2:0   .tmp    ?+1  #[ret]=[a]+[b]\n\
	#Return\n\
	0       0       .arg5:5\n\
	#Variables\n\
	.arg0:0\n\
	.tmp:0\n\
	.pt:0\n\
\n\
\n\
uint.sub:\n\
	#Call  : 0 ? uint.sub ret a b\n\
	#Effect: [ret]=[a]-[b]\n\
	#Time  : 31\n\
	#Setup the stack.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg0   ?+1\n\
	0       .tmp    ?+1\n\
	.arg0   0       ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	#Get [ret]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2:2 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     .tmp    ?+1\n\
	#Get [a]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.p2     .p2     ?+1\n\
	.p2     .tmp    ?+1\n\
	#Get [b]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg4:4 ?+1\n\
	.p3     .p3     ?+1\n\
	.p3     .tmp    ?+1\n\
	#Set [ret]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p0:0   ?+1  #[tmp]=-[ret]\n\
	.tmp    .p3:0   ?+1  #[tmp]=-[ret]-[b]\n\
	.ret    .ret    ?+1\n\
	.ret    .p2:0   ?+1  #[ret]=-[a]\n\
	.ret    .tmp    ?+1  #[ret]=[ret]-[a]+[b]\n\
	.p1:0   .ret    ?+1  #[ret]=[a]-[b]\n\
	#Return\n\
	0       0       .arg5:5\n\
	#Variables\n\
	.arg0:0\n\
	.ret:0\n\
	.tmp:0\n\
\n\
\n\
uint.mul:\n\
	#Call  : 0 ? uint.mul high low a b\n\
	#Effect:\n\
	#     [high]=([a]*[b])/2^64\n\
	#     [low] =([a]*[b])%2^64\n\
	#Time  : 33+15*bits = 993\n\
	#Setup stack pointer.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2   ?+1\n\
	0       .tmp    ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	.arg6   0       ?+1\n\
	#Get high.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2:2 ?+1\n\
	.h0     .h0     ?+1\n\
	.h0     .tmp    ?+1\n\
	.h1     .h1     ?+1\n\
	.h1     .tmp    ?+1\n\
	#Get low.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.l0     .l0     ?+1\n\
	.l0     .tmp    ?+1\n\
	.l1     .l1     ?+1\n\
	.l1     .tmp    ?+1\n\
	#Get -[a]. Use -[a] for adding to [lval].\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg4:4 ?+1\n\
	.a0     .a0     ?+1\n\
	.a0     .tmp    ?+1\n\
	.a      .a      ?+1\n\
	.a      .a0:0   ?+1\n\
	#Get [b].\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg5:5 ?+1\n\
	.b0     .b0     ?+1\n\
	.b0     .tmp    ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .b0:0   ?+1\n\
	.b      .b      ?+1\n\
	.b      .tmp    ?+1\n\
	#Initialize lval and hval.\n\
	.hval   .hval   ?+1\n\
	.lval   .lval   ?+1\n\
	#Manually perform the first loop and make sure [b] is odd.\n\
	.tmp    .z+1    ?+1\n\
	.b      .tmp    ?+4\n\
	.lval   .a      ?+1\n\
	.i      .bits   ?+13\n\
.loop:\n\
	#Check loop.\n\
	.i      .z+1    .ret\n\
	#Left shift [hval] and [lval].\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .hval   ?+1\n\
	.hval   .tmp    ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .lval   ?+1\n\
	.tmp    .z+1    ?+1\n\
	.lval   .tmp    ?+4\n\
	.hval   .z-1    ?+1\n\
	.lval   .z+1    ?+1\n\
	#If the highest bit of [b] is set, add [a] to [lval] and carry to [hval].\n\
	#Since [b] is guaranteed to be odd, we don't need to offset it.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .b      ?+1\n\
	.b      .tmp    .loop\n\
	.lval   .a      .loop\n\
	.hval   .z-1    .loop\n\
.ret:\n\
	#Set [high].\n\
	.hval   .h0:0   ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .hval   ?+1\n\
	.h1:0   .tmp    ?+1\n\
	#Set [low].\n\
	.lval   .l0:0   ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .lval   ?+1\n\
	.l1:0   .tmp    ?+1\n\
	0       0       .arg6:6\n\
	#Variables\n\
	0-1 .z:0 1 2\n\
	.tmp:0\n\
	.a:0\n\
	.b:0\n\
	.hval:0\n\
	.lval:0\n\
	.i:0\n\
	.bits:0-63\n\
\n\
\n\
uint.div:\n\
	#Call  : 0 ? uint.div quot rem num den\n\
	#Effect:\n\
	#     [quot]=[num]/[den], rounded down\n\
	#     [rem] =[num]%[den]\n\
	#Time  : 46+15*bits = 1006\n\
	#Setup stack pointer.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2   ?+1\n\
	0       .tmp    ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	.arg6   0       ?+1\n\
	#Get quotient.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2:2 ?+1\n\
	.r0     .r0     ?+1\n\
	.r0     .tmp    ?+1\n\
	.r1     .r1     ?+1\n\
	.r1     .tmp    ?+1\n\
	#Get remainder.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.r2     .r2     ?+1\n\
	.r2     .tmp    ?+1\n\
	.r3     .r3     ?+1\n\
	.r3     .tmp    ?+1\n\
	#Get numerator.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg4:4 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p0:0   ?+1\n\
	.num    .num    ?+1\n\
	.num    .tmp    ?+1\n\
	#Get denominator.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg5:5 ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     .tmp    ?+1\n\
	.nden   .nden   ?+1\n\
	.nden   .p1:0   ?+1\n\
	#If [den]=0, abort\n\
	.nden   .z      .divz\n\
	.nden   .z-1    ?+1\n\
	.den    .den    ?+1\n\
	.den    .nden   ?+1\n\
	#Start loop.\n\
	.quot   .quot   ?+1\n\
	.rem    .rem    ?+1\n\
	.i      .bits   ?+1\n\
.loop:\n\
	#[rem]+=[num]>>63, [num]<<=1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .num    ?+1\n\
	.tmp    .z+1    ?+1\n\
	.num    .tmp    ?+4\n\
	.rem    .z-1    ?+1\n\
	#if [rem]>=[den], [quot]+=1\n\
	.rem    .den    ?+7\n\
	.rem    .z+1    ?+1\n\
	.quot   .z-1    ?+4\n\
	.rem    .nden   ?+1\n\
	.i      .z+1    .ret\n\
	#[quot]<<=1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .quot   ?+1\n\
	.quot   .tmp    ?+1\n\
	#[rem]<<=1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .rem    ?+1\n\
	.rem    .tmp    .loop\n\
.ret:\n\
	#Set quotient.\n\
	.quot   .r0:0   ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .quot   ?+1\n\
	.r1:0   .tmp    ?+1\n\
	#Set remainder.\n\
	.rem    .r2:0   ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .rem    ?+1\n\
	.r3:0   .tmp    ?+1\n\
	0       0       .arg6:6\n\
.divz:\n\
	#Abort.\n\
	0-1     0       ?-2\n\
	#Variables\n\
	.num:0\n\
	.den:0\n\
	.nden:0\n\
	.quot:0\n\
	.rem:0\n\
	.tmp:0\n\
	.i:0\n\
	.bits:0-64\n\
	0-1 .z:0 1 2\n\
\n\
\n\
#--------------------------------------------------------------------------------\n\
#Bitwise Arithmetic\n\
\n\
uint.shl:\n\
	#Call  : 0 ? uint.shl ret num shift\n\
	#Effect: [ret]=[num]<<[shift]\n\
	#Time  : 38+17*((bits-1)//8)+4*((bits-1)%8) = 185\n\
	#Setup stack pointer.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2   ?+1\n\
	0       .tmp    ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	#Get ret.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2:2 ?+1\n\
	.ret0   .ret0   ?+1\n\
	.ret0   .tmp    ?+1\n\
	.ret1   .ret1   ?+1\n\
	.ret1   .tmp    ?+1\n\
	#Get -[num]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	.num    .num    ?+1\n\
	.num    .p0:0   ?+1\n\
	#Get [shift]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg4:4 ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     .tmp    ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p1:0   ?+1\n\
	.shift  .shift  ?+1\n\
	.shift  .tmp    .done8-3\n\
	#[num]=[num]<<8. Abort if [num]=0.\n\
.loop8:\n\
	.num    .z      .ret\n\
	.shift  .p7     .done8\n\
	.shift  .z+1    ?+1\n\
	.tmp    .num    ?+1\n\
	.tmp    .num    ?+1\n\
	.num    .tmp    ?+1\n\
	.tmp    .num    ?+1\n\
	.num    .tmp    ?+1\n\
	.num    .tmp    ?+1\n\
	.tmp    .num    ?+1\n\
	.tmp    .num    ?+1\n\
	.num    .tmp    ?+1\n\
	.num    .tmp    ?+1\n\
	.tmp    .num    ?+1\n\
	.tmp    .num    ?+1\n\
	.num    .tmp    ?+1\n\
	.tmp    .tmp    .loop8\n\
.done8:\n\
	.shift  .n8     ?+1\n\
	#[num]=[num]<<1\n\
.loop1:\n\
	.shift  .z+1    .ret\n\
	.tmp    .num    ?+1\n\
	.num    .tmp    ?+1\n\
	.tmp    .tmp    .loop1\n\
.ret:\n\
	#Set [ret].\n\
	.tmp    .ret0:0 ?+1\n\
	.num    .tmp    ?+1\n\
	.ret1:0 .num    ?+1\n\
	0       0       .arg5:5\n\
	#Variables\n\
	.num:0\n\
	.shift:0\n\
	.tmp:0\n\
	.z:0 1 2\n\
	.p7:7\n\
	.n8:0-8\n\
\n\
\n\
uint.shr:\n\
	#Call  : 0 ? uint.shr ret num shift\n\
	#Effect: [ret]=[num]>>[shift]\n\
	#Time  : 34+8*bits = 546\n\
	#Setup stack pointer.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2   ?+1\n\
	0       .tmp    ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	#On first run, calculate how many bits we are using.\n\
	.tmp    .tmp    .skip:?+1\n\
	.skip   .fval   ?+1\n\
	.num    .z-1    ?+1\n\
.firstloop:\n\
	.num    .z      .firstdone\n\
	.tmp    .num    ?+1\n\
	.num    .tmp    ?+1\n\
	.nbits  .z+1    ?+1\n\
	.tmp    .tmp    .firstloop\n\
.firstdone:\n\
	#Get ret\n\
	.tmp    .arg2:2 ?+1\n\
	.ret0   .ret0   ?+1\n\
	.ret0   .tmp    ?+1\n\
	.ret1   .ret1   ?+1\n\
	.ret1   .tmp    ?+1\n\
	.rval   .rval   ?+1\n\
	#Get [num]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p0:0   ?+1\n\
	.num    .num    ?+1\n\
	.num    .tmp    ?+1\n\
	#Get [shift]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg4:4 ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     .tmp    ?+1\n\
	.shift  .shift  ?+1\n\
	.shift  .nbits  ?+1\n\
	#If [shift]>=[bits], abort.\n\
	.shift  .p1:0   .ret\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .num    ?+1\n\
	.tmp    .z+1    ?+1\n\
	.num    .tmp    .loop\n\
	.rval   .z-1    ?+1\n\
.loop:\n\
	.shift  .z+1    .ret\n\
	#[rval]<<=1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .rval   ?+1\n\
	.rval   .tmp    ?+1\n\
	#[num]<<=1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .num    ?+1\n\
	.num    .tmp    .loop\n\
	.rval   .z-1    .loop\n\
.ret:\n\
	#Set [ret].\n\
	.tmp    .tmp    ?+1\n\
	.rval   .ret0:0 ?+1\n\
	.tmp    .rval   ?+1\n\
	.ret1:0 .tmp    ?+1\n\
	0       0       .arg5:5\n\
	#Variables\n\
	.fval:.skip+1-.firstdone\n\
	.num:0\n\
	.rval:0\n\
	.shift:0\n\
	.tmp:0\n\
	.nbits:0\n\
	0-1 .z:0 1 2\n\
\n\
\n\
uint.not:\n\
	#Call  : 0 ? uint.not ret a\n\
	#Effect: [ret]=~[a]\n\
	#Time  : 26\n\
	#Use the relation -1-[a]=~[a]\n\
	#Setup the stack.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2   ?+1\n\
	0       .tmp    ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	#Get [ret]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2:2 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     .tmp    ?+1\n\
	#Get [a]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg3:3 ?+1\n\
	.p2     .p2     ?+1\n\
	.p2     .tmp    ?+1\n\
	#Set [ret]\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p0:0   ?+1  #[tmp]=-[ret]\n\
	.tmp    .p2:0   ?+1  #[tmp]=-[ret]-[a]\n\
	.tmp    .z+1    ?+1\n\
	.ret    .ret    ?+1\n\
	.ret    .tmp    ?+1  #[ret]=[ret]+[a]\n\
	.p1:0   .ret    ?+1  #[ret]=[ret]-([ret]+[a])=-[a]\n\
	0       0       .arg4:4\n\
	#Variables\n\
	.z:0 1 2\n\
	.ret:0\n\
	.tmp:0\n\
\n\
\n\
uint.and:\n\
	#Call  : 0 ? uint.and ret a b\n\
	#Effect: [ret]=[a]&[b]\n\
	#Time  : 44+7*bits = 485\n\
	#This function works by making sure that the bottom bit is set for [a] and [b].\n\
	#As we shift [b] left, if [b]=0, then we know we have processed all bits. As we\n\
	#rotate [a] left, if we need to set a bit, we simply add 1 to it. The main loop\n\
	#is arranged to minimize the number of [a] bits set or [b]=0 checks needed.\n\
	#Setup stack pointer.\n\
	.atmp   .arg2   ?+1\n\
	0       .atmp   ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	#Get [ret]\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .arg2:2 ?+1\n\
	.ret0   .ret0   ?+1\n\
	.ret0   .atmp   ?+1\n\
	.ret1   .ret1   ?+1\n\
	.ret1   .atmp   ?+1\n\
	#Get [a]\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .arg3:3 ?+1\n\
	.a0     .a0     ?+1\n\
	.a0     .atmp   ?+1\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .a0:0   ?+1\n\
	.a      .a      ?+1\n\
	.a      .atmp   ?+1\n\
	#Get [b]\n\
	.btmp   .btmp   ?+1\n\
	.btmp   .arg4:4 ?+1\n\
	.b0     .b0     ?+1\n\
	.b0     .btmp   ?+1\n\
	.btmp   .btmp   ?+1\n\
	.btmp   .b0:0   ?+1\n\
	.b      .btmp   ?+1\n\
	#Perform the first iteration outside of the loop. We need [a] and [b] to be odd\n\
	#so that we can efficiently check for carrying in the loop. Flag if the top bit\n\
	#needs to be set at the end.\n\
	        .atmp   .z+1    ?+1\n\
	        .btmp   .z+1    ?+1\n\
	        .a      .atmp   .l0x\n\
	.l1x:   .b      .btmp   .l00\n\
	.l11:   .atmp   .atmp   .loop\n\
	.l0x:   .b      .btmp   .l00\n\
	.l00:   .top    .z+1    ?+1\n\
	        .atmp   .atmp   .loop\n\
	#Loop until [b]=0.\n\
.loop:\n\
	#Prepare [b] for shift and carry.\n\
	        .btmp   .btmp   ?+1\n\
	        .btmp   .b      ?+1\n\
	#Left shift [a] and [b] and check for carry. Set low bit of [a] if needed.\n\
	#If [b]<=[btmp] and [b]=0, then we are done.\n\
	        .b      .btmp   .f0x\n\
	.f1x:   .atmp   .a      ?+1\n\
	        .a      .atmp   .f00\n\
	.f11:   .a      .z-1    .f00\n\
	.f0x:   .b      .z      .done\n\
	        .atmp   .a      ?+1\n\
	        .a      .atmp   .f00\n\
	.f00:   .atmp   .atmp   .loop\n\
.done:\n\
	#Check if the top bit needs to be zero'd.\n\
	.top    .top:.z ?+4\n\
	.a      .btmp   ?+1\n\
	#We have [a]=[a]&[b]+-[btmp] and [btmp]=2^(n-1).\n\
	.a      .ret0:0 ?+1\n\
	.btmp   .a      ?+1\n\
	.ret1:0 .btmp   ?+1\n\
	0       0       .arg5:5\n\
	#Variables\n\
	0-1 .z:0 1 2\n\
	.a:0 .atmp:0\n\
	.b:0 .btmp:0\n\
\n\
\n\
uint.or:\n\
	#Call  : 0 ? uint.or ret a b\n\
	#Effect: [ret]=[a]|[b]\n\
	#Time  : 45+7*bits = 486\n\
	#Use uint.and and the relation A|B=-1-(~A)&(~B).\n\
	#Setup stack pointer.\n\
	.atmp   .arg2   ?+1\n\
	0       .atmp   ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	#Get [ret]\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .arg2:2 ?+1\n\
	.ret0   .ret0   ?+1\n\
	.ret0   .atmp   ?+1\n\
	.ret1   .ret1   ?+1\n\
	.ret1   .atmp   ?+1\n\
	#Get -[a]\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .arg3:3 ?+1\n\
	.a0     .a0     ?+1\n\
	.a0     .atmp   ?+1\n\
	.a      .a      ?+1\n\
	.a      .a0:0   ?+1\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .a      ?+1\n\
	#Get -[b]\n\
	.btmp   .btmp   ?+1\n\
	.btmp   .arg4:4 ?+1\n\
	.b0     .b0     ?+1\n\
	.b0     .btmp   ?+1\n\
	.b      .b0:0   ?+1\n\
	.btmp   .btmp   ?+1\n\
	.btmp   .b      ?+1\n\
	#Perform the first iteration outside of the loop. We need [a] and [b] to be odd\n\
	#so that we can efficiently check for carrying in the loop. Flag if the top bit\n\
	#needs to be set.\n\
	        .a      .z+1    ?+1\n\
	        .b      .z+1    ?+1\n\
	        .a      .atmp   .l0x\n\
	.l1x:   .b      .btmp   .l00\n\
	.l11:   .atmp   .atmp   .loop\n\
	.l0x:   .b      .btmp   .l00\n\
	.l00:   .top    .z+1    ?+1\n\
	        .atmp   .atmp   .loop\n\
	#Loop until [b]=0.\n\
.loop:\n\
	#Prepare [b] for shift and carry.\n\
	        .btmp   .btmp   ?+1\n\
	        .btmp   .b      ?+1\n\
	#Left shift [a] and [b] and check for carry. Set low bit of [a] if needed.\n\
	#If [b]<=[btmp] and [b]=0, then we are done.\n\
	        .b      .btmp   .f0x\n\
	.f1x:   .atmp   .a      ?+1\n\
	        .a      .atmp   .f00\n\
	.f11:   .a      .z-1    .f00\n\
	.f0x:   .b      .z      .done\n\
	        .atmp   .a      ?+1\n\
	        .a      .atmp   .f00\n\
	.f00:   .atmp   .atmp   .loop\n\
.done:\n\
	#Check if the top bit needs to be zero'd.\n\
	.top    .top:.z ?+4\n\
	.a      .btmp   ?+1\n\
	#We have [a]=[a]&[b]+-[btmp] and [btmp]=2^(n-1).\n\
	#A|B=-1-(~A)&(~B)\n\
	.a      .z-1    ?+1\n\
	.btmp   .ret0:0 ?+1\n\
	.a      .btmp   ?+1\n\
	.ret1:0 .a      ?+1\n\
	0       0       .arg5:5\n\
	#Variables\n\
	0-1 .z:0 1 2\n\
	.a:0 .atmp:0\n\
	.b:0 .btmp:0\n\
\n\
\n\
uint.xor:\n\
	#Call  : 0 ? uint.xor ret a b\n\
	#Effect: [ret]=[a]^[b]\n\
	#Time  : 46+7*bits = 487\n\
	#Use uint.and and the relation A^B=A+B-2(A&B).\n\
	#Setup stack pointer.\n\
	.atmp   .arg2   ?+1\n\
	0       .atmp   ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	.arg5   0       ?+1\n\
	#Get [ret]\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .arg2:2 ?+1\n\
	.ret0   .ret0   ?+1\n\
	.ret0   .atmp   ?+1\n\
	.ret1   .ret1   ?+1\n\
	.ret1   .atmp   ?+1\n\
	#Get [a]\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .arg3:3 ?+1\n\
	.a0     .a0     ?+1\n\
	.a0     .atmp   ?+1\n\
	.atmp   .atmp   ?+1\n\
	.atmp   .a0:0   ?+1\n\
	.a      .a      ?+1\n\
	.a      .atmp   ?+1\n\
	#Get [b]\n\
	.btmp   .btmp   ?+1\n\
	.btmp   .arg4:4 ?+1\n\
	.b0     .b0     ?+1\n\
	.b0     .btmp   ?+1\n\
	.btmp   .btmp   ?+1\n\
	.btmp   .b0:0   ?+1\n\
	.b      .btmp   ?+1\n\
	#Perform the first iteration outside of the loop. We need [a] and [b] to be odd\n\
	#so that we can efficiently check for carrying in the loop.\n\
	.off    .off    ?+1\n\
	.off    .atmp   ?+1\n\
	.off    .btmp   ?+1\n\
	.atmp   .z+1    ?+1\n\
	.btmp   .z+1    ?+1\n\
	.a      .atmp   ?+1\n\
	.b      .btmp   ?+1\n\
	.atmp   .atmp   .loop\n\
	#Loop until [b]=0.\n\
.loop:\n\
	#Prepare [b] for shift and carry.\n\
	        .btmp   .btmp   ?+1\n\
	        .btmp   .b      ?+1\n\
	#Left shift [a] and [b] and check for carry. Set low bit of [a] if needed.\n\
	#If [b]<=[btmp] and [b]=0, then we are done.\n\
	        .b      .btmp   .f0x\n\
	.f1x:   .atmp   .a      ?+1\n\
	        .a      .atmp   .f00\n\
	.f11:   .a      .z-1    .f00\n\
	.f0x:   .b      .z      .done\n\
	        .atmp   .a      ?+1\n\
	        .a      .atmp   .f00\n\
	.f00:   .atmp   .atmp   .loop\n\
.done:\n\
	#We have [a]=[a]&[b]+-[btmp] and [btmp]=2^(n-1).\n\
	#Use A^B=A+B-2(A&B).\n\
	.off    .a      ?+1\n\
	.off    .ret0:0 ?+1\n\
	.a      .off    ?+1\n\
	.ret1:0 .a      ?+1\n\
	0       0       .arg5:5\n\
	#Variables\n\
	0-1 .z:0 1 2\n\
	.a:0 .atmp:0\n\
	.b:0 .btmp:0\n\
	.off:0\n\
\n\
#|==============================================================================\n\
\n\
String Printing - v1.05\n\
\n\
Author: Alec Dee - alecdee.github.io - akdee144@gmail.com\n\
\n\
--------------------------------------------------------------------------------\n\
ASCII Table\n\
\n\
  0  00  NUL |  26  1a      |  52  34   4  |  78  4e   N  | 104  68   h\n\
  1  01      |  27  1b  ESC |  53  35   5  |  79  4f   O  | 105  69   i\n\
  2  02      |  28  1c      |  54  36   6  |  80  50   P  | 106  6a   j\n\
  3  03      |  29  1d      |  55  37   7  |  81  51   Q  | 107  6b   k\n\
  4  04      |  30  1e      |  56  38   8  |  82  52   R  | 108  6c   l\n\
  5  05      |  31  1f      |  57  39   9  |  83  53   S  | 109  6d   m\n\
  6  06      |  32  20  SPC |  58  3a   :  |  84  54   T  | 110  6e   n\n\
  7  07  BEL |  33  21   !  |  59  3b   ;  |  85  55   U  | 111  6f   o\n\
  8  08  BCK |  34  22   \"  |  60  3c   <  |  86  56   V  | 112  70   p\n\
  9  09  TAB |  35  23   #  |  61  3d   =  |  87  57   W  | 113  71   q\n\
 10  0a  LF  |  36  24   $  |  62  3e   >  |  88  58   X  | 114  72   r\n\
 11  0b  VTB |  37  25   %  |  63  3f   ?  |  89  59   Y  | 115  73   s\n\
 12  0c      |  38  26   &  |  64  40   @  |  90  5a   Z  | 116  74   t\n\
 13  0d  CR  |  39  27   '  |  65  41   A  |  91  5b   [  | 117  75   u\n\
 14  0e      |  40  28   (  |  66  42   B  |  92  5c   \\  | 118  76   v\n\
 15  0f      |  41  29   )  |  67  43   C  |  93  5d   ]  | 119  77   w\n\
 16  10      |  42  2a   *  |  68  44   D  |  94  5e   ^  | 120  78   x\n\
 17  11      |  43  2b   +  |  69  45   E  |  95  5f   _  | 121  79   y\n\
 18  12      |  44  2c   ,  |  70  46   F  |  96  60   `  | 122  7a   z\n\
 19  13      |  45  2d   -  |  71  47   G  |  97  61   a  | 123  7b   {\n\
 20  14      |  46  2e   .  |  72  48   H  |  98  62   b  | 124  7c   |\n\
 21  15      |  47  2f   /  |  73  49   I  |  99  63   c  | 125  7d   }\n\
 22  16      |  48  30   0  |  74  4a   J  | 100  64   d  | 126  7e   ~\n\
 23  17      |  49  31   1  |  75  4b   K  | 101  65   e  | 127  7f  DEL\n\
 24  18  CAN |  50  32   2  |  76  4c   L  | 102  66   f  |\n\
 25  19      |  51  33   3  |  77  4d   M  | 103  67   g  |\n\
|#\n\
\n\
print:\n\
	#Call: 0 ? print char0 char1 char2 ... 0\n\
	#Print function. Prints a zero terminated ASCII string. If -1 is used as a\n\
	#character value, then treat the next character as a pointer to a number.\n\
	.ptr    .ptr    ?+1\n\
	.ptr    0       ?+1\n\
	.ptr    .z-2    ?+1\n\
	0       0       ?+2\n\
	.ret:   .tmp\n\
.loop:\n\
	#Get the next character.\n\
	.tmp    .ptr:0  ?+1\n\
	.ptr    .z-1    ?+1\n\
	.char   .char   ?+1\n\
	.char   .tmp    .p0:?+1\n\
	#If [char]=0, we've reached the end of the string.\n\
	.char   .z      .ret\n\
	#If [char]>0, and [tmp]<=1, then [char]=-1.\n\
	.tmp    .z+1    .numprep\n\
	#Print [char].\n\
.print:\n\
	0-2     .char   ?+1\n\
	.tmp    .tmp    .loop\n\
.numprep:\n\
	#Prepare to print a number.\n\
	#First entry. Jump back to beginning of loop to get the number's pointer.\n\
	.p0     .pset   .loop\n\
	#Second entry. Get the number from [char].\n\
	.p0     .prem   ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .char:0 ?+1\n\
	.num    .tmp    ?+1\n\
	.show   .show   ?+1\n\
	.base   .base0  ?+1\n\
.numloop:\n\
	#Store a power of 10 in [tmp].\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .base:.base0-1 ?+1\n\
	.char   .char   ?+1\n\
	.char   .char0  ?+1\n\
	#Subtract [tmp] from [num] to get the next digit.\n\
.digitloop:\n\
	.num    .tmp    .digitdone\n\
	.num    .z+1    ?+1\n\
	.show   .z-1    ?+1\n\
	.char   .z-1    .digitloop\n\
.digitdone:\n\
	#If [tmp]=0 then return to the main loop and print the last digit.\n\
	.tmp    .z      .print\n\
	#Add [num]+=[tmp] to correct for the last [num]-[tmp] operation.\n\
	.z      .tmp    ?+1\n\
	.num    .z      ?+1\n\
	.z      .z      ?+1\n\
	#If [show]>0, then we can print digits.\n\
	.show   .z      .noshow\n\
	0-2     .char   ?+1\n\
.noshow:\n\
	.base   .z-1    .numloop\n\
	#Variables\n\
	0-2 0-1 .z:0 1\n\
	.num:0\n\
	.tmp:0\n\
	.show:0\n\
	.char0:0-48\n\
	.pset:.p0-.numprep-2\n\
	.prem:.numprep-.p0+2\n\
	#1-10^n\n\
	.base10:\n\
		0-9999999999999999999 0-999999999999999999 0-99999999999999999\n\
		   0-9999999999999999    0-999999999999999    0-99999999999999\n\
		      0-9999999999999       0-999999999999       0-99999999999\n\
		         0-9999999999          0-999999999          0-99999999\n\
		            0-9999999             0-999999             0-99999\n\
		               0-9999                0-999                0-99\n\
		                  0-9                    0\n\
	.base0:?-.base10-1\n\
\n\
#|==============================================================================\n\
\n\
Random Number Generator - v1.03\n\
\n\
Author: Alec Dee - alecdee.github.io - akdee144@gmail.com\n\
\n\
--------------------------------------------------------------------------------\n\
Index\n\
\n\
random.seed    [num]\n\
random.jump    [num]\n\
random.get     [dst]\n\
random.mod     [dst] [mod]\n\
random.shuffle [[arr]] [len]\n\
\n\
--------------------------------------------------------------------------------\n\
Version History\n\
\n\
1.00\n\
     Initial version.\n\
1.01\n\
     Added shuffling.\n\
1.02\n\
     Optimized random.generate by removing offsets during shitfing.\n\
1.03\n\
     Initial seed is generate by system time.\n\
\n\
--------------------------------------------------------------------------------\n\
TODO\n\
\n\
Find a faster hashing function.\n\
Optimize random.jump based on uint.mul.\n\
Optimize random.mod and random.shuffle based on uint.div.\n\
Merge random.get and random.generate.\n\
|#\n\
\n\
random.table:\n\
	#For the hash output to be unique, the bottom 8 bits of the table elements\n\
	#need be unique. Add 128 to compensate for shifting in random.generate.\n\
	0x98f570cabbbe2960 0x911fe275124571d3 0xc4b49b92decb87b8 0x2cd974e264a1471e\n\
	0xf25c1cd4ec741993 0x6ac38c14e315ff72 0x532a643077bdeaf3 0xe73da4ddf4ea21ce\n\
	0xf482feb36863db2c 0xb0b08786cdd32bff 0x2912bb15798712d5 0xaa3c40a2341958ba\n\
	0xa56c2aec8d398c9f 0xb571c4090f4e31b5 0xcfbbfe93f0333090 0x4d08908eb0d3773f\n\
	0x902c693a21a631cb 0x9b35783a62da3801 0xeb23e76d74a030bd 0x148e78184600d905\n\
	0x93cdff03f57a90f0 0xdc500bc795c0db4b 0x70da57814f7632c1 0x036633f4013f2582\n\
	0x0c8b76d2def52fc2 0xa45d1da2dba14a25 0x28dbc12379f88e00 0xcf437f8d91ddbc86\n\
	0x0e04a0cdced858ab 0xc7ad971bd5fd8b40 0x29c4517860f09471 0x651bab92d762f10c\n\
	0x9e5f7051205bcc26 0xdcf588711bbcf16c 0xb511a1dded21dd29 0x3679f6456f3452f6\n\
	0xe38dc026335be06b 0xc11d3c759a573da9 0x69410c19157a935a 0xbcc29a4c1b48f135\n\
	0x178c1f951bb7690d 0xd0fc4d498b3e96cf 0xb5b221282132f91f 0x3406dfcb2f0366c6\n\
	0xa18219fffb9a29fc 0xf389feeac4bde69c 0x7b0c200137dd9f57 0x2ecc7eb7f4962591\n\
	0x92ac81ab67b51beb 0x9009eb7acc6a5c7d 0x3182a4ab17f0d814 0xde30902e8d338137\n\
	0x3f3b76e6cccfc642 0xb90d0547d1666133 0x8829b84121f35da7 0xaf509317565b19e7\n\
	0x8fa5742b4f4eeeac 0xbfb86e765ab97f32 0x42b8d16ac3cc3a7f 0x33b8fda60fa07180\n\
	0x68b9f22c1b7ba74d 0x0cee1ee11bc6d449 0x0dce2401a6399421 0x052188c95763afdb\n\
	0x4cd0743f96271244 0x8ab6545393a1ebf9 0x768742f4f5d2cab3 0x2505089bf7de1def\n\
	0xc77ddf5d4bcb4fe8 0x3b861ae62a54910f 0xbba48529fa2859a1 0x9364a79693182e69\n\
	0x29da3184545bf7ed 0xae8efc34c79dd8d0 0xefb805aef57bab34 0xf78943322ead0764\n\
	0x9c357259e48eb6af 0x1dcf0b5f98e2b294 0xa84cb6e4e7897551 0x9054b2308f7ff5a8\n\
	0xdea01eccc8cb3002 0x46be28419fcd8f73 0x5c466247cab9ce7a 0x1034bef3c280cb12\n\
	0x8595486352ef7b07 0xe9c864d995472116 0x9d17d691fa40b9d8 0x1b0a781d7f42e5c0\n\
	0x9260768bc3848498 0x32b48273b8447b6e 0xa630dd7aa9926f68 0x6a5f0a3586db52e5\n\
	0xbeda047a0761a9de 0xeeedd85395df432a 0x9fa214fd946164b7 0xd76c7fadfb1b9f27\n\
	0xe2679809cd7c7195 0x4dbb967cba099877 0x9e611d7eb7c16511 0xde11e3858421c4dd\n\
	0x8f60a79abb8d57a4 0xb69e8632011f0476 0x3a1b15a9d57b3adc 0x6ec8bf7ca6e952f4\n\
	0x18ab73ed10808a85 0xccf19063a89d6ed6 0x9ddaae641e0d371d 0x349a6b56eb499da3\n\
	0xdebee3f7288eabe9 0x6d75b7185e043496 0xbfe68ee59f24e009 0xe2f755c64a184728\n\
	0xe3956041e0330606 0x1684ec84b22cf1a6 0xe547786c47fe87e1 0x7aaf255ec884c10b\n\
	0xb9a7b0be91eca4fa 0x18a85229e8fbe317 0x9b6dad19e7415bc4 0xdab2c6a930db6224\n\
	0xd745efee27085597 0x76f406eb0c7428d4 0x3f779c073097aad9 0xbd0f440b38d1bb66\n\
	0x6ebf3706f695fc55 0x5fbeb72a136c5f89 0xd1c85045aafa5699 0x9b0cf77eb69cfe5b\n\
	0x96bc972c67aeefe2 0xb878518614240efb 0x915a36484cec1b5d 0xa020e164db74d519\n\
	0x875a2ac9e4b98658 0xe34b6b0a580b7d50 0xcd30c71286948c3b 0xf0e6820ef3e9dedf\n\
	0x5dd7e2048d695b67 0xc631ad2b02402fe4 0xc04e99806aa6b8b0 0x5c3304efe897203a\n\
	0x8470f7bb68304a7e 0x4667d0d2c455a98f 0x627165e1b5e16941 0xcd115b2a371d7253\n\
	0x9d6959acac5178f2 0x2722e04d0a4a143e 0x9da126422bd82cb6 0xef7d31df6da70b9b\n\
	0x8419df95b52ed518 0x8744bd266232eec9 0xfec4fb7d4a39b7b4 0x653e09ad754e9663\n\
	0x2608342e20aa3b1b 0xcaacecdf21d87d83 0x60760dd379bb46ea 0xb3f7371bd3167bee\n\
	0x83456546a5d4b0c8 0x3b873a2c613d06d2 0x12c3d73474334dec 0xbec28771231d6d4f\n\
	0x1e0915b280ca6d78 0x12f9adbc60d758f8 0x9fb08c027989eee0 0xbe06995c7b3a3a8d\n\
	0xa018541f0b2d74fe 0xcb0dd0f03d00ed20 0xcea6dda8960694ae 0x903aaea97447f361\n\
	0xa790fbe394d3a1f1 0x40efcea66b9f4687 0xce2e0082770418c3 0x648d7efc4101d2c7\n\
	0x77554a83e487e00e 0x88a954411c963eca 0x5e50a70702f25e70 0x0f71bbe7c9f8888e\n\
	0xe10b0dd69b525b39 0xb6e0722926754946 0xf170a88f296f535f 0x3c04bceebe44795e\n\
	0x68bba5422fffc54a 0x3532437701d42d5c 0x0f193926db9f9f03 0xe3e8936f5cc07b75\n\
	0xeb05b184ecbc0781 0xcfb13169fb869a04 0x42a0202293da976a 0xf2b6c837dd71ec52\n\
	0x384cbe585d4a284c 0xaa3111a39a9aeffd 0x6c8ab832cf881743 0x0483dd6ad0cc54da\n\
	0x720a2dd6094fc823 0x03107a9e669770bc 0x1668b4ba38718ed7 0x771106507afb5788\n\
	0x5054ac481b535308 0x7e485aae5cf0843c 0x881766ced977c01c 0x2eb2c7255ded91e6\n\
	0xeeb1ca030d19f04e 0x68138ac1b21f7030 0xe5de8ba1badd73c5 0x03a8f78e3114d636\n\
	0xde62bdde8d42596d 0xcb15fc108b83a222 0x47e32cf9f7cb1038 0xdd46c0bcb1b2ed8b\n\
	0x24966b07ce5abb74 0x107257fa9545c5d1 0xbb6bed3a3715a192 0xca941e35cb1a8ab9\n\
	0x3ea5389dbca69e2d 0x0b84722da650e37c 0x0ddd81bdedcd05ad 0xa55ee070874ab6be\n\
	0x4856d854cdc81015 0xaf3482758939f02f 0x80547b7b42c6082b 0x32a83053658a73aa\n\
	0xb4e0f4a4bd383c9e 0x86c52d7ce1b79e0a 0x1567a7aa94e4fcb1 0x71fc8c1a6dfa442e\n\
	0x381ae7272b68bb48 0x85632a5c9280d6f7 0x141c9e3bdecc42f5 0xae184e25976dae1a\n\
	0x6fd0f1321084317b 0xb95e50ee69ed5f9d 0x786f68e44c0f0ea2 0x88ac24917ce632bb\n\
	0x88fca453535915bf 0x6c6e38b0bf5b979a 0x4b42cfc646897ccd 0x2a18e1dbbded9bb2\n\
	0x8c75ad2c94462045 0xde14e4d24fc9bb62 0x88d304a2898a4584 0xf7e1e0b52d45f0cc\n\
	0x9d8a8dd7d1bafba0 0x5ba48bfee8d17479 0x5d2d0cfc9a48fa56 0x85e41916f3616c6f\n\
	0xedfc0c68c0217147 0x067e32a00b210665 0x04440fe6a9b7ad3d 0xe0942f02c01f838c\n\
	0x86c8c765b04b7031 0x03edd68c2c9f6259 0xa82b24db8deaf410 0x66337c5333e8c4a5\n\
	0x305d36e368598b13 0xbdd8330fbb889ee3 0xc146c702c618a08a 0x377d5bd4c5c6b854\n\
\n\
\n\
random.generate:\n\
	#Call  : 0 ? random.generate\n\
	#Effect: Meant for internal use. Advances the PRNG state, hashes it, and stores\n\
	#the result in random.generate.ret.\n\
	#Time  : 296 instructions\n\
	#On first run, seed the PRNG by the current time.\n\
	.arg2   .arg2   .skip:?+1\n\
	.skip   .frdif  ?+1\n\
	random.seed.skip random.seed.frdif ?+1\n\
	.frtmp  0       ?+1\n\
	0       0       ?+1\n\
	0 ? random.seed 0-4\n\
	0       .frtmp  ?+1\n\
	.arg2   .arg2   .firstrun\n\
	.frdif: .skip+1-.firstrun\n\
	.frtmp: 0\n\
.firstrun:\n\
	#Set return address.\n\
	.arg2   0       ?+1\n\
	.arg2   .l+6    ?+1\n\
	#Advance state.\n\
	.state  .inc    ?+1\n\
	#Prepare return value.\n\
	.ret    .ret    ?+1\n\
	.ret    .state  ?+1\n\
	.z      .l+4    ?+4\n\
.loop:\n\
	.z      .z+1    .done\n\
	#Set [ret]=[ret]*256+128 and [t0]=[table+([out]>>56)]. Offset [ret] by 1 so\n\
	#we can detect if a carry occurs.\n\
	.tmp .tmp ?+1 .tmp .ret ?+1 .tmp .z+1 ?+1 .ret .tmp ?+4\n\
	.tbl .l+0 ?+4 .tbl .l+8 ?+1\n\
	.tmp .tmp ?+1 .tmp .ret ?+1 .ret .tmp ?+4 .tbl .l+1 ?+1\n\
	.tmp .tmp ?+1 .tmp .ret ?+1 .ret .tmp ?+4 .tbl .l+2 ?+1\n\
	.tmp .tmp ?+1 .tmp .ret ?+1 .ret .tmp ?+4 .tbl .l+3 ?+1\n\
	.tmp .tmp ?+1 .tmp .ret ?+1 .ret .tmp ?+4 .tbl .l+4 ?+1\n\
	.tmp .tmp ?+1 .tmp .ret ?+1 .ret .tmp ?+4 .tbl .l+5 ?+1\n\
	.tmp .tmp ?+1 .tmp .ret ?+1 .ret .tmp ?+4 .tbl .l+6 ?+1\n\
	.tmp .tmp ?+1 .tmp .ret ?+1 .ret .tmp ?+4 .tbl .l+7 ?+1\n\
	#[ret]-=table+128\n\
	.ret    .tbl:0  ?+1\n\
	.tbl    .tbl    .loop\n\
.done:\n\
	0       0       .arg2:0\n\
	#Variables\n\
	.state:0x4a090815efe7b279\n\
	.inc:0x1b859b859f5851fd\n\
	.ret:0\n\
	.tmp:0\n\
	.l:0-128-random.table 0-64 0-32 0-16 0-8 0-4 0-2 0-1 0-random.table\n\
	.z:0 1\n\
\n\
\n\
random.seed:\n\
	#Call  : 0 ? random.seed num\n\
	#Effect: Sets the PRNG state based on the value of [num].\n\
	#Disable random seeding on first run.\n\
	.tmp    .tmp    .skip:?+1\n\
	random.generate.skip random.generate.frdif  ?+1\n\
	.skip   .frdif  .firstrun\n\
	.frdif: .skip+1-.firstrun\n\
.firstrun:\n\
	#Setup the stack.\n\
	.tmp    .arg2   ?+1\n\
	.tmp    .z-2    ?+1\n\
	0       .tmp    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	0       0       ?+1\n\
	#Get [num].\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2:2 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .p0:0   ?+1\n\
	#Reset the generator state.\n\
	random.generate.state random.generate.state ?+1\n\
	random.generate.inc   random.generate.inc   ?+1\n\
	#Set [inc] make sure it's odd.\n\
	random.generate.inc .tmp ?+1\n\
	0 ? random.generate\n\
	random.generate.inc random.generate.inc ?+1\n\
	random.generate.inc random.generate.ret ?+1\n\
	random.generate.inc random.generate.ret ?+1\n\
	random.generate.inc .z-1 ?+1\n\
	#Set [state].\n\
	random.generate.state .tmp ?+1\n\
	0 ? random.generate\n\
	random.generate.state random.generate.state ?+1\n\
	random.generate.state random.generate.ret   .arg3:3\n\
	#Variables\n\
	.tmp:0\n\
	0-2 0-1 .z:0\n\
\n\
\n\
random.jump:\n\
	#Call  : 0 ? random.jump num\n\
	#Effect: Jumps the PRNG state forward or backwards [num] number of steps.\n\
	#Setup the stack.\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2   ?+1\n\
	.tmp    .z-2    ?+1\n\
	0       .tmp    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	#Get [num].\n\
	.tmp    .tmp    ?+1\n\
	.tmp    .arg2:2 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp    ?+1\n\
	.num    .num    ?+1\n\
	.num    .p0:0   ?+1\n\
	#Calculate [inc]*[num].\n\
	.mul    .mul    ?+1\n\
	.tmp    .tmp    ?+1\n\
	.i      .i0     ?+1\n\
.loop:\n\
	#[num]<<1 and carry into [mul].\n\
	.tmp    .z+1    ?+1\n\
	.tmp    .num    ?+1\n\
	.num    .tmp    ?+4\n\
	.mul    random.generate.inc ?+1\n\
	.tmp    .tmp    ?+1\n\
	.i      .z+1    .done\n\
	#[mul]<<1\n\
	.tmp    .mul    ?+1\n\
	.mul    .tmp    ?+1\n\
	.tmp    .tmp    .loop\n\
.done:\n\
	#[state]+=[inc]*[num]\n\
	.tmp    .mul    ?+1\n\
	random.generate.state .tmp ?+1\n\
	#Return\n\
	0       0       .arg3:3\n\
	#Variables\n\
	.tmp:0\n\
	.num:0\n\
	.mul:0\n\
	.i:0\n\
	.i0:0-64\n\
	0-2 0-1 .z:0 1\n\
\n\
\n\
random.get:\n\
	#Call  : 0 ? random.get dst\n\
	#Effect: [dst]=a random 64 bit integer\n\
	#Setup the stack.\n\
	0       .z+2    ?+1\n\
	.arg2   .arg2   ?+1\n\
	.arg2   0       ?+1\n\
	0       .z+1    ?+1\n\
	.arg3   .arg3   ?+1\n\
	.arg3   0       ?+1\n\
	0       0       ?+1\n\
	#Get dst.\n\
	.p0     .arg2:2 ?+1\n\
	.p1     .p0     ?+1\n\
	.p2     .p0     ?+1\n\
	.z      .p1     ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .z      ?+1\n\
	.z      .z      ?+1\n\
	#Get a random number.\n\
	0 ? random.generate\n\
	.z random.generate.ret ?+1\n\
	#Set [dst] and return.\n\
	.p0:0   .p1:0   ?+1\n\
	.p2:0   .z      ?+1\n\
	.z      .z      ?+1\n\
	0       0       .arg3:3\n\
	#Variables\n\
	.z:0 1 2\n\
\n\
\n\
random.mod:\n\
	#Call  : 0 ? random.get dst mod\n\
	#Effect: [dst]=a random number in [0,[mod]).\n\
	#Setup the stack.\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .arg2   ?+1\n\
	0       .tmp0   ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	0       0       ?+1\n\
	#Get dst.\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .arg2:2 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp0   ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     .tmp0   ?+1\n\
	#Get [mod].\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .arg3:3 ?+1\n\
	.p2     .p2     ?+1\n\
	.p2     .tmp0   ?+1\n\
	.nmod   .nmod   ?+1\n\
	.nmod   .p2:0   ?+1\n\
	.nmod   .z      .div0\n\
	.nmod   .z-1    ?+1\n\
	.mod    .mod    ?+1\n\
	.mod    .nmod   ?+1\n\
.randloop:\n\
	#Get a new random number.\n\
	0 ? random.generate\n\
	.rand   .rand   ?+1\n\
	.rand random.generate.ret ?+1\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0 random.generate.ret ?+1\n\
	.rem    .rem    ?+1\n\
	.i      .i0     ?+1\n\
	#Caculate [rem]=[rand]%[mod].\n\
.modloop:\n\
	#[tmp0]<<1 and carry into [rem].\n\
	.tmp1   .tmp1   ?+1\n\
	.tmp1   .tmp0   ?+1\n\
	.tmp1   .z+1    ?+1\n\
	.tmp0   .tmp1   ?+4\n\
	.rem    .z-1    ?+1\n\
	#[rem]%[mod]\n\
	.rem    .mod    ?+7\n\
	.rem    .z+1    ?+1\n\
	.tmp1   .tmp1   ?+7\n\
	.rem    .nmod   ?+1\n\
	.tmp1   .tmp1   ?+1\n\
	.i      .z+1    .moddone\n\
	#[rem]<<1\n\
	.tmp1   .rem    ?+1\n\
	.rem    .tmp1   .modloop\n\
.moddone:\n\
	#Rejection sampling. Accept if rand-rem<=-mod.\n\
	.nmod   .z+1    ?+1\n\
	.rand   .rem    ?+1\n\
	.rand   .nmod   .accept\n\
	.nmod   .z-1    .randloop\n\
.accept:\n\
	.rem    .p0:0   ?+1\n\
	.tmp1   .rem    ?+1\n\
	.p1:0   .tmp1   ?+1\n\
	0       0       .arg4:4\n\
.div0:\n\
	0-1     0       ?-2\n\
	#Variables\n\
	.nmod:0\n\
	.mod:0\n\
	.rand:0\n\
	.rem:0\n\
	.tmp0:0\n\
	.tmp1:0\n\
	.i:0\n\
	.i0:0-64\n\
	0-1 .z:0 1 2\n\
\n\
\n\
random.shuffle:\n\
	#Call  : 0 ? random.shuffle arr len\n\
	#Effect: Randomly shuffles [[arr]] from [0,[len]).\n\
	#Setup the stack.\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .arg2   ?+1\n\
	0       .tmp0   ?+1\n\
	0       .z+2    ?+1\n\
	.arg2   0       ?+1\n\
	.arg3   0       ?+1\n\
	.arg4   0       ?+1\n\
	0       0       ?+1\n\
	#Get [len].\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .arg3:3 ?+1\n\
	.p1     .p1     ?+1\n\
	.p1     .tmp0   ?+1\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .p1:0   ?+1\n\
	.len    .len    ?+1\n\
	.len    .tmp0   ?+1\n\
	#Return if [len]<=1.\n\
	.len    .z+1    .done\n\
	#Get -[arr].\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .arg2:2 ?+1\n\
	.p0     .p0     ?+1\n\
	.p0     .tmp0   ?+1\n\
	.narr   .narr   ?+1\n\
	.narr   .p0:0   ?+1\n\
	#Set array pointers.\n\
	.i0     .i0     ?+1\n\
	.i0     .narr   ?+1\n\
	.i1     .i1     ?+1\n\
	.i1     .narr   ?+1\n\
	.nmod   .nmod   ?+1\n\
	.nmod   .z+1    ?+1\n\
	.mod    .mod    ?+1\n\
	.mod    .z-1    .randloop\n\
.loop:\n\
	.len    .z+1    .done\n\
	#Get a random number in [0,i+1).\n\
.randloop:\n\
	0 ? random.generate\n\
	.rand   .rand   ?+1\n\
	.rand random.generate.ret ?+1\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0 random.generate.ret ?+1\n\
	.rem    .rem    ?+1\n\
	.k      .k0     ?+1\n\
	#Caculate [rem]=[rand]%[mod].\n\
.modloop:\n\
	#[tmp0]<<1 and carry into [rem].\n\
	.tmp1   .tmp1   ?+1\n\
	.tmp1   .tmp0   ?+1\n\
	.tmp1   .z+1    ?+1\n\
	.tmp0   .tmp1   ?+4\n\
	.rem    .z-1    ?+1\n\
	#[rem]%[mod]\n\
	.rem    .mod    ?+7\n\
	.rem    .z+1    ?+1\n\
	.tmp1   .tmp1   ?+7\n\
	.rem    .nmod   ?+1\n\
	.tmp1   .tmp1   ?+1\n\
	.k      .z+1    .moddone\n\
	#[rem]<<1\n\
	.tmp1   .rem    ?+1\n\
	.rem    .tmp1   .modloop\n\
.moddone:\n\
	#Rejection sampling. Accept if rand-rem<=-mod.\n\
	.nmod   .z+1    ?+1\n\
	.rand   .rem    ?+1\n\
	.rand   .nmod   .modaccept\n\
	.nmod   .z-1    .randloop\n\
.modaccept:\n\
	#Increment i.\n\
	.i0     .z-1    ?+1\n\
	.i1     .z-1    ?+1\n\
	#Set j=arr+[rand]%(i+1).\n\
	.rem    .j0     ?+1\n\
	.rem    .narr   ?+1\n\
	.tmp1   .rem    ?+1\n\
	.j0     .tmp1   ?+1\n\
	.j1     .tmp1   ?+1\n\
	#Swap [i] and [j].\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .i0:0   ?+1\n\
	.tmp1   .tmp1   ?+1\n\
	.tmp1   .j0:0   ?+1\n\
	.tmp1   .tmp0   ?+1  #[tmp1]=[i]-[j]\n\
	.i1:0   .tmp1   ?+1\n\
	.tmp0   .tmp0   ?+1\n\
	.tmp0   .tmp1   ?+1\n\
	.j1:0   .tmp0   ?+1\n\
	#Next loop.\n\
	.mod    .z-1    .loop\n\
.done:\n\
	0       0       .arg4:4\n\
	#Variables\n\
	.tmp0:0\n\
	.tmp1:0\n\
	.narr:0\n\
	.rem:0\n\
	.nmod:0\n\
	.mod:0\n\
	.len:0\n\
	.rand:0\n\
	.k:0\n\
	.k0:0-64\n\
	0-1 .z:0 1 2\n\
\n\
";

//--------------------------------------------------------------------------------
//Hash map for labels.

typedef struct unllabel {
	struct unllabel *next,*scope;
	const uchar* data;
	u64 addr;
	u32 hash,len,depth;
} unllabel;

u32 unllabelcmp(unllabel* l,unllabel* r) {
	//Compare two labels from their last character to their first along with any
	//scope characters. Return 0 if they're equal.
	unllabel *lv=0,*rv=0;
	if (l->len!=r->len || l->hash!=r->hash) {return 1;}
	for (u32 i=l->len-1;i!=(u32)-1;i--) {
		if (l && i<l->len) {lv=l;l=l->scope;}
		if (r && i<r->len) {rv=r;r=r->scope;}
		if (lv==rv) {return 0;}
		if (lv->data[i]!=rv->data[i]) {return 1;}
	}
	return 0;
}

typedef struct unlhashmap {
	unllabel** map;
	u32 mask;
} unlhashmap;

unlhashmap* unlhashcreate(void) {
	unlhashmap* map=(unlhashmap*)malloc(sizeof(unlhashmap));
	if (map) {
		map->mask=(1<<20)-1;
		map->map=(unllabel**)malloc((map->mask+1)*sizeof(unllabel*));
		if (map->map) {
			for (u32 i=0;i<=map->mask;i++) {map->map[i]=0;}
			return map;
		}
		free(map);
	}
	return 0;
}

void unlhashfree(unlhashmap* map) {
	if (map) {
		for (u32 i=0;i<=map->mask;i++) {
			unllabel *lbl,*next=map->map[i];
			while ((lbl=next)) {
				next=lbl->next;
				free(lbl);
			}
		}
		free(map->map);
		free(map);
	}
}

unllabel* unllabelinit(unlhashmap* map,unllabel* lbl,unllabel* scope,const uchar* data,u32 len) {
	//Initialize a label and return a match if we find one.
	//Count .'s to determine what scope we should be in.
	u32 depth=0;
	while (depth<len && data[depth]=='.') {depth++;}
	while (scope && scope->depth>depth) {scope=scope->scope;}
	depth=scope?scope->depth:0;
	u32 hash=scope?scope->hash:0;
	u32 scopelen=scope?scope->len:0;
	lbl->scope=scope;
	lbl->depth=depth+1;
	//Offset the data address by the parent scope's depth.
	u32 dif=scopelen-depth+(depth>0);
	lbl->data=data-dif;
	lbl->len=len+dif;
	//Compute the hash of the label. Use the scope's hash to speed up computation.
	for (u32 i=scopelen;i<lbl->len;i++) {
		hash+=lbl->data[i]+i;
		hash=(hash>>9)|(hash<<23);
		hash^=hash>>14;
		hash*=0xe4d75b4b;
		hash=(hash>>7)|(hash<<25);
		hash^=hash>>6;
		hash*=0x253aa2ed;
		hash=(hash>>17)|(hash<<15);
		hash^=hash>>6;
		hash*=0x5d24324b;
		hash=(hash>>16)|(hash<<16);
	}
	lbl->hash=hash;
	//Search for a match.
	unllabel* match=map->map[hash&map->mask];
	while (match && unllabelcmp(match,lbl)) {match=match->next;}
	return match;
}

unllabel* unllabeladd(unlhashmap* map,unllabel* lbl) {
	unllabel* dst=(unllabel*)malloc(sizeof(unllabel));
	if (dst) {
		memcpy(dst,lbl,sizeof(unllabel));
		u32 hash=dst->hash&map->mask;
		dst->next=map->map[hash];
		map->map[hash]=dst;
	}
	return dst;
}

//--------------------------------------------------------------------------------
//Unileq architecture interpreter.

#define UNL_RUNNING      0
#define UNL_COMPLETE     1
#define UNL_ERROR_PARSER 2
#define UNL_ERROR_MEMORY 3
#define UNL_MAX_PARSE    (1<<30)

typedef struct unlstate {
	u64 *mem,alloc,ip;
	u32 state;
	char statestr[256];
} unlstate;

void unlclear(unlstate* st);
void unlsetmem(unlstate* st,u64 addr,u64 val);

unlstate* unlcreate(void) {
	//Allocate a unileq interpreter.
	unlstate* st=(unlstate*)malloc(sizeof(unlstate));
	if (st) {
		st->mem=0;
		unlclear(st);
	}
	return st;
}

void unlfree(unlstate* st) {
	if (st) {
		unlclear(st);
		free(st);
	}
}

void unlparsestr(unlstate* st,const char* str) {
	//Convert unileq assembly language into a unileq program.
	#define  CNUM(c) ((uchar)(c<='9'?c-'0':((c-'A')&~32)+10))
	#define ISLBL(c) (CNUM(c)<36 || c=='_' || c=='.' || c>127)
	#define  ISOP(c) (c=='+' || c=='-')
	#define     NEXT (c=i++<len?ustr[i-1]:0)
	unlclear(st);
	u32 i=0,j=0,len=0;
	const uchar* ustr=(const uchar*)str;
	uchar c,op;
	const char* err=0;
	//Get the string length.
	if (ustr) {
		while (len<UNL_MAX_PARSE && ustr[len]) {len++;}
	}
	if (len>=UNL_MAX_PARSE) {err="Input string too long";}
	//Process the string in 2 passes. The first pass is needed to find label values.
	unlhashmap* map=unlhashcreate();
	if (map==0) {err="Unable to allocate hash map";}
	for (u32 pass=0;pass<2 && err==0;pass++) {
		unllabel *scope=0,*lbl,lbl0;
		u64 addr=0,val=0,acc=0;
		op=0;
		i=0;
		NEXT;
		j=i;
		while (c && err==0) {
			u32 n=0,token=0;
			if (c=='\r' || c=='\n' || c=='\t' || c==' ') {
				//Whitespace.
				NEXT;
				continue;
			}
			if (c=='#') {
				//Comment. If next='|', use the multi-line format.
				u32 mask=0,eoc='\n',i0=i;
				if (NEXT=='|') {mask=255;eoc=('|'<<8)+'#';NEXT;}
				while (c && n!=eoc) {n=((n&mask)<<8)+c;NEXT;}
				if (mask && n!=eoc) {err="Unterminated block quote";j=i0;}
				continue;
			}
			j=i;
			if (ISOP(c)) {
				//Operator. Decrement addr since we're modifying the previous value.
				if (op) {err="Double operator";}
				if (op==':') {err="Operating on declaration";}
				if (addr--==0) {err="Leading operator";}
				op=c;
				NEXT;
			} else if (CNUM(c)<10) {
				//Number. If it starts with "0x", use hexadecimal.
				token=10;
				val=0;
				if (c=='0' && (NEXT=='x' || c=='X')) {token=16;NEXT;}
				while ((n=CNUM(c))<token) {val=val*token+n;NEXT;}
			} else if (c=='?') {
				//Current address token.
				token=1;
				val=addr;
				NEXT;
			} else if (ISLBL(c)) {
				//Label.
				while (ISLBL(c)) {NEXT;}
				lbl=unllabelinit(map,&lbl0,scope,ustr+(j-1),i-j);
				if (c==':') {
					//Label declaration.
					if (pass==0) {
						if (lbl) {err="Duplicate label declaration";}
						lbl0.addr=addr;
						lbl=unllabeladd(map,&lbl0);
						if (lbl==0) {err="Unable to allocate label";}
					}
					scope=lbl;
					if (ISOP(op)) {err="Operating on declaration";}
					op=c;
					NEXT;
				} else {
					token=1;
					if (lbl) {val=lbl->addr;}
					else if (pass) {err="Unable to find label";}
				}
			} else {
				err="Unexpected token";
				i++;
			}
			if (token) {
				//Add a new value to memory.
				if (op=='+') {val=acc+val;}
				else if (op=='-') {val=acc-val;}
				else if (pass) {unlsetmem(st,addr-1,acc);}
				addr++;
				acc=val;
				op=0;
				if (ISLBL(c) || c=='?') {err="Unseparated tokens";}
			}
		}
		if (err==0 && ISOP(op)) {err="Trailing operator";}
		if (pass) {unlsetmem(st,addr-1,acc);}
	}
	if (err) {
		//We've encountered a parsing error.
		st->state=UNL_ERROR_PARSER;
		const char* fmt="Parser: %s\n";
		u32 line=1;
		uchar window[61],under[61];
		if (i-- && j--)
		{
			fmt="Parser: %s\nline %u:\n\t\"%s\"\n\t\"%s\"\n";
			//Find the boundaries of the line we're currently parsing.
			u32 s0=0,s1=j,k;
			for (k=0;k<j;k++) {
				if (ustr[k]=='\n') {
					line++;
					s0=k+1;
				}
			}
			while (s1<len && ustr[s1]!='\n') {s1++;}
			//Trim whitespace.
			while (s0<s1 && ustr[s0  ]<=' ') {s0++;}
			while (s1>s0 && ustr[s1-1]<=' ') {s1--;}
			//Extract the line and underline the error.
			s0=j>s0+30?j-30:s0;
			for (k=0;k<60 && s0<s1;k++,s0++) {
				c=ustr[s0];
				window[k]=c;
				under[k]=s0>=j && s0<i?'^':(c<=' '?c:' ');
			}
			window[k]=under[k]=0;
		}
		snprintf(st->statestr,sizeof(st->statestr),fmt,err,line,window,under);
	}
	unlhashfree(map);
}

void unlparsefile(unlstate* st,const char* path) {
	//Load and parse a source file.
	unlclear(st);
	st->state=UNL_ERROR_PARSER;
	FILE* in=fopen(path,"rb");
	//Check if the file exists.
	if (in==0) {
		snprintf(st->statestr,sizeof(st->statestr),"Could not open file \"%s\"\n",path);
		return;
	}
	//Check the file's size.
	fseek(in,0,SEEK_END);
	size_t size=(size_t)ftell(in);
	char* str=0;
	if (size<UNL_MAX_PARSE) {
		str=(char*)malloc((size+1)*sizeof(char));
	}
	if (str==0) {
		snprintf(st->statestr,sizeof(st->statestr),"File \"%s\" too large: %zu bytes\n",path,size);
	} else {
		fseek(in,0,SEEK_SET);
		for (size_t i=0;i<size;i++) {str[i]=(char)getc(in);}
		str[size]=0;
		unlparsestr(st,str);
		free(str);
	}
	fclose(in);
}

void unlclear(unlstate* st) {
	st->state=UNL_RUNNING;
	st->statestr[0]=0;
	st->ip=0;
	free(st->mem);
	st->mem=0;
	st->alloc=0;
}

void unlprintstate(unlstate* st) {
	const char* str=st->statestr;
	if (str[0]==0 && st->state==UNL_RUNNING) {str="Running\n";}
	printf("Unileq state: %08x\n%s",st->state,str);
}

u64 unlgetip(unlstate* st) {
	return st->ip;
}

void unlsetip(unlstate* st,u64 ip) {
	st->ip=ip;
}

u64 unlgetmem(unlstate* st,u64 addr) {
	//Return the memory value at addr.
	return addr<st->alloc?st->mem[addr]:0;
}

void unlsetmem(unlstate* st,u64 addr,u64 val) {
	//Write val to the memory at addr.
	if (addr>=st->alloc) {
		//If we're writing to an address outside of our memory, attempt to resize it or
		//error out.
		if (val==0) {return;}
		//Safely find the maximum we can allocate.
		u64 alloc=1,*mem=0;
		while (alloc && alloc<=addr) {alloc+=alloc;}
		if (alloc==0) {alloc--;}
		size_t max=((size_t)-1)/sizeof(u64);
		if ((sizeof(u64)>sizeof(size_t) || ((size_t)alloc)>max) && alloc>((u64)max)) {
			alloc=(u64)max;
		}
		//Attempt to allocate.
		if (alloc>addr) {
			mem=(u64*)realloc(st->mem,((size_t)alloc)*sizeof(u64));
		}
		if (mem) {
			memset(mem+st->alloc,0,((size_t)(alloc-st->alloc))*sizeof(u64));
			st->mem=mem;
			st->alloc=alloc;
		} else {
			st->state=UNL_ERROR_MEMORY;
			snprintf(st->statestr,sizeof(st->statestr),"Failed to allocate memory.\nIndex: %" PRIu64 "\n",addr);
			return;
		}
	}
	st->mem[addr]=val;
}

void unlrun(unlstate* st,u32 iters) {
	//Run unileq for a given number of iterations. If iters=-1, run forever. We will
	//spend 99% of our time in this function.
	if (st->state!=UNL_RUNNING) {
		return;
	}
	u32 dec=iters!=(u32)-1;
	u64 a,b,ma,mb,ip=st->ip,io=(u64)-4;
	u64 *mem=st->mem,alloc=st->alloc;
	for (;iters;iters-=dec) {
		//Load a and b. c is loaded only if we jump.
		a=ip<alloc?mem[ip]:0;ip++;
		b=ip<alloc?mem[ip]:0;ip++;
		//Input
		if (b<alloc) {
			//Read mem[b].
			mb=mem[b];
		} else if (b<io) {
			//b is out of bounds.
			mb=0;
		} else if (b==(u64)-3) {
			//Read stdin.
			mb=(uchar)getchar();
		} else if (b==(u64)-4) {
			//Read time. time = (seconds since 1 Jan 1970) * 2^32.
			struct timespec ts;
			timespec_get(&ts,TIME_UTC);
			mb=(((u64)ts.tv_sec)<<32)+(((u64)ts.tv_nsec)*0xffffffffULL)/999999999ULL;
		} else {
			mb=0;
		}
		//Output
		if (a<alloc) {
			//Execute a normal unileq instruction.
			ma=mem[a];
			if (ma<=mb) {
				ip=ip<alloc?mem[ip]:0;
			} else {
				ip++;
			}
			mem[a]=ma-mb;
			continue;
		}
		//a is out of bounds or a special address.
		ip=ip<alloc?mem[ip]:0;
		if (a<io) {
			//Execute a normal unileq instruction.
			unlsetmem(st,a,-mb);
			if (st->state!=UNL_RUNNING) {
				break;
			}
			mem=st->mem;
			alloc=st->alloc;
		} else if (a==(u64)-1) {
			//Exit.
			st->state=UNL_COMPLETE;
			break;
		} else if (a==(u64)-2) {
			//Print to stdout.
			putchar((char)mb);
		}
	}
	st->ip=ip;
}

//--------------------------------------------------------------------------------
//Example usage. Call "unileq file.unl" to run a file.

int main(int argc,char** argv) {
	unlstate* unl=unlcreate();
	unlparsestr(unl,SOURCE);
	//Main loop.
	unlrun(unl,(u32)-1);
	//Exit and print status if there was an error.
	u32 ret=unl->state;
	if (ret!=UNL_COMPLETE) {unlprintstate(unl);}
	unlfree(unl);
	return (int)ret;
}

