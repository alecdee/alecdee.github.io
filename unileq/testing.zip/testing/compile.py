#!/usr/bin/python3


# Compile C source files and concatenate libraries.
# Store output in "compiled" directory.


import os,re,sys,shutil


# Directory helpers
pydir=os.path.dirname(os.path.abspath(__file__))
webdir=os.path.realpath(os.path.join(pydir,"../libraries"))
cmpdir=os.path.realpath(os.path.join(pydir,"./compiled"))
libdir=os.path.realpath(os.path.join(pydir,"./library"))
mscdir=os.path.realpath(os.path.join(pydir,"./misc"))

def webjoin(path): return os.path.join(webdir,path)
def cmpjoin(path): return os.path.join(cmpdir,path)
def libjoin(path): return os.path.join(libdir,path)
def mscjoin(path): return os.path.join(mscdir,path)

def loadfile(path):
	with open(path,"r") as f:
		return "".join(f.readlines())
	raise "failed to load file"

def concat(input,output):
	text=""
	for file in input: text+=loadfile(file)
	with open(output,"w") as f: f.write(text)


# Compile the master library. Add line numbers to the index.
if not os.path.isdir(cmpdir): os.mkdir(cmpdir)
master=loadfile(libjoin("master_header.unl"))
files=("string.unl","uint.unl","int.unl","random.unl","memory.unl")
for file in files:
	path=libjoin(file)
	data=loadfile(path)
	idx="{0:s}  |  {1:>4d}".format(file,master.count("\n")+1)
	master=re.sub(re.escape("$"+file+"  |"),idx,master,1)
	master+=data
with open(cmpjoin("master.unl"),"w") as f:
	f.write(master)


# Compile demos
concat([libjoin("print_demo.unl") ,cmpjoin("master.unl")],cmpjoin("print_demo.unl"))
concat([libjoin("random_demo.unl"),cmpjoin("master.unl")],cmpjoin("random_demo.unl"))
concat([libjoin("uint_demo.unl")  ,cmpjoin("master.unl")],cmpjoin("uint_demo.unl"))
concat([libjoin("memory_demo.unl"),cmpjoin("master.unl")],cmpjoin("memory_demo.unl"))
concat([libjoin("toascii.unl")]                          ,cmpjoin("toascii.unl"))
concat([libjoin("helloworld_demo.unl")]                  ,cmpjoin("helloworld_demo.unl"))


# Compile tests
concat([libjoin("uint_test.unl")  ,cmpjoin("master.unl")],cmpjoin("uint_test.unl"))
concat([libjoin("int_test.unl")   ,cmpjoin("master.unl")],cmpjoin("int_test.unl"))
concat([libjoin("random_test.unl"),cmpjoin("master.unl")],cmpjoin("random_test.unl"))
concat([libjoin("memory_test.unl"),cmpjoin("master.unl")],cmpjoin("memory_test.unl"))


# Copy compiled files to the site library
shutil.copyfile(cmpjoin("helloworld_demo.unl"),webjoin("helloworld_demo.unl"))
shutil.copyfile(libjoin("int.unl")        ,webjoin("int.unl"))
shutil.copyfile(cmpjoin("master.unl")     ,webjoin("master.unl"))
shutil.copyfile(libjoin("memory.unl")     ,webjoin("memory.unl"))
shutil.copyfile(cmpjoin("memory_demo.unl"),webjoin("memory_demo.unl"))
shutil.copyfile(cmpjoin("print_demo.unl") ,webjoin("print_demo.unl"))
shutil.copyfile(libjoin("random.unl")     ,webjoin("random.unl"))
shutil.copyfile(cmpjoin("random_demo.unl"),webjoin("random_demo.unl"))
shutil.copyfile(libjoin("string.unl")     ,webjoin("string.unl"))
shutil.copyfile(libjoin("uint.unl")       ,webjoin("uint.unl"))
shutil.copyfile(cmpjoin("uint_demo.unl")  ,webjoin("uint_demo.unl"))
shutil.copyfile(cmpjoin("toascii.unl")    ,webjoin("toascii.unl"))


# Compile unileq.c, unileq_graphics.c, and unileqtest.c
if os.path.isfile(cmpjoin("unileq")): os.remove(cmpjoin("unileq"))
os.system("gcc -Wall -Wextra -O3 "+os.path.join(pydir,"../unileq.c")+" -o "+cmpjoin("unileq"))
if os.path.isfile(cmpjoin("unileq_graphics")): os.remove(cmpjoin("unileq_graphics"))
os.system("gcc -Wall -Wextra -O3 "+mscjoin("unileq_graphics.c")+" -o "+cmpjoin("unileq_graphics")+" -lSDL2")
if os.path.isfile(cmpjoin("unileqtest")): os.remove(cmpjoin("unileqtest"))
os.system("gcc -I\""+os.path.join(pydir,"../")+"\" -fsanitize=address -fsanitize=undefined "+mscjoin("unileqtest.c")+" -o "+cmpjoin("unileqtest"))


