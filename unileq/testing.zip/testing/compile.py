#!/usr/bin/python3

import os,re,sys,shutil


#Directory helpers
pydir=os.path.dirname(os.path.abspath(__file__))
libdir=os.path.realpath(os.path.join(pydir ,"../libraries"))
testdir=os.path.realpath(os.path.join(pydir,"./testenv"))
unldir=os.path.realpath(os.path.join(pydir ,"./unlfiles"))

def libjoin(path):  return os.path.join(libdir ,path)
def testjoin(path): return os.path.join(testdir,path)
def unljoin(path):  return os.path.join(unldir ,path)

def loadfile(path):
	with open(path,"r") as f:
		return "".join(f.readlines())
	raise "failed to load file"

def concat(input,output):
	text=""
	for file in input: text+=loadfile(file)
	with open(output,"w") as f: f.write(text)


#Compile the master library. Add line numbers to the index.
master=loadfile(unljoin("master_header.unl"))
files=("string.unl","uint.unl","int.unl","random.unl","memory.unl")
for file in files:
	path=libjoin(file)
	data=loadfile(path)
	idx="{0:s}  |  {1:>4d}".format(file,master.count("\n")+1)
	master=re.sub(re.escape("$"+file+"  |"),idx,master,1)
	master+=data
with open(libjoin("master.unl"),"w") as f:
	f.write(master)


#Compile demos
concat([unljoin("print_demo.unl") ,libjoin("master.unl")],libjoin("print_demo.unl"))
concat([unljoin("random_demo.unl"),libjoin("master.unl")],libjoin("random_demo.unl"))
concat([unljoin("uint_demo.unl")  ,libjoin("master.unl")],libjoin("uint_demo.unl"))
concat([unljoin("memory_demo.unl"),libjoin("master.unl")],libjoin("memory_demo.unl"))
concat([unljoin("all_demo.unl")   ,libjoin("master.unl")],libjoin("all_demo.unl"))


#Create testing environment
if not os.path.isdir(testdir): os.mkdir(testdir)
shutil.copyfile(libjoin("print_demo.unl") ,testjoin("print_demo.unl"))
shutil.copyfile(libjoin("random_demo.unl"),testjoin("random_demo.unl"))
shutil.copyfile(libjoin("uint_demo.unl")  ,testjoin("uint_demo.unl"))
shutil.copyfile(libjoin("memory_demo.unl"),testjoin("memory_demo.unl"))
shutil.copyfile(libjoin("all_demo.unl")   ,testjoin("all_demo.unl"))
shutil.copyfile(libjoin("toascii.unl")    ,testjoin("toascii.unl"))
concat([unljoin("uint_test.unl")  ,libjoin("master.unl")],testjoin("uint_test.unl"))
concat([unljoin("random_test.unl"),libjoin("master.unl")],testjoin("random_test.unl"))
concat([unljoin("memory_test.unl"),libjoin("master.unl")],testjoin("memory_test.unl"))


#Create unileq.c and unileqtest.c
if os.path.isfile(testjoin("unileq")): os.remove(testjoin("unileq"))
os.system("gcc -O3 "+os.path.join(pydir,"../unileq.c")+" -o "+testjoin("unileq"))
if os.path.isfile(testjoin("unileqtest")): os.remove(testjoin("unileqtest"))
os.system("gcc -fsanitize=address -fsanitize=undefined "+os.path.join(pydir,"unileqtest.c")+" -o "+testjoin("unileqtest"))


