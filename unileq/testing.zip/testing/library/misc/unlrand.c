/*
C implementation of random.unl.
*/

//--------------------------------------------------------------------------------
//Declarations


struct UnlRand {
	u64 mod;
	u64 iters;
	u64 state;
	u64 inc;
	u64 con0;
	u64 con1;
	u64 con2;
	u64 con3;
};
typedef struct UnlRand UnlRand;


UnlRand* UnlRandCreate(u64 mod);
void     UnlRandFree(UnlRand* rnd);
void     UnlRandInit(UnlRand* rnd);
void     UnlRandSeed(UnlRand* rnd,u64 seed);
void     UnlRandJump(UnlRand* rnd,u64 num);
u64      UnlRandGet(UnlRand* rnd);
u64      UnlRandMod(UnlRand* rnd,u64 mod);
void     UnlRandShuffle(UnlRand* rnd,u64* arr,u64 len);


//--------------------------------------------------------------------------------
//Helper Functions


u32 UnlRandOp(u64* a,u64 b,u64 mod) {
	u64 v=*a;
	u32 gt=v>b;
	*a=v<b?(v-b+mod):(v-b);
	return gt;
}

u64 UnlRandAdd(u64 a,u64 b,u64 mod) {
	return (b==0 || a<mod-b)?(a+b):(a+b-mod);
}

u64 UnlRandNeg(u64 a,u64 mod) {
	return a?mod-a:0;
}


//--------------------------------------------------------------------------------
//PRNG


UnlRand* UnlRandCreate(u64 mod) {
	UnlRand* rnd=(UnlRand*)malloc(sizeof(UnlRand));
	rnd->mod=mod;
	UnlRandInit(rnd);
	return rnd;
}

void UnlRandFree(UnlRand* rnd) {
	if (rnd) {
		free(rnd);
	}
}

void UnlRandInit(UnlRand* rnd) {
	u64 mod=rnd->mod;
	u64 iters=0;
	while ((1ULL<<(iters*2))<mod) {
		iters++;
	}
	if (mod==0 || mod>=0x8000000000000000ULL) {
		iters=32;
	}
	rnd->iters=iters;
	rnd->state=0;
	rnd->inc=mod-1;
	rnd->con0=1;
	rnd->con1=0;
	rnd->con2=mod-1;
	rnd->con3=mod-2;
	u64 rem=mod%4;
	u64 tmp0,tmp1,tmp2,tmp3;
	for (u64 i=0;i<iters;i++) {
		if (rem==0) {
			tmp0=UnlRandGet(rnd);
			tmp0=UnlRandAdd(tmp0,tmp0,mod)  ;
			tmp0=UnlRandAdd(tmp0,tmp0,mod)+0;
			tmp1=UnlRandGet(rnd);
			tmp1=UnlRandAdd(tmp1,tmp1,mod)  ;
			tmp1=UnlRandAdd(tmp1,tmp1,mod)+2;
			tmp2=UnlRandGet(rnd);
			tmp2=UnlRandAdd(tmp2,tmp2,mod)  ;
			tmp2=UnlRandAdd(tmp2,tmp2,mod)+1;
			tmp3=UnlRandGet(rnd);
			tmp3=UnlRandAdd(tmp3,tmp3,mod)  ;
			tmp3=UnlRandAdd(tmp3,tmp3,mod)+3;
		} else if (rem==1) {
			tmp0=UnlRandGet(rnd);
			tmp1=UnlRandAdd(tmp0,mod-2,mod);
			tmp2=UnlRandAdd(tmp0,    3,mod);
			tmp3=UnlRandAdd(tmp0,mod-1,mod);
		} else if (rem==2) {
			tmp0=UnlRandGet(rnd);
			tmp0=UnlRandAdd(tmp0,tmp0,mod)+0;
			tmp3=tmp0;
			tmp1=UnlRandGet(rnd);
			tmp1=UnlRandAdd(tmp1,tmp1,mod)+1;
			tmp2=tmp1;
		} else {
			tmp0=UnlRandGet(rnd);
			tmp1=UnlRandAdd(tmp0,mod-2,mod);
			tmp2=UnlRandAdd(tmp0,    1,mod);
			tmp3=UnlRandAdd(tmp0,mod-3,mod);
		}
		rnd->con0=tmp0;
		rnd->con1=tmp1;
		rnd->con2=tmp2;
		rnd->con3=tmp3;
	}
}

void UnlRandSeed(UnlRand* rnd,u64 seed) {
	u64 mod=rnd->mod;
	rnd->state=seed;
	rnd->inc=mod-1;
	//Generate a random increment relatively prime to the modulus.
	//If gcd(num,-num)=1, then it's relatively prime.
	u64 inc;
	while (1) {
		inc=UnlRandGet(rnd);
		u64 a=inc,b=UnlRandNeg(inc,mod);
		while (b) {
			u64 tmp=a%b;
			a=b;
			b=tmp;
		}
		if (a==1) {break;}
	}
	rnd->inc=UnlRandNeg(inc,mod);
}

void UnlRandJump(UnlRand* rnd,u64 num) {
	rnd->state+=num*rnd->inc;
}

u64 UnlRandGet(UnlRand* rnd) {
	u64 mod=rnd->mod;
	UnlRandOp(&rnd->state,rnd->inc,mod);
	u64 hash=UnlRandNeg(rnd->state,mod);
	//Hash the state.
	for (u64 i=0;i<rnd->iters;i++) {
		u64 tmp=mod-1-hash;
		if (UnlRandOp(&hash,tmp,mod)) {
			tmp=UnlRandNeg(hash,mod);
			if (UnlRandOp(&hash,tmp,mod)) {
				UnlRandOp(&hash,rnd->con3,mod);
			} else {
				UnlRandOp(&hash,rnd->con2,mod);
			}
		} else {
			tmp=UnlRandNeg(hash,mod);
			if (UnlRandOp(&hash,tmp,mod)) {
				UnlRandOp(&hash,rnd->con1,mod);
			} else {
				UnlRandOp(&hash,rnd->con0,mod);
			}
		}
	}
	return UnlRandNeg(hash,mod);
}

u64 UnlRandMod(UnlRand* rnd,u64 mod) {
	//u64 min=(rnd->mod-mod)%mod,rand;
	//while ((rand=UnlRandGet(rnd))<min);
	//return rand%mod;
	u64 rand,rem,limit=rnd->mod-mod;
	do {
		rand=UnlRandGet(rnd);
		rem=rand%mod;
	} while (rand-rem>limit);
	return rem;
}

void UnlRandShuffle(UnlRand* rnd,u64* arr,u64 len) {
	for (u64 i=1;i<len;i++) {
		u64 j=UnlRandMod(rnd,i+1);
		u64 tmp=arr[i];
		arr[i]=arr[j];
		arr[j]=tmp;
	}
}

u64 UnlRandTestHash(u64 hash,u64 num) {
	const u64 inc0=0x30d1f2bd3a4cc8aeULL;
	const u64 inc1=0xa377912103273f8bULL;
	hash-=num;
	if (hash&0x8000000000000000ULL) {
		hash=(hash<<1)-inc0+1;
	} else {
		hash=(hash<<1)-inc1+1;
	}
	return hash;
}

void UnlRandTests(void) {
	UnlRand* rnd=UnlRandCreate(0);
	u64 hash;
	//random.output.test
	UnlRandSeed(rnd,99);
	hash=0;
	for (u32 i=0;i<1000000;i++) {
		hash=UnlRandTestHash(hash,UnlRandGet(rnd));
	}
	printf("random.output.test: 0x%016llx\n",(unsigned long long)hash);
	//random.jump.test
	UnlRandSeed(rnd,100);
	hash=0;
	for (u32 i=0;i<10000;i++) {
		u64 seed=UnlRandGet(rnd);
		u64 jump=UnlRandGet(rnd);
		UnlRandSeed(rnd,seed);
		UnlRandJump(rnd,jump);
		hash=UnlRandTestHash(hash,UnlRandGet(rnd));
	}
	printf("random.jump.test: 0x%016llx\n",(unsigned long long)hash);
	//random.mod.test
	UnlRandSeed(rnd,101);
	hash=0;
	u64 mod=0;
	for (u32 i=0;i<100000;i++) {
		if (mod==0) {mod--;}
		mod=UnlRandMod(rnd,mod);
		hash=UnlRandTestHash(hash,mod);
	}
	printf("random.mod.test: 0x%016llx\n",(unsigned long long)hash);
	//random.shuffle.test
	UnlRandSeed(rnd,102);
	u64 arr[66]={
		0x3c760412306d440eULL,0x3002a6567e36c717ULL,0x00a976784f7d2e7fULL,0x3ebc16d04a935effULL,
		0x510a3a24d0ecb9caULL,0xc3c4779048393181ULL,0x72c2726542ae440aULL,0x2e55d7b5c16c4297ULL,
		0xa814c5b005c37109ULL,0x51f0b6cd3ac4839bULL,0xfb100309b5803a0fULL,0xfdffb3f3f196229aULL,
		0xc57f52fe2e2cb207ULL,0xc03ec5df1b0c659eULL,0x104323409d640297ULL,0x7d300742ae9cc67cULL,
		0x80ffb2f4c7876689ULL,0xa670cf314779496dULL,0x759dfd7e08bf6178ULL,0x753e8ff8284e05b8ULL,
		0x625df52130610e61ULL,0x342d91fd26d60f4fULL,0x9fb35eeb0d4978baULL,0xe62bf49393a63a97ULL,
		0xa77b7014726cc161ULL,0x76787d25b7a7bc7aULL,0xac3b6c82c1d922f5ULL,0x22ad1d1a4a3c6dbbULL,
		0xabcc06bfcd498f15ULL,0xcab9b26d3b74ae74ULL,0x7c4b5e06a233d667ULL,0x0bc030351da1aa1cULL,
		0x2fae1cbf8411ed52ULL,0xa56b06e1dd7f3353ULL,0x851067ac93dc173dULL,0xcdefde80d199e147ULL,
		0x8a5e13009d098287ULL,0xbf27d9bc98bde7dcULL,0x690aa504bbd8b5d3ULL,0x512e3d5242a09e40ULL,
		0x1fa9161c855fae91ULL,0x40b0c3043de69e26ULL,0x5701155ea2411de1ULL,0x4a5794639a72fa0fULL,
		0x172b26614fbde7a4ULL,0x0a57972a5f9585d7ULL,0x13ff6b9fc8472173ULL,0xec8581904733cd3dULL,
		0xdd3c452b1b81eb48ULL,0x81f32b1d22f05ac5ULL,0x060c37f06e996722ULL,0x5254415beff37fbaULL,
		0x080f8b3fa041c597ULL,0xa140cc22c78572acULL,0x78ce6c8d1cb65f6bULL,0xab0083595f33760aULL,
		0xcfb3bf4331882290ULL,0xa12a9f4febfcd70dULL,0x524d4ea87b790220ULL,0xd413eca29c4b0785ULL,
		0x153d2cce5fb056f9ULL,0x488d2e52a6357687ULL,0x359ce51f9717e45cULL,0x7a441911961f3189ULL,
		0x1d2d47d80b9f5e07ULL,0x5886e2e9d2cade95ULL
	};
	hash=0;
	for (u32 i=0;i<10000;i++) {
		u64 len=UnlRandMod(rnd,65);
		u64 pos=UnlRandMod(rnd,65-len);
		UnlRandShuffle(rnd,arr+pos+1,len);
		for (u32 j=0;j<66;j++) {
			hash=UnlRandTestHash(hash,arr[j]);
		}
	}
	printf("random.shuffle.test: 0x%016llx\n",(unsigned long long)hash);
	UnlRandFree(rnd);
}

