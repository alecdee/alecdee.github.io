"""

hash=x
hash=(hash<<s)+table[hash>>(bits-s)]


"""

import random


class UnlRandom():
	def __init__(self,bits):
		self.bits=bits
		self.mask=2**bits-1
		self.iters=(bits+7)//8
		self.state=0x4a090815efe7b279
		self.inc=0x1b859b859f5851fd
		"""random.seed(1)
		table=[0]*256
		for i in range(256):
			val=((random.randrange(self.mask+1)<<8)|i)&self.mask
			j=random.randrange(i) if i else 0
			table[i]=table[j]
			table[j]=val
		self.table=table"""
		table=[
			0x98f570cabbbe2960,0x911fe275124571d3,0xc4b49b92decb87b8,0x2cd974e264a1471e,
			0xf25c1cd4ec741993,0x6ac38c14e315ff72,0x532a643077bdeaf3,0xe73da4ddf4ea21ce,
			0xf482feb36863db2c,0xb0b08786cdd32bff,0x2912bb15798712d5,0xaa3c40a2341958ba,
			0xa56c2aec8d398c9f,0xb571c4090f4e31b5,0xcfbbfe93f0333090,0x4d08908eb0d3773f,
			0x902c693a21a631cb,0x9b35783a62da3801,0xeb23e76d74a030bd,0x148e78184600d905,
			0x93cdff03f57a90f0,0xdc500bc795c0db4b,0x70da57814f7632c1,0x036633f4013f2582,
			0x0c8b76d2def52fc2,0xa45d1da2dba14a25,0x28dbc12379f88e00,0xcf437f8d91ddbc86,
			0x0e04a0cdced858ab,0xc7ad971bd5fd8b40,0x29c4517860f09471,0x651bab92d762f10c,
			0x9e5f7051205bcc26,0xdcf588711bbcf16c,0xb511a1dded21dd29,0x3679f6456f3452f6,
			0xe38dc026335be06b,0xc11d3c759a573da9,0x69410c19157a935a,0xbcc29a4c1b48f135,
			0x178c1f951bb7690d,0xd0fc4d498b3e96cf,0xb5b221282132f91f,0x3406dfcb2f0366c6,
			0xa18219fffb9a29fc,0xf389feeac4bde69c,0x7b0c200137dd9f57,0x2ecc7eb7f4962591,
			0x92ac81ab67b51beb,0x9009eb7acc6a5c7d,0x3182a4ab17f0d814,0xde30902e8d338137,
			0x3f3b76e6cccfc642,0xb90d0547d1666133,0x8829b84121f35da7,0xaf509317565b19e7,
			0x8fa5742b4f4eeeac,0xbfb86e765ab97f32,0x42b8d16ac3cc3a7f,0x33b8fda60fa07180,
			0x68b9f22c1b7ba74d,0x0cee1ee11bc6d449,0x0dce2401a6399421,0x052188c95763afdb,
			0x4cd0743f96271244,0x8ab6545393a1ebf9,0x768742f4f5d2cab3,0x2505089bf7de1def,
			0xc77ddf5d4bcb4fe8,0x3b861ae62a54910f,0xbba48529fa2859a1,0x9364a79693182e69,
			0x29da3184545bf7ed,0xae8efc34c79dd8d0,0xefb805aef57bab34,0xf78943322ead0764,
			0x9c357259e48eb6af,0x1dcf0b5f98e2b294,0xa84cb6e4e7897551,0x9054b2308f7ff5a8,
			0xdea01eccc8cb3002,0x46be28419fcd8f73,0x5c466247cab9ce7a,0x1034bef3c280cb12,
			0x8595486352ef7b07,0xe9c864d995472116,0x9d17d691fa40b9d8,0x1b0a781d7f42e5c0,
			0x9260768bc3848498,0x32b48273b8447b6e,0xa630dd7aa9926f68,0x6a5f0a3586db52e5,
			0xbeda047a0761a9de,0xeeedd85395df432a,0x9fa214fd946164b7,0xd76c7fadfb1b9f27,
			0xe2679809cd7c7195,0x4dbb967cba099877,0x9e611d7eb7c16511,0xde11e3858421c4dd,
			0x8f60a79abb8d57a4,0xb69e8632011f0476,0x3a1b15a9d57b3adc,0x6ec8bf7ca6e952f4,
			0x18ab73ed10808a85,0xccf19063a89d6ed6,0x9ddaae641e0d371d,0x349a6b56eb499da3,
			0xdebee3f7288eabe9,0x6d75b7185e043496,0xbfe68ee59f24e009,0xe2f755c64a184728,
			0xe3956041e0330606,0x1684ec84b22cf1a6,0xe547786c47fe87e1,0x7aaf255ec884c10b,
			0xb9a7b0be91eca4fa,0x18a85229e8fbe317,0x9b6dad19e7415bc4,0xdab2c6a930db6224,
			0xd745efee27085597,0x76f406eb0c7428d4,0x3f779c073097aad9,0xbd0f440b38d1bb66,
			0x6ebf3706f695fc55,0x5fbeb72a136c5f89,0xd1c85045aafa5699,0x9b0cf77eb69cfe5b,
			0x96bc972c67aeefe2,0xb878518614240efb,0x915a36484cec1b5d,0xa020e164db74d519,
			0x875a2ac9e4b98658,0xe34b6b0a580b7d50,0xcd30c71286948c3b,0xf0e6820ef3e9dedf,
			0x5dd7e2048d695b67,0xc631ad2b02402fe4,0xc04e99806aa6b8b0,0x5c3304efe897203a,
			0x8470f7bb68304a7e,0x4667d0d2c455a98f,0x627165e1b5e16941,0xcd115b2a371d7253,
			0x9d6959acac5178f2,0x2722e04d0a4a143e,0x9da126422bd82cb6,0xef7d31df6da70b9b,
			0x8419df95b52ed518,0x8744bd266232eec9,0xfec4fb7d4a39b7b4,0x653e09ad754e9663,
			0x2608342e20aa3b1b,0xcaacecdf21d87d83,0x60760dd379bb46ea,0xb3f7371bd3167bee,
			0x83456546a5d4b0c8,0x3b873a2c613d06d2,0x12c3d73474334dec,0xbec28771231d6d4f,
			0x1e0915b280ca6d78,0x12f9adbc60d758f8,0x9fb08c027989eee0,0xbe06995c7b3a3a8d,
			0xa018541f0b2d74fe,0xcb0dd0f03d00ed20,0xcea6dda8960694ae,0x903aaea97447f361,
			0xa790fbe394d3a1f1,0x40efcea66b9f4687,0xce2e0082770418c3,0x648d7efc4101d2c7,
			0x77554a83e487e00e,0x88a954411c963eca,0x5e50a70702f25e70,0x0f71bbe7c9f8888e,
			0xe10b0dd69b525b39,0xb6e0722926754946,0xf170a88f296f535f,0x3c04bceebe44795e,
			0x68bba5422fffc54a,0x3532437701d42d5c,0x0f193926db9f9f03,0xe3e8936f5cc07b75,
			0xeb05b184ecbc0781,0xcfb13169fb869a04,0x42a0202293da976a,0xf2b6c837dd71ec52,
			0x384cbe585d4a284c,0xaa3111a39a9aeffd,0x6c8ab832cf881743,0x0483dd6ad0cc54da,
			0x720a2dd6094fc823,0x03107a9e669770bc,0x1668b4ba38718ed7,0x771106507afb5788,
			0x5054ac481b535308,0x7e485aae5cf0843c,0x881766ced977c01c,0x2eb2c7255ded91e6,
			0xeeb1ca030d19f04e,0x68138ac1b21f7030,0xe5de8ba1badd73c5,0x03a8f78e3114d636,
			0xde62bdde8d42596d,0xcb15fc108b83a222,0x47e32cf9f7cb1038,0xdd46c0bcb1b2ed8b,
			0x24966b07ce5abb74,0x107257fa9545c5d1,0xbb6bed3a3715a192,0xca941e35cb1a8ab9,
			0x3ea5389dbca69e2d,0x0b84722da650e37c,0x0ddd81bdedcd05ad,0xa55ee070874ab6be,
			0x4856d854cdc81015,0xaf3482758939f02f,0x80547b7b42c6082b,0x32a83053658a73aa,
			0xb4e0f4a4bd383c9e,0x86c52d7ce1b79e0a,0x1567a7aa94e4fcb1,0x71fc8c1a6dfa442e,
			0x381ae7272b68bb48,0x85632a5c9280d6f7,0x141c9e3bdecc42f5,0xae184e25976dae1a,
			0x6fd0f1321084317b,0xb95e50ee69ed5f9d,0x786f68e44c0f0ea2,0x88ac24917ce632bb,
			0x88fca453535915bf,0x6c6e38b0bf5b979a,0x4b42cfc646897ccd,0x2a18e1dbbded9bb2,
			0x8c75ad2c94462045,0xde14e4d24fc9bb62,0x88d304a2898a4584,0xf7e1e0b52d45f0cc,
			0x9d8a8dd7d1bafba0,0x5ba48bfee8d17479,0x5d2d0cfc9a48fa56,0x85e41916f3616c6f,
			0xedfc0c68c0217147,0x067e32a00b210665,0x04440fe6a9b7ad3d,0xe0942f02c01f838c,
			0x86c8c765b04b7031,0x03edd68c2c9f6259,0xa82b24db8deaf410,0x66337c5333e8c4a5,
			0x305d36e368598b13,0xbdd8330fbb889ee3,0xc146c702c618a08a,0x377d5bd4c5c6b854
		]
		self.table=[(t-128)&self.mask for t in table]


	def printtable(self):
		for i in range(0,len(self.table),4):
			print("\t\t"+" ".join("0x{0:016x}".format((r+128)&self.mask) for r in self.table[i:i+4]))


	def seed(self,num):
		mask=self.mask
		num=num&mask
		self.state=num
		self.inc=0
		tmp=self.get()
		self.inc=(((-tmp)<<1)+1)&mask
		self.state=(self.state-tmp)&mask
		self.state=self.get()


	def jump(self,num):
		self.state=(self.state+self.inc*num)&self.mask


	def get(self):
		mask=self.mask
		table=self.table
		self.state=(self.state-self.inc)&mask
		hash=(-self.state)&mask
		for i in range(self.iters):
			hash=((hash<<8)-table[hash>>56])&mask
		return (-hash)&mask


	def mod(self,mod):
		mask=self.mask
		mod=mod&mask
		assert(mod)
		cut=(-mod)&mask
		while True:
			rand=self.get()
			rem=rand%mod
			if ((rand-rem)&mask)<=cut:
				return rem


	def shuffle(self,arr):
		for i in range(1,len(arr)):
			j=self.mod(i+1)
			arr[i],arr[j]=arr[j],arr[i]


def RandOutputTest(rand):
	rand.seed(0)
	mask=rand.mask
	hash=0
	inc=(0xa377912103273f8b,0x30d1f2bd3a4cc8ae)
	for i in range(1000000):
		hash=(hash-rand.get())&mask
		hash=((hash<<1)+1-inc[hash>>63])&mask
	print(hash)


def RandJumpTest(rand):
	rand.seed(0)
	mask=rand.mask
	hash=0
	inc=(0xa377912103273f8b,0x30d1f2bd3a4cc8ae)
	for i in range(10000):
		seed=rand.get()
		jump=rand.get()
		rand.seed(seed)
		rand.jump(jump)
		hash=(hash-rand.get())&mask
		hash=((hash<<1)+1-inc[hash>>63])&mask
	print(hash)


def RandModTest(rand):
	rand.seed(0)
	mask=rand.mask
	hash=0
	inc=(0xa377912103273f8b,0x30d1f2bd3a4cc8ae)
	for i in range(100000):
		shift=rand.get()>>58
		mod=rand.get()>>shift
		if mod!=0:
			hash=(hash-rand.mod(mod))&mask
			hash=((hash<<1)+1-inc[hash>>63])&mask
	print(hash)


def RandShuffleTest(rand):
	rand.seed(0)
	mask=rand.mask
	hash=0
	arr=[
		0x3c760412306d440e,0x3002a6567e36c717,0x00a976784f7d2e7f,0x3ebc16d04a935eff,
		0x510a3a24d0ecb9ca,0xc3c4779048393181,0x72c2726542ae440a,0x2e55d7b5c16c4297,
		0xa814c5b005c37109,0x51f0b6cd3ac4839b,0xfb100309b5803a0f,0xfdffb3f3f196229a,
		0xc57f52fe2e2cb207,0xc03ec5df1b0c659e,0x104323409d640297,0x7d300742ae9cc67c,
		0x80ffb2f4c7876689,0xa670cf314779496d,0x759dfd7e08bf6178,0x753e8ff8284e05b8,
		0x625df52130610e61,0x342d91fd26d60f4f,0x9fb35eeb0d4978ba,0xe62bf49393a63a97,
		0xa77b7014726cc161,0x76787d25b7a7bc7a,0xac3b6c82c1d922f5,0x22ad1d1a4a3c6dbb,
		0xabcc06bfcd498f15,0xcab9b26d3b74ae74,0x7c4b5e06a233d667,0x0bc030351da1aa1c,
		0x2fae1cbf8411ed52,0xa56b06e1dd7f3353,0x851067ac93dc173d,0xcdefde80d199e147,
		0x8a5e13009d098287,0xbf27d9bc98bde7dc,0x690aa504bbd8b5d3,0x512e3d5242a09e40,
		0x1fa9161c855fae91,0x40b0c3043de69e26,0x5701155ea2411de1,0x4a5794639a72fa0f,
		0x172b26614fbde7a4,0x0a57972a5f9585d7,0x13ff6b9fc8472173,0xec8581904733cd3d,
		0xdd3c452b1b81eb48,0x81f32b1d22f05ac5,0x060c37f06e996722,0x5254415beff37fba,
		0x080f8b3fa041c597,0xa140cc22c78572ac,0x78ce6c8d1cb65f6b,0xab0083595f33760a,
		0xcfb3bf4331882290,0xa12a9f4febfcd70d,0x524d4ea87b790220,0xd413eca29c4b0785,
		0x153d2cce5fb056f9,0x488d2e52a6357687,0x359ce51f9717e45c,0x7a441911961f3189,
		0x1d2d47d80b9f5e07,0x5886e2e9d2cade95
	]
	inc=(0xa377912103273f8b,0x30d1f2bd3a4cc8ae)
	for i in range(10000):
		slen=1+rand.mod(65)
		for j in range(2,slen):
			k=1+rand.mod(j)
			arr[j],arr[k]=arr[k],arr[j]
		for a in arr:
			hash=(hash-a)&mask
			hash=((hash<<1)+1-inc[hash>>63])&mask
	assert(arr[ 0]==0x3c760412306d440e)
	assert(arr[-1]==0x5886e2e9d2cade95)
	print(hash)


def BuildFibonacciTree(shiftbits,totalbits):
	assert(shiftbits<=totalbits)
	shiftmask=(1<<shiftbits)-1
	#Find a sequence of a-=b or b-=a instructions to calculate 1<<highbits.
	instmaskarr=[]
	retry=False
	for insts in range(1,32):
		for instmask in range(1<<insts):
			a,b=1,0
			for bit in range(insts):
				if (instmask>>bit)&1:
					a=(a-b)&shiftmask
				else:
					b=(b-a)&shiftmask
			if a==0:
				instmaskarr+=[(insts,instmask)]
		#Stop when we find our first solution.
		if instmaskarr:
			if retry: break
			retry=True
			#break
	if len(instmaskarr)==0:
		print("Could not find a solution")
		return
	arr=", ".join([str(x) for x in instmaskarr])
	#print("Found solutions at {0} instructions: {1}".format(insts,arr))
	#Build the fibonacci tree.
	class Node:
		def __init__(self,parent):
			self.parent=parent
			self.child=[None,None]  #[no jump, jump]
			self.ohtvalues=[]       #[original,hash,tmp] pairs
			self.inst=0
			self.depth=parent.depth+1 if parent else 0
			self.value=None
			self.special=None
		def __eq__(a,b):
			if a.depth!=b.depth or a.value!=b.value or a.special!=b.special:
				return False
			for i in range(2):
				achild=a.child[i]
				bchild=b.child[i]
				if (achild is None)!=(bchild is None):
					return False
				if (not (achild is None)) and (not achild==bchild):
					return False
			return True
	lowbits=min(shiftbits+5,totalbits-shiftbits)
	simbits=shiftbits+lowbits
	simmask=(1<<simbits)-1
	off=1<<shiftbits
	for insts,instmask in instmaskarr:
		print("----------------------\n")
		print(insts,instmask)
		root=Node(None)
		nodearr=[root]
		for val in range(simmask+1):
			#Simulate running the instructions to see how we branch.
			parent=root
			hash,tmp=(val)&simmask,(0)&simmask
			for bit in range(insts):
				side=0
				inst=(instmask>>bit)&1
				if inst:
					if hash<=tmp: side=1
					hash=(hash-tmp)&simmask
				else:
					if tmp<=hash: side=1
					tmp=(tmp-hash)&simmask
				#Add the new leaf to the tree.
				parent.inst=inst
				node=parent.child[side]
				if node is None:
					node=Node(parent)
					parent.child[side]=node
					nodearr+=[node]
				parent=node
			#assert(hash==(((val<<shiftbits)+off)&simmask))
			#Add the new value to the leaf node.
			node.ohtvalues+=[(val,hash,tmp)]
		#Get the node's default and special values.
		for node in nodearr:
			if len(node.ohtvalues)==0: continue
			oht=sorted(node.ohtvalues)
			node.value=oht[len(oht)//2][0]>>lowbits
			for o,h,t in oht:
				value=o>>lowbits
				if value!=node.value:
					#assert(node.special is None)
					node.special=value
			#If the node has a special value, make sure that
			#
			#     tmp <= half for the special value
			#     tmp >  half for default values
			#
			specialhash=True
			specialtmp =True
			if not (node.special is None):
				half=1<<(simbits-1)
				for o,h,t in oht:
					value=o>>lowbits
					if value==node.value:
						if h==0: specialhash=False
						if t<=half: specialtmp=False
					else:
						if h!=0: specialhash=False
						if t>half: specialtmp=False
					#print(value,h,t,half)
					#assert((value==node.value and t>half) or (value!=node.value and t<=half))
				#assert(specialhash or specialtmp)
				print(specialhash,specialtmp)
		print(len(nodearr),"nodes")
		continue
		"""for node in nodearr:
			if len(node.ohtvalues)==0: continue
			norm=node.ohtvalues[len(node.ohtvalues)//2][0]>>lowbits
			print("")
			print("values:",len(node.ohtvalues))
			print("norm  :",norm)
			#print([(v[0]>>lowbits,v[1],v[2]) for v in node.ohtvalues])
			for o,h,t in node.ohtvalues:
				if (o>>lowbits)!=norm:
					print("{0}, {1}, {2}, {3}".format(o>>lowbits,o&((1<<lowbits)-1),h,t))
			print([int(v[2]<=(1<<(simbits-1))) for v in node.ohtvalues])
			#print("hash=0")
			#for o,h,t in node.ohtvalues:
			#	if h==0:
			#		print("{0}, {1}, {2}, {3}".format(o>>lowbits,o&((1<<lowbits)-1),h,t))
		"""
		#Remove duplicate nodes. Only remove if they're taken after a jump.
		nodearr.sort(key=lambda n: n.depth)
		for i in range(1,len(nodearr)):
			a=nodearr[i]
			if a.parent.child[0] is a:
				continue
			for j in range(1,len(nodearr)):
				b=nodearr[j]
				if not (a is b) and a==b:
					print("found duplicate child")
					#If they're siblings, remove the right child.
					if b.parent is a.parent:
						a.parent.child[1]=None
						print("siblings")
					else:
						a.parent.child[1]=b
					a.value=-1
					break
		nodearr=[node for node in nodearr if node.value!=-1]
		#Special values can always jump to another node.
		for a in nodearr:
			if a.special:
				for b in nodearr:
					if a.special==b.value:
						a.special=b
						break
		print("nodes: {0}".format(len(nodearr)))
		"""
		lchild,rchild=node.child
		string=label
		if node.inst:
			string+=".tmp   .hash   "
		else:
			string+=".hash  .tmp    "
		string+=rchild.label if rchild else lchild.label
		if lchild:
			string=lchild.string
		if rchild and rchild.parent is node:
			string+=rchild.string
		"""
		#Build tree from bottom to top.
		#splitstr=""
		inst=nodearr[-1].depth
		for node in nodearr:
			label=""
			tmp=node
			while tmp.parent:
				parent=tmp.parent
				label=str(int(parent.child[1] is tmp))+label
				tmp=parent
			label="."+label+"x"*(insts-len(label))
			node.label=label
		pad="\n"+" "*insts+"   "
		for node in nodearr[::-1]:
			label=node.label
			inststr=label+": "+(".tmp    .hash",".hash   .tmp ")[node.inst]+"   "
			child=node.child
			if child[0] is None and child[1] is None:
				#leaf
				inststr=label+": "
				if node.special:
					inststr+=".tmp    .half   {0}".format(node.special.label)+pad
				inststr+=".hash   .con+{0: <2} ?+1".format(node.value)
				inststr+=pad+".tmp    .tmp    .loop"
			elif child[0] is None:
				#[None,right]
				inststr+=child[1].label
				if child[1].parent is node:
					inststr+="\n"+child[1].inststr
			elif child[1] is None:
				#[left,None]
				inststr+=child[0].label+"\n"+child[0].inststr
			elif child[1].parent is node:
				#[left,immediate right]
				inststr+=child[1].label+"\n"+child[0].inststr+"\n"+child[1].inststr
			else:
				#[left,distant right]
				inststr+=child[1].label+"\n"+child[0].inststr
			node.inststr=inststr
		print(pad+".hash   .z-1    ?+1")
		print(root.inststr)
		print(".half: 0x{0:016x}".format(1<<(totalbits-1)))


if __name__=="__main__":
	rand=UnlRandom(64)
	#rand.printtable()
	"""rand.seed(42)
	rand.jump(103)
	arr=[0,1,2,3,4,7]
	for i in range(10):
		rand.shuffle(arr)
		print(arr)"""
	#RandOutputTest(rand)
	#RandJumpTest(rand)
	#RandModTest(rand)
	RandShuffleTest(rand)
	#BuildFibonacciTree(4,64)

