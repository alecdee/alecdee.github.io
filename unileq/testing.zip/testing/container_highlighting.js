//Author  : Alec Dee, akdee144@gmail.com.
//Modified: 24 Jul 2021
/*jshint bitwise: false*/
/*jshint eqeqeq: true*/

function init_editor() {
	var runbutton=document.getElementById("unileq_run");
	var resetbutton=document.getElementById("unileq_reset");
	var input=document.getElementById("unileq_editor");
	var output=document.getElementById("unileq_output");
	var select=document.getElementById("unileq_demo");
	var unl=unlcreate(output);
	var running=0;
	var frametime=0;
	function update() {
		var time=performance.now();
		var rem=frametime-time+16.666667;
		if (rem>1.0) {
			setTimeout(update,1);
			return;
		}
		rem=rem>-16.0?rem:-16.0;
		frametime=time+rem;
		//There's no good unicode character for a pause button, so use 2 vertical bars
		//instead.
		var text="<span style='font-size:60%;vertical-align:middle'>&#9616;&#9616;</span>&nbsp;&nbsp;&nbsp;Pause";
		if (unl.state!==UNL_RUNNING) {
			running=0;
			text="&#9654;&nbsp;&nbsp;&nbsp;Run";
			if (unl.state!==UNL_COMPLETE && output!==null) {
				output.value+=unl.statestr;
			}
		} else if (running===0) {
			text="&#9654;&nbsp;&nbsp;&nbsp;Resume";
		}
		if (runbutton.innerHTML!==text) {
			runbutton.innerHTML=text;
		}
		if (running===1) {
			//Instructions per frame is hard to time due to browser timer inconsistencies.
			//250k instructions per frame at 60fps seems to work well across platforms.
			unlrun_fast(unl,250000);
			setTimeout(update,0);
		}
	}
	//Setup the run button.
	runbutton.onclick=function() {
		if (unl.state===UNL_RUNNING) {
			running=1-running;
		} else {
			unlparsestr(unl,input.value);
			running=1;
		}
		if (running===1) {
			frametime=performance.now()-17;
			setTimeout(update,0);
		}
	};
	runbutton.innerHTML="&#9654;&nbsp;&nbsp;&nbsp;Resume&nbsp;";
	runbutton.style.width=runbutton.clientWidth.toString()+"px";
	runbutton.innerHTML="&#9654;&nbsp;&nbsp;&nbsp;Run";
	//Setup the reset button.
	resetbutton.onclick=function() {
		unlclear(unl);
		running=0;
		setTimeout(update,0);
	};
	//Helper function to load files.
	function loadfile(path) {
		var xhr=new XMLHttpRequest();
		xhr.onreadystatechange=function(){
			if (xhr.readyState===4) {
				unlclear(unl);
				running=0;
				setTimeout(update,0);
				if (xhr.status===200) {
					var name=path.split("/");
					input.value=xhr.response;
					output.value="Loaded "+name[name.length-1];
					update_text();
				} else {
					output.value="Unable to open "+path;
				}
			}
		};
		xhr.open("GET",path,true);
		xhr.send();
	}
	//Setup the example select menu.
	select.onchange=function() {
		if (select.value==="") {
			unlclear(unl);
			input.value="";
			update_text();
		} else {
			loadfile(select.value);
		}
	};
	//Parse arguments.
	var regex=new RegExp(".*?\\?(file|demo|source)=(.*)","g");
	var match=regex.exec(decodeURI(window.location.href));
	if (match!==null) {
		var type=match[1];
		var arg=match[2];
		if (type==="file") {
			loadfile(arg);
		} else if (type==="demo") {
			for (var i=0;i<select.length;i++) {
				var option=select[i];
				if (option.innerText===arg) {
					select.value=option.value;
					loadfile(option.value);
				}
			}
		} else if (type==="source") {
			input.value=arg;
			output.value="";
		}
	}
	//Setup editor highlighting. We do this by creating a textarea and then displaying
	//a colored div directly under it. Skip if Internet Explorer.
	var update_text=function() {};
	var useragent=window.navigator.userAgent;
	if (useragent.match("(MSIE\s|Trident/)")===null) {
		var container=document.createElement("div");
		var highlight=document.createElement("div");
		input.parentNode.replaceChild(container,input);
		container.appendChild(highlight);
		container.appendChild(input);
		//Copy the textarea attributes to the container div.
		//We need to do this before changing the input attributes.
		var inputstyle=window.getComputedStyle(input);
		var valuelist=Object.values(inputstyle);
		var allow=new RegExp("(padding|background|border|margin)","i");
		for (var i=0;i<valuelist.length;i++) {
			var name=valuelist[i];
			if (name.match(allow)) {
				container.style[name]=inputstyle[name];
			}
		}
		container.style.display="grid";
		//container.style.overflow="auto";
		container.style.resize="both";
		container.style.width=inputstyle.width;
		container.style.height=inputstyle.height;
		//Set the textarea to absolute positioning within the container and remove all
		//decorations.
		var lrpadding=parseFloat(inputstyle.paddingLeft)+parseFloat(inputstyle.paddingRight);
		var caretcolor=inputstyle["caret-color"];
		/*input.style["margin-left"]=inputstyle["padding-left"];
		input.style["margin-right"]=inputstyle["padding-right"];
		input.style["margin-top"]=inputstyle["padding-top"];
		input.style["margin-bottom"]=inputstyle["padding-bottom"];*/
		input.style.margin="0";
		input.style.padding="0";
		input.style["grid-row"]="1";
		input.style["grid-column"]="1";
		input.style.border="none";
		input.style.background="none";
		input.style.overflow="hidden";
		input.style.resize="none";
		//Copy the textarea attributes to the highlight div.
		inputstyle=window.getComputedStyle(input);
		var block=new RegExp("color","i");
		for (var i=0;i<valuelist.length;i++) {
			var name=valuelist[i];
			if (name.match(allow) || !name.match(block)) {
				highlight.style[name]=inputstyle[name];
			}
		}
		//Make the textarea's text invisible, except for the caret.
		input.style.color="rgba(0,0,0,0)";
		input.style["caret-color"]=caretcolor;
		update_text=function() {
			highlight.innerHTML=unileq_highlight(input.value);
container.style.overflow="auto";
			input.style.width="0";
			input.style.height="0";
			input.style.width=input.scrollWidth+"px";
			input.style.height=input.scrollHeight+"px";
			/*if (input.scrollWidth<container.clientWidth) {
				input.style.width=container.clientWidth+"px";
				container.style["overflow-x"]="hidden";
			} else {
				input.style.width=input.scrollWidth+"px";
				container.style["overflow-x"]="auto";
			}
			if (input.scrollHeight<container.clientHeight) {
				input.style.height=container.clientHeight+"px";
				container.style["overflow-y"]="hidden";
			} else {
				input.style.height=input.scrollHeight+"px";
				container.style["overflow-y"]="auto";
			}*/
			//highlight.style.width="0";
			//highlight.style.height="0";
			highlight.style.width=input.style.width;
			highlight.style.height=input.style.height;
			//var maxwidth=-lrpadding;
			if (input.scrollWidth<container.clientWidth) {
				container.style["overflow-x"]="hidden";
				input.style.width=container.clientWidth+"px";
				highlight.style.width=container.clientWidth+"px";
			}
			if (input.scrollHeight<container.clientHeight) {
				container.style["overflow-y"]="hidden";
				input.style.height=container.clientHeight+"px";
				highlight.style.height=container.clientHeight+"px";
			}
			//input.style.width=highlight.style.width;
			//input.style.height=highlight.style.height;
		};
		input.oninput=update_text;
		update_text();
	}
}

window.addEventListener("load",init_editor,true);