//Author  : Alec Dee, akdee144@gmail.com.
//Modified: 17 Jul 2021
/*jshint bitwise: false*/
/*jshint eqeqeq: true*/

function init_editor() {
	var runbutton=document.getElementById("unileq_run");
	var resetbutton=document.getElementById("unileq_reset");
	var input=document.getElementById("unileq_editor");
	var output=document.getElementById("unileq_output");
	var select=document.getElementById("unileq_demo");
	var unl=unlcreate(output);
	var running=0;
	var frametime=0;
	function loadfile(path) {
		var xhr=new XMLHttpRequest();
		xhr.onreadystatechange=function(){
			if (xhr.readyState===4) {
				unlclear(unl);
				running=0;
				setTimeout(update,0);
				if (xhr.status===200) {
					var name=path.split("/");
					input.value=xhr.response;
					output.value="Loaded "+name[name.length-1];
					highlight.innerHTML=unileq_highlight(input.value);
				} else {
					output.value="Unable to open "+path;
				}
			}
		};
		xhr.open("GET",path,true);
		xhr.send();
	}
	function update() {
		var time=performance.now();
		var rem=frametime-time+16.666667;
		if (rem>1.0) {
			setTimeout(update,1);
			return;
		}
		rem=rem>-16.0?rem:-16.0;
		frametime=time+rem;
		//Clear the output buffer if it gets full.
		if (output!==null && output.value.length>=10000) {
			output.value="";
		}
		//There's no good unicode character for a pause button, so use 2 vertical bars
		//instead.
		var text="<span style='font-size:60%;vertical-align:middle'>&#9616;&#9616;</span>&nbsp;&nbsp;&nbsp;Pause";
		if (unl.state!==UNL_RUNNING) {
			running=0;
			text="&#9654;&nbsp;&nbsp;&nbsp;Run";
			if (unl.state!==UNL_COMPLETE && output!==null) {
				output.value+=unl.statestr;
			}
		} else if (running===0) {
			text="&#9654;&nbsp;&nbsp;&nbsp;Resume";
		}
		if (runbutton.innerHTML!==text) {
			runbutton.innerHTML=text;
		}
		if (running===1) {
			//Instructions per frame is hard to time due to browser timer inconsistencies.
			//250k instructions per frame at 60fps seems to work well across platforms.
			unlrun_fast(unl,250000);
			setTimeout(update,0);
		}
	}
	//Setup the run button.
	runbutton.onclick=function() {
		if (unl.state===UNL_RUNNING) {
			running=1-running;
		} else {
			unlparsestr(unl,input.value);
			running=1;
		}
		if (running===1) {
			frametime=performance.now()-17;
			setTimeout(update,0);
		}
	};
	runbutton.innerHTML="&#9654;&nbsp;&nbsp;&nbsp;Resume&nbsp;";
	runbutton.style.width=runbutton.clientWidth.toString()+"px";
	runbutton.innerHTML="&#9654;&nbsp;&nbsp;&nbsp;Run";
	//Setup the reset button.
	resetbutton.onclick=function() {
		unlclear(unl);
		running=0;
		setTimeout(update,0);
	};
	//Setup the example select menu.
	select.onchange=function() {
		loadfile(select.value);
	};
	//Parse arguments.
	var regex=/.*?\?(file|demo|source)=(.*)/g;
	var match=regex.exec(decodeURI(window.location.href));
	if (match!==null) {
		var type=match[1];
		var arg=match[2];
		if (type==="file") {
			loadfile(arg);
		} else if (type==="demo") {
			for (var i=0;i<select.length;i++) {
				var option=select[i];
				if (option.innerText===arg) {
					select.value=option.value;
					loadfile(option.value);
				}
			}
		} else if (type==="source") {
			input.value=arg;
			output.value="";
		}
	}
	//Setup editor highlighting. We do this by creating a textarea and then displaying
	//a colored div directly under.
	var container=document.createElement("div");
	var highlight=document.createElement("div");
	var caret=document.createElement("div");
	input.parentNode.replaceChild(container,input);
	container.appendChild(highlight);
	container.appendChild(caret);
	container.appendChild(input);
	//Copy the textarea attributes to the container div.
	//We need to do this before changing the input attributes.
	var inputstyle=window.getComputedStyle(input);
	var valuelist=Object.values(inputstyle);
	var allow=new RegExp("(background|border|margin)","i");
	for (var i=0;i<valuelist.length;i++) {
		var name=valuelist[i];
		if (name.match(allow)) {
			container.style[name]=inputstyle[name];
		}
	}
	container.style.position="relative";
	container.style.width=input.style.width;
	container.style.height=input.style.height;
	input.style.position="absolute";
	input.style.top="0";
	input.style.left="0";
	input.style.resize="none";
	input.style.margin="0";
	input.style.border="none";
	input.style.background="none";
	//Copy the textarea attributes to the highlight div.
	inputstyle=window.getComputedStyle(input);
	var block=new RegExp("color","i");
	for (var i=0;i<valuelist.length;i++) {
		var name=valuelist[i];
		if (name.match(allow) || !name.match(block)) {
			highlight.style[name]=inputstyle[name];
			caret.style[name]=inputstyle[name];
		}
	}
	//Set the container to a grid layout.
	container.style.overflow="hidden";
	highlight.style.overflow="hidden";
	caret.style.overflow="hidden";
	input.style.color="rgba(0,0,0,0.01)";
	function update_text() {
		var text=unileq_highlight(input.value);
		var plain=input.value.substring(0,input.selectionStart);
		plain=plain.replace(/\S/g," ");
		caret.innerHTML=plain+"<span style='background-color:#ffffff;color:#000000'>"+input.value[input.selectionStart]+"</span>";
		highlight.innerHTML=text;
	}
	function update_caret(visible) {
	}
	function update_position() {
		highlight.style.left=(-input.scrollLeft).toString()+"px";
		highlight.style.top=(-input.scrollTop).toString()+"px";
		highlight.style.height=(input.clientHeight+input.scrollTop).toString()+"px";
		highlight.style.width=(input.clientWidth+input.scrollLeft).toString()+"px";
		caret.style.left=highlight.style.left;
		caret.style.top=highlight.style.top;
		caret.style.height=highlight.style.height;
		caret.style.width=highlight.style.width;
	}
	input.oninput=function() {
		update_text();
	};
	input.onscroll=function() {
		update_position();
	};
	input.onselect=function() {
		update_text();
	};
	input.onselectstart=function() {
		update_text();
	};
	console.log(input);
	update_text();
	update_position();
}

window.addEventListener("load",init_editor,true);