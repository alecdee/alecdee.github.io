/*
C implementation of random.unl.
*/

#if defined(__GNUC__)
	#pragma GCC diagnostic error "-Wall"
	#pragma GCC diagnostic error "-Wextra"
	#pragma GCC diagnostic error "-Wpedantic"
	#pragma GCC diagnostic error "-Wformat=1"
	#pragma GCC diagnostic error "-Wconversion"
	#pragma GCC diagnostic error "-Wshadow"
	#pragma GCC diagnostic error "-Wundef"
	#pragma GCC diagnostic error "-Winit-self"
#elif defined(_MSC_VER)
	#pragma warning(push,4)
#endif

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <inttypes.h>

typedef uint32_t u32;
typedef uint64_t u64;
typedef unsigned char uchar;


//--------------------------------------------------------------------------------
//Declarations


struct UnlRand {
	u64 mod;
	u64 iters;
	u64 state;
	u64 inc;
	u64 con0;
	u64 con1;
	u64 con2;
	u64 con3;
};
typedef struct UnlRand UnlRand;


UnlRand* UnlRandCreate(u64 mod);
void     UnlRandFree(UnlRand* rnd);
void     UnlRandInit(UnlRand* rnd);
void     UnlRandSeed(UnlRand* rnd,u64 seed);
void     UnlRandJump(UnlRand* rnd,u64 num);
u64      UnlRandGet(UnlRand* rnd);
u64      UnlRandMod(UnlRand* rnd,u64 mod);
void     UnlRandShuffle(UnlRand* rnd,u64* arr,u64 len);


//--------------------------------------------------------------------------------
//Helper Functions


u32 UnlRandOp(u64* a,u64 b,u64 mod) {
	u64 v=*a;
	u32 gt=v>b;
	*a=v<b?(v-b+mod):(v-b);
	return gt;
}

u64 UnlRandAdd(u64 a,u64 b,u64 mod) {
	return (b==0 || a<mod-b)?(a+b):(a+b-mod);
}

u64 UnlRandNeg(u64 a,u64 mod) {
	return a?mod-a:0;
}


//--------------------------------------------------------------------------------
//PRNG


UnlRand* UnlRandCreate(u64 mod) {
	UnlRand* rnd=(UnlRand*)malloc(sizeof(UnlRand));
	rnd->mod=mod;
	UnlRandInit(rnd);
	return rnd;
}

void UnlRandFree(UnlRand* rnd) {
	if (rnd) {
		free(rnd);
	}
}

void UnlRandInit(UnlRand* rnd) {
	u64 mod=rnd->mod;
	u64 iters=0;
	while ((1ULL<<(iters*2))<mod) {
		iters++;
	}
	if (mod==0 || mod>=0x8000000000000000ULL) {
		iters=32;
	}
	rnd->iters=iters;
	rnd->state=0;
	rnd->inc=mod-1;
	rnd->con0=1;
	rnd->con1=0;
	rnd->con2=mod-1;
	rnd->con3=mod-2;
	u64 rem=mod%4;
	u64 tmp0,tmp1,tmp2,tmp3;
	for (u64 i=0;i<iters;i++) {
		if (rem==0) {
			tmp0=UnlRandGet(rnd);
			tmp0=UnlRandAdd(tmp0,tmp0,mod)  ;
			tmp0=UnlRandAdd(tmp0,tmp0,mod)+0;
			tmp1=UnlRandGet(rnd);
			tmp1=UnlRandAdd(tmp1,tmp1,mod)  ;
			tmp1=UnlRandAdd(tmp1,tmp1,mod)+2;
			tmp2=UnlRandGet(rnd);
			tmp2=UnlRandAdd(tmp2,tmp2,mod)  ;
			tmp2=UnlRandAdd(tmp2,tmp2,mod)+1;
			tmp3=UnlRandGet(rnd);
			tmp3=UnlRandAdd(tmp3,tmp3,mod)  ;
			tmp3=UnlRandAdd(tmp3,tmp3,mod)+3;
		} else if (rem==1) {
			tmp0=UnlRandGet(rnd);
			tmp1=UnlRandAdd(tmp0,mod-2,mod);
			tmp2=UnlRandAdd(tmp0,    3,mod);
			tmp3=UnlRandAdd(tmp0,mod-1,mod);
		} else if (rem==2) {
			tmp0=UnlRandGet(rnd);
			tmp0=UnlRandAdd(tmp0,tmp0,mod)+0;
			tmp3=tmp0;
			tmp1=UnlRandGet(rnd);
			tmp1=UnlRandAdd(tmp1,tmp1,mod)+1;
			tmp2=tmp1;
		} else {
			tmp0=UnlRandGet(rnd);
			tmp1=UnlRandAdd(tmp0,mod-2,mod);
			tmp2=UnlRandAdd(tmp0,    1,mod);
			tmp3=UnlRandAdd(tmp0,mod-3,mod);
		}
		rnd->con0=tmp0;
		rnd->con1=tmp1;
		rnd->con2=tmp2;
		rnd->con3=tmp3;
	}
}

void UnlRandSeed(UnlRand* rnd,u64 seed) {
	u64 mod=rnd->mod;
	rnd->state=seed;
	rnd->inc=mod-1;
	//Generate a random increment relatively prime to the modulus.
	//If gcd(num,-num)=1, then it's relatively prime.
	u64 inc;
	while (1) {
		inc=UnlRandGet(rnd);
		u64 a=inc,b=UnlRandNeg(inc,mod);
		while (b) {
			u64 tmp=a%b;
			a=b;
			b=tmp;
		}
		if (a==1) {break;}
	}
	rnd->inc=UnlRandNeg(inc,mod);
}

void UnlRandJump(UnlRand* rnd,u64 num) {
	rnd->state+=num*rnd->inc;
}

u64 UnlRandGet(UnlRand* rnd) {
	u64 mod=rnd->mod;
	UnlRandOp(&rnd->state,rnd->inc,mod);
	u64 hash=UnlRandNeg(rnd->state,mod);
	//Hash the state.
	for (u64 i=0;i<rnd->iters;i++) {
		u64 tmp=mod-1-hash;
		if (UnlRandOp(&hash,tmp,mod)) {
			tmp=UnlRandNeg(hash,mod);
			if (UnlRandOp(&hash,tmp,mod)) {
				UnlRandOp(&hash,rnd->con3,mod);
			} else {
				UnlRandOp(&hash,rnd->con2,mod);
			}
		} else {
			tmp=UnlRandNeg(hash,mod);
			if (UnlRandOp(&hash,tmp,mod)) {
				UnlRandOp(&hash,rnd->con1,mod);
			} else {
				UnlRandOp(&hash,rnd->con0,mod);
			}
		}
	}
	return UnlRandNeg(hash,mod);
}

u64 UnlRandMod(UnlRand* rnd,u64 mod) {
	//Rejection sampling. Accept if rand-rem<=-mod.
	u64 rand,rem,limit=rnd->mod-mod;
	do {
		rand=UnlRandGet(rnd);
		rem=rand%mod;
	} while (rand-rem>limit);
	return rem;
}

void UnlRandShuffle(UnlRand* rnd,u64* arr,u64 len) {
	//Fisher-Yates shuffling.
	for (u64 i=1;i<len;i++) {
		u64 j=UnlRandMod(rnd,i+1);
		u64 tmp=arr[i];
		arr[i]=arr[j];
		arr[j]=tmp;
	}
}


//--------------------------------------------------------------------------------
//Testing


u64 UnlRandTestHash(u64 hash,u64 num) {
	const u64 inc0=0x30d1f2bd3a4cc8aeULL;
	const u64 inc1=0xa377912103273f8bULL;
	hash-=num;
	if (hash&0x8000000000000000ULL) {
		hash=(hash<<1)-inc0+1;
	} else {
		hash=(hash<<1)-inc1+1;
	}
	return hash;
}

void UnlRandTests(void) {
	UnlRand* rnd=UnlRandCreate(0);
	u64 hash;
	//random.output.test
	UnlRandSeed(rnd,99);
	hash=0;
	for (u32 i=0;i<1000000;i++) {
		hash=UnlRandTestHash(hash,UnlRandGet(rnd));
	}
	printf("random.output.test: 0x%016llx\n",(unsigned long long)hash);
	//random.jump.test
	UnlRandSeed(rnd,100);
	hash=0;
	for (u32 i=0;i<10000;i++) {
		u64 seed=UnlRandGet(rnd);
		u64 jump=UnlRandGet(rnd);
		UnlRandSeed(rnd,seed);
		UnlRandJump(rnd,jump);
		hash=UnlRandTestHash(hash,UnlRandGet(rnd));
	}
	printf("random.jump.test: 0x%016llx\n",(unsigned long long)hash);
	//random.mod.test
	UnlRandSeed(rnd,101);
	hash=0;
	u64 mod=0;
	for (u32 i=0;i<100000;i++) {
		if (mod==0) {mod--;}
		mod=UnlRandMod(rnd,mod);
		hash=UnlRandTestHash(hash,mod);
	}
	printf("random.mod.test: 0x%016llx\n",(unsigned long long)hash);
	//random.shuffle.test
	UnlRandSeed(rnd,102);
	u64 arr[66]={0};
	u64 arrlen=(u64)(sizeof(arr)/sizeof(*arr));
	for (u64 i=0;i<arrlen;i++) {
		for (u64 j=0;j<64;j++) {
			arr[i]=UnlRandTestHash(arr[i],i);
		}
		//printf("0x%016llx ",(unsigned long long)arr[i]);
	}
	hash=0;
	for (u32 i=0;i<10000;i++) {
		u64 len=UnlRandMod(rnd,arrlen-1);
		u64 pos=UnlRandMod(rnd,arrlen-1-len);
		UnlRandShuffle(rnd,arr+pos+1,len);
		for (u32 j=0;j<arrlen;j++) {
			hash=UnlRandTestHash(hash,arr[j]);
		}
	}
	printf("random.shuffle.test: 0x%016llx\n",(unsigned long long)hash);
	UnlRandFree(rnd);
}

int main(void) {
	UnlRandTests();
	return 0;
}
