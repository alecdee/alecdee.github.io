"""
with open("unileq_wasm.js") as f:
	lines=f.read()
lines=lines.replace(";",";\n")
lines=lines.replace("{","{\n\t")
lines=lines.replace("}","\n}")
with open("out2.js","w") as f:
	f.write(lines)
"""

"""
with open("unileq_wasm.wasm","rb") as f: bytearr=f.read()
bytes=len(bytearr)
line=""
for i in range(bytes):
	c=str(bytearr[i])+("," if i+1<bytes else "")
	if len(line)+len(c)>100:
		print(line)
		line=""
	line+=c
if line: print(line)
"""

import base64
with open("unileq_wasm.wasm","rb") as f: bytearr=f.read()
base=str(base64.b64encode(bytearr))
for i in range(2,len(base)-2,99):
	line=base[i:i+99]
	if line[-1]=="'": line=line[:-1]
	#line="".join([chr(c) for c in line])
	print(line+"\\")
