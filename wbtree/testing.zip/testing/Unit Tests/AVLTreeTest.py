"""

Copyright 2022 Alec Dee - MIT license - SPDX: MIT
alecdee.github.io - akdee144@gmail.com

"""

import time,random,math
from AVLTree import AVLTree as SBTree


def SBTreeInspect(tree):
	# Traverse a tree and inspect all links and weights.
	#
	# We traverse in an order that inspects the next node before traversing to it. In
	# this way, we make sure there is a path from the root to any node in the tree.
	node=tree.root
	nodes=0
	maxheight=-1
	# Don't process an empty tree.
	if node is None:
		return (nodes,maxheight)
	if not node.parent is None:
		print("root parent is not null")
		exit()
	height=0
	prev=node
	while True:
		if node is None:
			# We traversed a null child link.
			height-=1
			node=prev
			prev=None
		elif prev is node.right:
			# Going up #2.
			height-=1
			prev=node
			node=node.parent
			if node is None: break
		elif prev is node.left:
			# Going up #1.
			height+=1
			prev=node
			node=node.right
		else:
			# Going down.
			nodes+=1
			# Measure the height of the tree.
			if maxheight<height:
				maxheight=height
			# Check that both siblings point back to the parent.
			left=node.left
			if left and not left.parent is node:
				print("left has no parent")
				exit()
			right=node.right
			if right and not right.parent is node:
				print("right has no parent")
				exit()
			# Check for twins.
			if left and left is right:
				print("children are twins")
				exit()
			# Check weight and weight invariant.
			leftheight=left.height if left else 0
			rightheight=right.height if right else 0
			nheight=(leftheight if leftheight>rightheight else rightheight)+1
			if node.height!=nheight:
				print("node height: {0}, {1}".format(node.height,nheight))
				exit()
			if rightheight+1<leftheight or leftheight+1<rightheight:
				print("height balance: {0}, {1}".format(leftheight,rightheight))
				exit()
			height+=1
			prev=node
			node=left
	if (not prev is tree.root) or maxheight+1!=prev.height:
		print("improper tree height",maxheight+1,prev.height)
		exit()
	return (nodes,maxheight)


def SBManualSearch(valarr,nodearr,nodes,val,search):
	# Perform a regular linear search for a value.
	pos=-1
	if search==SBTree.EQ:
		for i in range(nodes):
			if valarr[i]==val: pos=i;break
	elif search==SBTree.EQG:
		for i in range(nodes-1,-1,-1):
			if valarr[i]==val: pos=i;break
	elif search==SBTree.LT:
		for i in range(nodes):
			if valarr[i]>=val: break
			pos=i
	elif search==SBTree.LE:
		for i in range(nodes):
			if valarr[i]>val: break
			pos=i
	elif search==SBTree.GT:
		for i in range(nodes-1,-1,-1):
			if valarr[i]<=val: break
			pos=i
	elif search==SBTree.GE:
		for i in range(nodes-1,-1,-1):
			if valarr[i]<val: break
			pos=i
	return nodearr[pos] if pos>=0 else None


def SBTreeTest():
	print("Testing SB trees")

	# A mock integer type to test sorting stability of the tree.
	class IndexInt(object):
		def __init__(self,val,idx):
			if isinstance(val,IndexInt): val=val.val
			self.val=val
			self.idx=idx
		def __str__(a): return "("+str(a.val)+","+str(a.idx)+")"
		# def __int__(a): return a.val
		@staticmethod
		def get(a): return a.val if isinstance(a,IndexInt) else a
		def __eq__(a,b): return a.val==IndexInt.get(b)
		def __ne__(a,b): return a.val!=IndexInt.get(b)
		def __le__(a,b): return a.val<=IndexInt.get(b)
		def __lt__(a,b): return a.val< IndexInt.get(b)
		def __ge__(a,b): return a.val>=IndexInt.get(b)
		def __gt__(a,b): return a.val> IndexInt.get(b)

	# Perform multiple trials.
	trials=1000000
	maxnodes=2048
	nodes=0
	maxratio=0.0
	valnum=0
	createprob=128
	createrun=0
	nodearr=[None]*maxnodes
	valarr=[None]*maxnodes
	tree=SBTree(unique=False)
	for trial in range(trials):
		if (trial&4095)==0:
			print("\r{0}/{1}: {2}, {3:.6f}  ".format(trial,trials,nodes,maxratio),end="",flush=True)

		# Make sure the tree is in compliance.
		weight,height=SBTreeInspect(tree)
		if nodes!=weight:
			print("missing nodes: {0}, {1}".format(nodes,weight))
			exit()
		minlim=math.log(nodes+1)/math.log(2.0)
		maxlim=1.44*minlim
		if nodes>0:
			ratio=height/minlim
			if maxratio<ratio: maxratio=ratio
		if height<minlim-1 or height>=maxlim:
			print("tree height: {0}, {1}, {2}, {3}".format(nodes,height,minlim,maxlim))
			exit()

		# Traverse the tree and compare it with the sorted array.
		node=tree.first()
		rev=tree.last()
		for i in range(nodes):
			if (not node is nodearr[i]) or (not node.value is valarr[i]):
				print("forward walk out of order")
				exit()
			if (not rev is nodearr[nodes-i-1]):
				print("reverse walk out of order")
				exit()
			node=node.next()
			rev=rev.prev()
		if (not node is None) or (not rev is None):
			print("didn't finish walking")
			exit()

		# Test searching the tree for a value.
		valmin,valmax=-2,3
		if tree.root:
			valmin=tree.first().value.val-2
			valmax=tree.last().value.val+3
		val=random.randrange(valmin,valmax)
		search=random.randrange(6)
		node=SBManualSearch(valarr,nodearr,nodes,val,search)
		find=tree.find(val,search)
		if not find is node:
			print("Cound not find node")
			exit()

		# Add or remove a value.
		if createrun<=0:
			createrun=1<<random.randrange(9)
			createprob=random.randrange(257)
		createrun-=1
		if random.randrange(256)<createprob:
			if nodes<maxnodes:
				# Add a value.
				valnum=valnum+random.randrange(65)-32
				val=IndexInt(valnum,trial)
				node=tree.add(val)
				i=nodes
				nodes+=1
				while i>0 and valarr[i-1]>val:
					valarr[i]=valarr[i-1]
					nodearr[i]=nodearr[i-1]
					i-=1
				valarr[i]=val
				nodearr[i]=node
		elif nodes:
			# Remove a value.
			i=random.randrange(nodes)
			tree.removenode(nodearr[i])
			nodes-=1
			while i<nodes:
				valarr[i]=valarr[i+1]
				nodearr[i]=nodearr[i+1]
				i+=1

	print("\npassed")


def SBTreeSpeedTest():
	# pypy
	# insert: 5.684066
	# search: 4.612764
	# delete: 3.629820
	#
	# python3
	# insert: 79.122885
	# search: 43.640018
	# delete: 24.880355
	print("Testing SB tree speed")
	random.seed(1)
	shuffle=random.shuffle
	randrange=random.randrange
	timeinsert,timesearch,timedelete=0.0,0.0,0.0
	trials=1000
	nodes=10000
	valarr=[i//16 for i in range(nodes)]
	nodearr=[None]*nodes
	for trial in range(trials):
		tree=SBTree(unique=False)
		# Time insertion.
		shuffle(valarr)
		t0=time.time()
		for i in range(nodes):
			nodearr[i]=tree.add(valarr[i])
		timeinsert+=time.time()-t0
		# Time searching.
		shuffle(valarr)
		t0=time.time()
		for i in range(nodes):
			tree.find(valarr[i],randrange(6))
		timesearch+=time.time()-t0
		# Time deletion.
		shuffle(nodearr)
		t0=time.time()
		for i in range(nodes):
			tree.removenode(nodearr[i])
		timedelete+=time.time()-t0
	print("#insert: {0:6f}".format(timeinsert))
	print("#search: {0:6f}".format(timesearch))
	print("#delete: {0:6f}".format(timedelete))
	print("passed")


if __name__=="__main__":
	SBTreeTest()
	# SBTreeSpeedTest()

