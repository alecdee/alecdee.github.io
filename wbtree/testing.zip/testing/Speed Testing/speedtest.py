"""
speedtest.py - v1.01
"""


import random,gc,os,sys
from time import time,sleep


AuthorNames=(
	"Dee AVL","Dee WBT","Girish AVL",
	"Mozman AVL","Mozman RB","Msingh RB",
	"Pathak AVL","Pgrafov AVL","Reid RB",
	"Stanisl RB","Yoo RB"
)


def LoadTree(name):
	#Load the trees of various authors.
	#
	#In cases where functions aren't defined or require slightly different
	#parameters, we will create support functions to so the libraries all have the
	#same API.
	#
	#Returns:
	#
	#     add function
	#     remove function
	#     search function
	#     clear function

	#For trees that can use custom comparison functions.
	def cmp(a,b): return a-b

	if name=="Dee AVL":

		from dee_avl import AVLTree as dee_avl
		tree=dee_avl(cmp,True)
		return (tree.add,tree.remove,tree.find,tree.clear)

	elif name=="Dee WBT":

		from dee_wbt import WBTree as dee_wbt
		tree=dee_wbt(cmp,True)
		return (tree.add,tree.remove,tree.find,tree.clear)

	elif name=="Girish AVL":

		from girish3_avl import AVLTree as girish_avl
		tree=girish_avl()
		def clear(): tree.__init__()
		return (tree.insert,tree.delete,None,clear)

	elif name=="Mozman AVL":

		from mozman.avltree import AVLTree as mozman_avl
		tree=mozman_avl()
		#insert() requires a value parameter.
		def insertkey(key): return tree.insert(key,None)
		return (insertkey,tree.remove,tree.get_value,tree.clear)

	elif name=="Mozman RB":

		from mozman.rbtree import RBTree as mozman_rb
		tree=mozman_rb()
		#insert() requires a value parameter.
		def insertkey(key): return tree.insert(key,None)
		return (insertkey,tree.remove,tree.get_value,tree.clear)

	elif name=="Msingh RB":

		from msingh3012_rb import RBTree as msingh_rb
		tree=msingh_rb(cmp)
		#insertNode() requires a value parameter.
		def insertkey(key): return tree.insertNode(key,None)
		def deletekey(key): tree.deleteNode(tree.findNode(key))
		def clear(): tree.__init__(cmp)
		return (insertkey,deletekey,tree.findNode,clear)

	elif name=="Pathak AVL":

		from pathak_avl import AVL_Tree as pathak_avl
		tree=pathak_avl()
		tree.root=None
		#insert() requires supplying a node and setting root.
		def insertkey(key): tree.root=tree.insert(tree.root,key)
		def clear(): tree.root=None
		return (insertkey,None,None,clear)

	elif name=="Pgrafov AVL":

		from pgrafov_avl import AVLTree as pgrafov_avl
		tree=pgrafov_avl()
		def clear(): tree.__init__()
		return (tree.insert,tree.remove,tree.find,clear)

	elif name=="Reid RB":

		from reid_rb import rbtree as reid_rb
		tree=reid_rb()
		def clear(): tree.__init__()
		return (tree.insert_key,None,tree.search,clear)

	elif name=="Stanisl RB":

		from stanislavkozlovski_rb import RedBlackTree as stanisl_rb
		tree=stanisl_rb()
		def clear(): tree.__init__()
		return (tree.add,tree.remove,tree.find_node,clear)

	elif name=="Yoo RB":

		from yoo_rb import Tree as yoo_rb,rb_insert as yoo_insert,Node as yoo_node
		tree=yoo_rb()
		#insert() is defined separately from the Tree object.
		def insertkey(key): yoo_insert(tree,yoo_node(key))
		def clear(): tree.__init__()
		return (insertkey,None,None,clear)

	else:

		print("Unknown name: "+str(name))
		exit()


def TimingTestAll():
	#Given an author name, perform timing tests for their tree.
	print("timing trees")
	trials=100
	nodes=100000
	print("trials: {0}".format(trials))
	print("nodes : {0}\n".format(nodes))
	sortarr=[]
	for name in AuthorNames:
		print(name.ljust(11)+": ",end="")
		gc.collect()
		sleep(10)
		treeadd,treeremove,treefind,treeclear=LoadTree(name)
		random.seed(1)
		addtime=0.0
		remtime=0.0
		findtime=0.0
		data=list(range(nodes))
		for trial in range(trials):
			#Add data to the tree.
			random.shuffle(data)
			t0=time()
			for i in range(nodes):
				treeadd(data[i])
			addtime+=time()-t0
			#Find all data points.
			random.shuffle(data)
			if treefind:
				t0=time()
				for i in range(nodes):
					treefind(data[i])
				findtime+=time()-t0
			#Remove all data.
			random.shuffle(data)
			if treeremove:
				t0=time()
				for i in range(nodes):
					treeremove(data[i])
				remtime+=time()-t0
			treeclear()
		addtime/=trials
		components=1
		totaltime=addtime
		addtime="{0:.2f}".format(addtime)
		if treefind is None:
			findtime="-"
		else:
			components+=1
			findtime/=trials
			totaltime+=findtime
			findtime="{0:.2f}".format(findtime)
		if treeremove is None:
			remtime="-"
		else:
			components+=1
			remtime/=trials
			totaltime+=remtime
			remtime="{0:.2f}".format(remtime)
		print("{0}, {1}, {2}".format(addtime,remtime,findtime))
		sortarr+=[[components,-totaltime,name,addtime,remtime,findtime]]
	sortarr.sort()
	print("\nHTML table:\n")
	print("<table class=\"datatable headerrow\">")
	print("<tr><td>Algorithm</td><td>Rank</td><td>Add (s)</td><td>Remove (s)</td><td>Search (s)</td></tr>")
	for i in range(len(sortarr)):
		tree=sortarr[i]
		args=[len(sortarr)-i]+tree[2:]
		print("<tr><td>{1}</td><td>{0}</td><td>{2}</td><td>{3}</td><td>{4}</td></tr>".format(*args))
	print("</table>\n")
	print("timing done")


def TimingGraph():
	import speeddata
	import matplotlib
	import matplotlib.pyplot as plt
	#Add graph.
	maxx,maxy=100000,4.0
	for i in range(2):
		matplotlib.rcParams["font.sans-serif"]="Consolas"
		plt.figure(figsize=(12,6),dpi=100)
		plt.grid(True,linestyle="dashed")
		title=plt.title(("Adding Keys","Removing Keys")[i],y=1.04)
		plt.setp(title,color="black",fontweight="bold",fontsize=22)
		plt.xlabel("N",fontsize=15)
		plt.ylabel("Seconds",fontsize=15)
		plt.xlim(0,maxx)
		plt.ylim(0,maxy)
		for name in AuthorNames:
			data=getattr(speeddata,name)[i]
			if data==None: continue
			xaxis=[d[0] for d in data]
			yaxis=[d[1] for d in data]
			#Find the point of the graph on the upper/right border.
			x,y=xaxis[0],yaxis[0]
			for j in range(1,len(data)):
				x0,y0=x,y
				x,y=xaxis[j],yaxis[j]
				if x>=maxx:
					y=y0+(y-y0)*(maxx-x0)/(x-x0)-maxy*0.01
					x=maxx+maxx*0.002
					break
				elif y>=maxy:
					x=x0+(x-x0)*(maxy-y0)/(y-y0)+maxx*0.002
					y=maxy+maxy*0.005
					break
			plt.plot(xaxis,yaxis)
			#Kludge to prevent overlapping labels.
			if i==0:
				if name=="dee": y-=maxy*0.015
				if name=="stanisl":  y+=maxy*0.015
			plt.text(x,y,name)
		#plt.show()
		plt.savefig(("add_graph.svg","rem_graph.svg")[i],bbox_inches="tight")
	#Table for find times.
	print("Time to search through "+str(maxx)+" elements")
	print("<table>")
	print("<tr><td>Name</td><td>Search Time</td></tr>")
	for name in AuthorNames:
		data=getattr(speeddata,name)[2]
		if data: data="{0:>6f} s".format(data)
		else   : data="N/A"
		print("<tr><td>{0}</td><td>{1}</td></tr>".format(name,data))
	print("</table>")


if __name__=="__main__":
	TimingTestAll()
	#TimingGraph()
