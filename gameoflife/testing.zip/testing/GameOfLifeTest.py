# Testing functions for GameOfLife.py.
# Alec Dee, akdee144@gmail.com

# Python2 compatibility.
import sys
if sys.version_info[0]<=2:
	range=xrange
	input=raw_input
import math

class GameOfLifeTest(object):
	"""
	Conway's Game of Life
	Rules:
	A living cell with fewer than 2 neighbors dies by underpopulation.
	A living cell with 2 or 3 neighbors lives.
	A living cell with greater than 3 neighbors dies by overpopulation.
	A dead cell with 3 neighbors lives by reproduction.
	"""

	def __init__(self,width,height):
		self.width=width
		self.height=height
		self.grid=[[0]*width for y in range(height)]
		self.next=[[0]*width for y in range(height)]
		self.wrap=False

	def getalive(self,x,y):
		"""Internal use. Allow for space wrapping."""
		if x>=0 and x<self.width and y>=0 and y<self.height:
			return self.grid[y][x]
		return 0

	def advance(self,generations=1):
		"""Advance the state by a given number of generations."""
		while generations>0:
			generations-=1
			grid=self.grid
			next=self.next
			alive=self.getalive
			for y in range(self.height):
				for x in range(self.width):
					val=grid[y][x]
					if val<2:
						# Variable cell. Determine if it lives or dies.
						cnt=( alive(x-1,y-1)+alive(x  ,y-1)+alive(x+1,y-1)
						     +alive(x-1,y  )+               alive(x+1,y  )
						     +alive(x-1,y+1)+alive(x  ,y+1)+alive(x+1,y+1))
						# Calculate if the next generation should be alive or dead.
						next[y][x]=int((cnt|val)==3)
					else:
						# Static cell, do not change.
						next[y][x]=val
			self.grid=next
			self.next=grid

	def __str__(self):
		grid=self.grid
		rep=(".","x")
		s=""
		for line in grid:
			s+="".join([rep[c] for c in line])+"\n"
		return s

	def getcell(self,x,y):
		return self.grid[y][x]

	def setcell(self,x,y,v):
		"""v may be a int value or a 2D array of values."""
		if isinstance(v,int):
			self.grid[y][x]=v
			return
		# v is a 2D list.
		for vy in range(len(v)):
			vline=v[vy]
			gline=self.grid[y+vy]
			for vx in range(len(vline)):
				gline[x+vx]=vline[vx]

	def setcoords(self,x,y,coords):
		"""coords is an array of (x,y) points. Mark all points as alive."""
		grid=self.grid
		for p in coords:
			grid[y+p[1]][x+p[0]]=1

	def spawnglider(self,x,y):
		"""Spawn a 3x3 glider."""
		cells=(
			(0,1,0),
			(0,0,1),
			(1,1,1)
		)
		self.setcell(x,y,cells)

	def spawnship(self,x,y):
		"""Spawn a light weight space ship."""
		cells=(
			(1,0,0,1,0),
			(0,0,0,0,1),
			(1,0,0,0,1),
			(0,1,1,1,1)
		)
		self.setcell(x,y,cells)

	def spawnpulsar(self,x,y):
		"""Spawn a 3-period pulsar."""
		cells=(
			(0,0,1,1,1,0,0,0,1,1,1,0,0),
			(0,0,0,0,0,0,0,0,0,0,0,0,0),
			(1,0,0,0,0,1,0,1,0,0,0,0,1),
			(1,0,0,0,0,1,0,1,0,0,0,0,1),
			(1,0,0,0,0,1,0,1,0,0,0,0,1),
			(0,0,1,1,1,0,0,0,1,1,1,0,0),
			(0,0,0,0,0,0,0,0,0,0,0,0,0),
			(0,0,1,1,1,0,0,0,1,1,1,0,0),
			(1,0,0,0,0,1,0,1,0,0,0,0,1),
			(1,0,0,0,0,1,0,1,0,0,0,0,1),
			(1,0,0,0,0,1,0,1,0,0,0,0,1),
			(0,0,0,0,0,0,0,0,0,0,0,0,0),
			(0,0,1,1,1,0,0,0,1,1,1,0,0)
		)
		self.setcell(x,y,cells)

	def spawngospergun(self,x,y):
		"""Spawn Gosper's glider gun."""
		cells=(
			(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0),
			(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0),
			(0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1),
			(0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,1,1),
			(1,1,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
			(1,1,0,0,0,0,0,0,0,0,1,0,0,0,1,0,1,1,0,0,0,0,1,0,1,0,0,0,0,0,0,0,0,0,0,0),
			(0,0,0,0,0,0,0,0,0,0,1,0,0,0,0,0,1,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0),
			(0,0,0,0,0,0,0,0,0,0,0,1,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),
			(0,0,0,0,0,0,0,0,0,0,0,0,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0)
		)
		self.setcell(x,y,cells)

	def spawnacorn(self,x,y):
		"""Spawn a 5206-period acorn."""
		cells=(
			(0,1,0,0,0,0,0),
			(0,0,0,1,0,0,0),
			(1,1,0,0,1,1,1)
		)
		self.setcell(x,y,cells)

	def spawnrabbit(self,x,y):
		cells=(
			(1,0,0,0,1,1,1),
			(1,1,1,0,0,1,0),
			(0,1,0,0,0,0,0)
		)
		self.setcell(x,y,cells)

def LifeSimTest(text=True):
	if text: print("testing life simulation")
	# The fastest ship travels at c/2. Thus, after n generations, the farthest cell
	# that can be set outside of spawn is n/2.
	#
	#                   {n/2}
	#      +-----------------+
	#      |                 |
	#      |    +-------+    |
	#      |    |       |    |
	#      |    | spawn |    |
	#      |    |       |    |
	#      |    +-------+    |
	#      |                 |
	#      +-----------------+
	#
	def setage(life,coord):
		# If a cell is toggled by setcell, it might inherit a recycled cell that already
		# has an age. Therefore, we must reset cells set by setcell.
		x,y=coord
		cell=life.hashtable[life.hashcoords(x,y)]
		while cell and (cell.x!=x and cell.y!=y): cell=cell.next
		if cell: cell.age=0
	trials=100
	maxgen=100
	spawndim=25
	edgegap=(maxgen+1)//2
	dim=spawndim+2*edgegap
	for trial in range(trials):
		if text: sys.stdout.write("\b"*20+"trial: "+str(trial))
		if text: sys.stdout.flush()
		# Create the production and test simulations.
		testlife=GameOfLifeTest(dim,dim)
		life=GameOfLife()
		lifex=randrange(-100,100)
		lifey=randrange(-100,100)
		if (trial&7)<4:
			# Create an acorn in the spawn area.
			x=randrange(spawndim-7)+edgegap
			y=randrange(spawndim-7)+edgegap
			testlife.spawnacorn(x,y)
			life.setcells(".O\n...O\nOO..OOO",(x+lifex,y+lifey))
		elif (trial&7)<7:
			# Create random noise in the spawn area.
			for dy in range(spawndim):
				for dx in range(spawndim):
					x,y=dx+edgegap,dy+edgegap
					state=randrange(2)
					testlife.setcell(x,y,state)
					coord=(x+lifex,y+lifey)
					life.setcell(coord,state)
					setage(life,coord)
		maxrand=randrange(20)+1
		for gen in range(maxgen):
			# Change random cells in the spawn area.
			grid=testlife.grid
			spawn=randrange(maxrand)-9
			for i in range(spawn):
				x=randrange(spawndim)+edgegap
				y=randrange(spawndim)+edgegap
				state=randrange(2)
				grid[y][x]=state
				coord=(x+lifex,y+lifey)
				life.setcell(coord,state)
				setage(life,coord)
			# Try toggling a cell.
			if randrange(20)==0:
				x=randrange(spawndim)+edgegap
				y=randrange(spawndim)+edgegap
				state=randrange(2)
				grid[y][x]=state
				coord=(x+lifex,y+lifey)
				life.setcell(coord,state^1)
				life.setcell(coord,state)
				setage(life,coord)
			# Iterate through all set cells and make sure they're set in the grid.
			cnt=0
			for line in grid: cnt+=sum(line)
			for cell in life:
				cnt-=1
				x,y=cell[0]-lifex,cell[1]-lifey
				assert(grid[y][x]==1)
			assert(cnt==0)
			# Cell-by-cell comparison.
			for y in range(dim):
				for x in range(dim):
					assert(grid[y][x]==life.getcell((x+lifex,y+lifey)))
			# Test if we can get and set patterns losslessly in different formats.
			if randrange(8)==0:
				fmt=("points","plaintext","lif","rle")[randrange(4)]
				x=randrange(spawndim)+edgegap+lifex
				y=randrange(spawndim)+edgegap+lifey
				w,h=randrange(30),randrange(30)
				pat=life.getcells((x,y),(w,h),fmt)
				if randrange(2) and fmt in ("rle","plaintext"):
					com={"rle":"#","plaintext":"!"}[fmt]
					com+="Test comment "+str(randrange(100))
					lines=pat.split("\n")
					for i in range(randrange(5)):
						lines.insert(randrange(len(lines)),com)
					pat="\n".join(lines)
				new=GameOfLife()
				new.setcells(pat,(x,y))
				for dy in range(h):
					for dx in range(w):
						assert(life.getcell((x+dx,y+dy))==new.getcell((x+dx,y+dy)))
			# Make sure cells are being deallocated when dead.
			for cell in life.hashtable:
				while cell:
					cnt,alive=cell.state>>3,cell.state&1
					assert(cnt>=0 and cnt<=8)
					if not hasattr(cell,"age"): cell.age=0
					if cnt or alive: cell.age=0
					else: cell.age+=1
					assert(cell.age<2)
					cell=cell.next
			# Advance each simulation.
			testlife.advance()
			life.advance()
	if text: print("\npassed")

def LifeRotateTest():
	print("testing pattern rotation")
	trials=1000
	for trial in range(trials):
		x=randrange(-100,100)
		y=randrange(-100,100)
		arr=(
			( x  , y  ),(-y-1, x  ),(-x-1,-y-1),( y  ,-x-1),# normal
			(-x-1, y  ),(-y-1,-x-1),( x  ,-y-1),( y  , x  ),# flip h
			( x  ,-y-1),( y  , x  ),(-x-1, y  ),(-y-1,-x-1),# flip v
			(-x-1,-y-1),( y  ,-x-1),( x  , y  ),(-y-1, x  ) # flip h+v
		)
		life=GameOfLife()
		for i in range(16):
			life.setcells([(x,y)],(0,0),i,"points")
			cell=life.queue
			p=(cell.x,cell.y)
			if arr[i]!=p:
				print("rotation incorrect: ",i,arr[i],p)
				exit()
			life.clear()
	print("passed")

def LifeHashTest():
	print("testing hash performance")
	life=GameOfLife()
	life.hashsize=2048
	life.hashmask=life.hashsize-1
	# used: 2026, avg: 5.121717, max: 15
	# life.setcells("backrake3.rle",(0,0),fmt="file")
	# used: 2047, avg: 6.883034, max: 15
	life.setcells("3enginecordershipgun.rle",(-100,-100),fmt="file")
	life.advance(6000)
	csum,cmax,cden=0,0,0
	for cell in life.hashtable:
		h=0
		while cell: h+=1;cell=cell.next
		csum+=h*h
		cmax=max(cmax,h)
		cden+=int(h!=0)
	cavg=math.sqrt(float(csum)/cden)
	print("used: {0}, avg: {1:>6f}, max: {2}".format(cden,cavg,cmax))
	print("passed")

def LifeSpeedTest():
	print("testing life speed")
	life=GameOfLife()
	# pypy: 0.269860, python3:  6.627411
	# life.setcells("backrake3.rle",(0,0),fmt="file")
	# pypy: 1.296225, python3: 23.556984
	life.setcells("3enginecordershipgun.rle",(-100,-100),fmt="file")
	# life.setcells("/home/none/Downloads/maximumvolatilitygun.rle",
	#               (-100,-100),fmt="file")
	t0=time.time()
	life.advance(1000)
	t0=time.time()-t0
	print("time: {0:>6f}".format(t0))
	print("passed")

sys.path.insert(0,"../")
from GameOfLife import GameOfLife
from random import randrange
import time
LifeSimTest()
# LifeRotateTest()
# LifeHashTest()
# LifeSpeedTest()

